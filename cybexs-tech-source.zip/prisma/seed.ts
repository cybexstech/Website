// Seed script — run with: bun prisma/seed.ts
// Creates the administrator account (from ADMIN_EMAIL / ADMIN_PASSWORD env vars)
// and imports the launch article set from src/data/articles.ts.
// Safe to re-run: it upserts by unique keys and never deletes existing data.

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { ARTICLES_SEED } from "../src/data/articles";

const prisma = new PrismaClient();

async function seedAdmin() {
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD || "";

  if (!email || !password) {
    console.warn("[seed] ADMIN_EMAIL / ADMIN_PASSWORD not set — skipping admin provisioning.");
    return;
  }
  if (password.length < 10) {
    console.warn("[seed] ADMIN_PASSWORD too short (min 10 chars) — skipping admin provisioning.");
    return;
  }

  const existing = await prisma.adminUser.findUnique({ where: { email } });
  const passwordHash = await bcrypt.hash(password, 12);

  if (existing) {
    await prisma.adminUser.update({ where: { email }, data: { passwordHash } });
    console.log(`[seed] admin updated: ${email}`);
  } else {
    await prisma.adminUser.create({
      data: { email, name: "Cybexs Admin", passwordHash, role: "ADMIN" },
    });
    console.log(`[seed] admin created: ${email}`);
  }
}

async function seedArticles() {
  let published = 0;
  let drafts = 0;

  for (const a of ARTICLES_SEED) {
    const data = {
      slug: a.slug,
      title: a.title,
      excerpt: a.excerpt,
      content: a.content,
      category: a.category,
      tags: a.tags,
      status: a.status,
      seoTitle: a.seoTitle ?? null,
      seoDescription: a.seoDescription ?? null,
      author: a.author ?? "Cybexs Tech Team",
      readMinutes: a.readMinutes ?? 6,
      publishedAt:
        a.status === "PUBLISHED" ? (a.publishedAt ? new Date(a.publishedAt) : new Date()) : null,
    };
    await prisma.article.upsert({
      where: { slug: a.slug },
      create: data,
      update: {
        title: data.title,
        excerpt: data.excerpt,
        content: data.content,
        category: data.category,
        tags: data.tags,
        status: data.status,
        seoTitle: data.seoTitle,
        seoDescription: data.seoDescription,
        readMinutes: data.readMinutes,
        publishedAt: data.publishedAt,
      },
    });
    if (a.status === "PUBLISHED") published++;
    else drafts++;
  }
  console.log(`[seed] articles: ${published} published, ${drafts} drafts.`);
}

async function main() {
  await seedAdmin();
  await seedArticles();
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
