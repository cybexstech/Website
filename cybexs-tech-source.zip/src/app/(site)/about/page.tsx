import type { Metadata } from "next";
import Image from "next/image";
import { PageHero } from "@/components/site/page-hero";
import { CtaSection } from "@/components/site/cta-section";
import { SectionHeading } from "@/components/site/section-heading";
import { StaggerGroup, StaggerItem, Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "About — A Business Partner, Not a Vendor",
  description:
    "Cybexs Tech combines practical AI automation, technical services and human-powered teams to remove repetitive work — measured honestly, in hours returned and conversations improved.",
  alternates: { canonical: "/about" },
};

const BELIEFS = [
  {
    title: "Practical over theoretical",
    description:
      "We recommend what will work in your business next month, not what will demo well in a slide. Every proposal starts from your actual processes and tools.",
  },
  {
    title: "Transparent by default",
    description:
      "Clear scopes, clear pricing, plain-language reporting. If something isn't working, you hear it from us first — with a plan to fix it.",
  },
  {
    title: "Technology plus people",
    description:
      "Automation handles repetition; trained people handle judgment. We build both, and we're honest about which one a problem actually needs.",
  },
  {
    title: "Long-term systems",
    description:
      "We build things you own and understand — documented, handed over properly, and designed to keep working without us.",
  },
];

const ENGAGEMENT = [
  {
    number: "01",
    title: "Free consultation",
    description:
      "Thirty minutes to understand your tools, processes and goals. Free, with no obligation.",
  },
  {
    number: "02",
    title: "Focused proposal",
    description:
      "A concrete scope: what we'll deliver, when, and what it costs. No generic decks.",
  },
  {
    number: "03",
    title: "Implementation & delivery",
    description:
      "We build, integrate and operate — keeping you updated in plain language throughout.",
  },
  {
    number: "04",
    title: "Ongoing support",
    description:
      "Documentation and training as standard, with optional ongoing improvement plans. No lock-in.",
  },
];

const NOT_THIS = [
  {
    title: "Not a recruitment agency",
    description:
      "We don't supply staff for hire. We deliver outcomes — automated workflows, support coverage and working systems — through our own team.",
  },
  {
    title: "Not a licensed financial or legal advisor",
    description:
      "We don't provide financial, legal or tax advice. Where those questions matter to a project, we recommend qualified professionals.",
  },
  {
    title: "No guaranteed outcomes",
    description:
      "We scope honestly and commit to defined deliverables. We don't promise rankings, revenue or results outside our control — and if we think something won't work, we'll tell you before you spend.",
  },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About us"
        title="A business partner, not a vendor."
        description="Cybexs Tech exists to remove the friction between businesses and the work they actually want to do — with technology and people, combined deliberately."
        crumbs={[]}
      />

      {/* Why we exist */}
      <section className="section bg-white" aria-label="Why we exist">
        <div className="container-site grid gap-12 lg:grid-cols-[1fr_1.6fr] lg:gap-20">
          <div>
            <Reveal>
              <p className="eyebrow">Why we exist</p>
            </Reveal>
          </div>
          <div className="max-w-3xl space-y-6">
            <Reveal>
              <p className="text-lg leading-relaxed text-neutral-600 sm:text-xl">
                Most businesses don&rsquo;t suffer from a lack of software — they suffer from repetitive
                work and disconnected tools. Quotes are re-typed, inquiries go unanswered, data lives in
                five places, and the people who could be serving customers spend their days moving
                information between systems.
              </p>
            </Reveal>
            <Reveal delay={0.08}>
              <p className="text-lg leading-relaxed text-neutral-600 sm:text-xl">
                Cybexs Tech exists to remove that friction. We combine practical technology — AI
                automation, integrations, well-built websites — with human-powered services for the work
                that needs people. Neither replaces the other; together they let a smaller team operate
                like a larger one.
              </p>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="text-lg leading-relaxed text-neutral-600 sm:text-xl">
                We measure success the honest way: hours returned to your team, conversations improved
                with your customers, and systems that keep working after we hand them over. If an
                engagement isn&rsquo;t delivering that, we say so — and adjust.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Image band */}
      <section className="bg-[#FAFAF8] pb-20 sm:pb-24" aria-label="Our operating idea">
        <div className="container-site">
          <Reveal>
            <figure>
              <div className="overflow-hidden rounded-lg border border-neutral-200 bg-white">
                <Image
                  src="/brand/campaign-infrastructure.png"
                  alt="Illustration of campaign infrastructure: processes, systems and people connected as one operational layer"
                  width={1584}
                  height={396}
                  className="h-auto w-full object-cover"
                  sizes="(min-width: 1280px) 1280px, 100vw"
                />
              </div>
              <figcaption className="mt-4 text-sm text-neutral-500">
                Our operating idea: technology, process and people wired into one dependable layer.
              </figcaption>
            </figure>
          </Reveal>
        </div>
      </section>

      {/* What we believe */}
      <section className="section bg-white" aria-label="What we believe">
        <div className="container-site">
          <SectionHeading
            eyebrow="What we believe"
            title="Four principles we actually operate by"
            description="These aren't wall posters. They decide what we propose, what we decline, and how we report."
          />
          <StaggerGroup className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {BELIEFS.map((belief, index) => (
              <StaggerItem key={belief.title}>
                <div className="flex h-full flex-col border border-neutral-200 bg-white p-7">
                  <p className="font-display text-sm font-semibold tracking-[0.2em] text-[var(--coral)]">
                    {String(index + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-4 font-display text-lg font-semibold tracking-tight text-[var(--ink)]">
                    {belief.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-neutral-600">{belief.description}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* How we engage */}
      <section
        className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white"
        aria-label="How we engage"
      >
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div className="container-site section relative">
          <SectionHeading
            dark
            eyebrow="How we engage"
            title="The same four steps, every time"
            description="A deliberately simple path. You always know what happens next — and what it costs before it happens."
          />
          <StaggerGroup className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
            {ENGAGEMENT.map((step) => (
              <StaggerItem key={step.number} className="border-t border-white/15 pt-6">
                <p className="font-display text-sm font-semibold tracking-[0.2em] text-[var(--coral)]">
                  {step.number}
                </p>
                <h3 className="mt-4 font-display text-xl font-semibold tracking-tight text-white">
                  {step.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-neutral-400">{step.description}</p>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* What we are not */}
      <section className="section bg-[#FAFAF8]" aria-label="What we are not">
        <div className="container-site">
          <SectionHeading
            eyebrow="What we are not"
            title="Set expectations before the first call"
            description="Honest boundaries make better projects. Here's what we are explicitly not."
          />
          <StaggerGroup className="mt-12 border-t border-neutral-200">
            {NOT_THIS.map((item) => (
              <StaggerItem key={item.title}>
                <div className="grid gap-3 border-b border-neutral-200 py-8 sm:grid-cols-[1fr_1.6fr] sm:gap-10">
                  <h3 className="font-display text-xl font-semibold tracking-tight text-[var(--ink)]">
                    {item.title}
                  </h3>
                  <p className="self-center text-base leading-relaxed text-neutral-600">
                    {item.description}
                  </p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
