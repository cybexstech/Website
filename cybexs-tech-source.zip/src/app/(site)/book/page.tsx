import type { Metadata } from "next";
import { CalendarCheck, Check, Clock, Mail } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { Reveal } from "@/components/motion/reveal";
import { ConsultationForm } from "@/components/forms/consultation-form";

export const metadata: Metadata = {
  title: "Book Free Consultation",
  description:
    "Tell us briefly about your business and what you'd like to improve — then pick a time that suits you. Free, 30 minutes, no obligation.",
  alternates: { canonical: "/book" },
};

const COVERAGE = [
  {
    title: "Your current tools and processes",
    description: "Where time is actually lost today — not a generic checklist.",
  },
  {
    title: "Quick wins",
    description: "Improvements you could implement without a large project.",
  },
  {
    title: "Whether we're a fit",
    description: "An honest recommendation — including 'not yet' when that's the truth.",
  },
];

const ASSURANCES = [
  { icon: Clock, label: "30 minutes", detail: "Focused, structured, on video or by phone." },
  { icon: Check, label: "Free, no obligation", detail: "No contract, no pressure, no follow-up sequence." },
  { icon: Mail, label: "One business-day follow-up", detail: "A short written summary after the call." },
];

const HOW_IT_WORKS = [
  { step: "01", title: "Share your details", description: "Two minutes — name, company, what you'd like to improve." },
  { step: "02", title: "Pick a time", description: "Choose a slot that suits you, or we'll schedule directly." },
  { step: "03", title: "Meet for 30 minutes", description: "We review your processes and tools together." },
  { step: "04", title: "Receive a proposal", description: "A focused scope with clear pricing — only if it makes sense." },
];

export default function BookPage() {
  return (
    <>
      <PageHero
        eyebrow="Free consultation"
        title="Book your free consultation."
        description="Tell us briefly about your business and what you'd like to improve — then pick a time that suits you."
        crumbs={[{ name: "Book", href: "/book" }]}
      />

      <section className="section bg-white" aria-label="Consultation booking">
        <div className="container-site grid gap-10 lg:grid-cols-[1fr_1.6fr] lg:gap-16">
          {/* Reassurance column */}
          <aside className="space-y-10">
            <div className="border border-neutral-200 bg-[#FAFAF8] p-8">
              <h2 className="font-display text-lg font-semibold tracking-tight text-[var(--ink)]">
                What we&rsquo;ll cover
              </h2>
              <ul className="mt-5 space-y-5">
                {COVERAGE.map((item) => (
                  <li key={item.title} className="flex gap-3">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-[var(--coral)]" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-semibold text-[var(--ink)]">{item.title}</p>
                      <p className="mt-1 text-sm leading-relaxed text-neutral-600">{item.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <ul className="space-y-5">
              {ASSURANCES.map((item) => (
                <li key={item.label} className="flex items-start gap-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center border border-neutral-200">
                    <item.icon className="h-4 w-4 text-[var(--ink)]" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-[var(--ink)]">{item.label}</p>
                    <p className="mt-0.5 text-sm text-neutral-600">{item.detail}</p>
                  </div>
                </li>
              ))}
            </ul>
          </aside>

          {/* Two-step flow */}
          <div className="border border-neutral-200 bg-white p-6 sm:p-10">
            <ConsultationForm />
          </div>
        </div>
      </section>

      {/* How it works strip */}
      <section className="border-t border-neutral-200 bg-[#FAFAF8]" aria-label="How booking works">
        <div className="container-site py-14 sm:py-16">
          <Reveal>
            <p className="eyebrow">After you book</p>
          </Reveal>
          <Reveal delay={0.08}>
            <ol className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {HOW_IT_WORKS.map((item) => (
                <li key={item.step} className="border-t border-neutral-300 pt-5">
                  <p className="font-display text-sm font-semibold tracking-[0.2em] text-[var(--coral)]">
                    {item.step}
                  </p>
                  <h2 className="mt-3 font-display text-base font-semibold tracking-tight text-[var(--ink)]">
                    {item.title}
                  </h2>
                  <p className="mt-1.5 text-sm leading-relaxed text-neutral-600">{item.description}</p>
                </li>
              ))}
            </ol>
          </Reveal>
          <Reveal delay={0.12}>
            <p className="mt-10 flex items-center gap-2 text-sm text-neutral-500">
              <CalendarCheck className="h-4 w-4 text-[var(--coral)]" aria-hidden="true" />
              No preparation needed — come as you are. Reschedule anytime if plans change.
            </p>
          </Reveal>
        </div>
      </section>
    </>
  );
}
