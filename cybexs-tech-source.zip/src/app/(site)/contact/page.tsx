import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Clock, Linkedin } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { CtaSection } from "@/components/site/cta-section";
import { ContactForm } from "@/components/forms/contact-form";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact — Tell Us What's Slowing You Down",
  description:
    "Email business@cybexs.tech or send the contact form. We typically reply within one business day — with questions, or a proposed time for a free consultation.",
  alternates: { canonical: "/contact" },
};

const NEXT_STEPS = [
  {
    title: "We read every message",
    description: "A person on our team reviews it — not an auto-responder.",
  },
  {
    title: "We reply within one business day",
    description:
      "Usually with a few focused questions or a proposed time for a free 30-minute consultation.",
  },
  {
    title: "You decide whether to proceed",
    description:
      "The consultation is free and comes with no obligation. If we're not the right fit, we'll say so.",
  },
];

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Tell us what's slowing you down."
        description="Send a short note about your business and what you'd like to improve. A person — not a funnel — reads it and replies within one business day."
        crumbs={[{ name: "Contact", href: "/contact" }]}
      />

      <section className="section bg-white" aria-label="Contact options">
        <div className="container-site grid gap-10 lg:grid-cols-[1fr_1.5fr] lg:gap-16">
          {/* Info column */}
          <div className="space-y-8">
            <div className="border border-neutral-200 bg-[#FAFAF8] p-8">
              <p className="eyebrow">Direct</p>
              <a
                href={`mailto:${siteConfig.contactEmail}`}
                className="mt-5 inline-flex items-center gap-2 font-display text-xl font-semibold tracking-tight text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 transition-colors hover:text-[var(--coral)] sm:text-2xl"
              >
                {siteConfig.contactEmail}
              </a>
              <p className="mt-4 flex items-start gap-2.5 text-sm leading-relaxed text-neutral-600">
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-[var(--coral)]" aria-hidden="true" />
                We typically reply within one business day.
              </p>
              {siteConfig.linkedinUrl && (
                <a
                  href={siteConfig.linkedinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors hover:text-[var(--coral)]"
                >
                  <Linkedin className="h-4 w-4" aria-hidden="true" />
                  Connect on LinkedIn
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              )}
            </div>

            <div>
              <h2 className="font-display text-lg font-semibold tracking-tight text-[var(--ink)]">
                What happens next
              </h2>
              <ol className="mt-5 space-y-5">
                {NEXT_STEPS.map((step, index) => (
                  <li key={step.title} className="flex gap-4">
                    <span className="font-display text-sm font-semibold text-[var(--coral)]">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-[var(--ink)]">{step.title}</p>
                      <p className="mt-1 text-sm leading-relaxed text-neutral-600">{step.description}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            <p className="text-sm leading-relaxed text-neutral-500">
              Prefer to skip the form?{" "}
              <Link
                href="/book"
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 transition-colors hover:text-[var(--coral)]"
              >
                Book a free consultation
              </Link>{" "}
              and pick a time directly.
            </p>
          </div>

          {/* Form column */}
          <div className="border border-neutral-200 bg-white p-6 sm:p-10">
            <h2 className="font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              Send us a message
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-neutral-600">
              A few details help us route your inquiry to the right person.
            </p>
            <div className="mt-8">
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
