import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { CtaSection } from "@/components/site/cta-section";
import { SectionHeading } from "@/components/site/section-heading";
import { FaqAccordion } from "@/components/site/faq-accordion";
import { JsonLd } from "@/components/site/json-ld";
import { ServiceIcon } from "@/components/site/service-icon";
import { StaggerGroup, StaggerItem, Reveal } from "@/components/motion/reveal";
import { GENERAL_FAQS } from "@/data/faqs";
import { SERVICES } from "@/data/services";

export const metadata: Metadata = {
  title: "FAQs — Straight Answers",
  description:
    "What Cybexs Tech does, how engagements start, pricing, timelines and tools — answered directly. Plus links to each service's detailed FAQs.",
  alternates: { canonical: "/faqs" },
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: GENERAL_FAQS.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: { "@type": "Answer", text: faq.answer },
  })),
};

export default function FaqsPage() {
  return (
    <>
      <JsonLd data={faqJsonLd} />

      <PageHero
        eyebrow="FAQs"
        title="Straight answers."
        description="No sales haze. The questions we hear most, answered the way we'd answer them on a call — including the honest caveats."
        crumbs={[{ name: "FAQs", href: "/faqs" }]}
      />

      {/* General questions */}
      <section className="section bg-white" aria-label="General questions">
        <div className="container-site grid gap-12 lg:grid-cols-[1fr_1.6fr] lg:gap-20">
          <div>
            <SectionHeading
              eyebrow="General"
              title="About Cybexs Tech"
              description="What we do, how we work and what you can expect."
            />
          </div>
          <Reveal>
            <FaqAccordion items={GENERAL_FAQS} />
          </Reveal>
        </div>
      </section>

      {/* Working with us — per-service FAQs */}
      <section className="section bg-[#FAFAF8]" aria-label="Service-specific questions">
        <div className="container-site">
          <SectionHeading
            eyebrow="Working with us"
            title="Questions per service"
            description="Each service page answers the practical questions about that specific engagement — scoping, tools, data handling and delivery."
          />
          <StaggerGroup className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((service) => (
              <StaggerItem key={service.slug}>
                <Link
                  href={`/services/${service.slug}#faqs`}
                  className="group flex h-full flex-col justify-between border border-neutral-200 bg-white p-7 transition-all duration-300 hover:-translate-y-1 hover:border-neutral-300 hover:shadow-[0_20px_50px_-24px_rgba(10,10,10,0.25)]"
                >
                  <div>
                    <p className="flex h-11 w-11 items-center justify-center border border-neutral-200">
                      <ServiceIcon icon={service.icon} className="h-5 w-5 text-[var(--ink)]" />
                    </p>
                    <h3 className="mt-6 font-display text-lg font-semibold tracking-tight text-[var(--ink)]">
                      {service.name}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-neutral-600">{service.tagline}</p>
                  </div>
                  <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors group-hover:text-[var(--coral)]">
                    Read service FAQs
                    <ArrowUpRight
                      className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                      aria-hidden="true"
                    />
                  </span>
                </Link>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
