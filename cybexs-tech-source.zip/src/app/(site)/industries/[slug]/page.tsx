import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { SectionHeading } from "@/components/site/section-heading";
import { FaqAccordion } from "@/components/site/faq-accordion";
import { JsonLd } from "@/components/site/json-ld";
import { CtaSection } from "@/components/site/cta-section";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { INDUSTRIES, getIndustry } from "@/data/industries";
import { absoluteUrl } from "@/lib/site";

type Params = { slug: string };

const SEO_TITLES: Record<string, string> = {
  "small-medium-businesses": "SMB Automation & Operations Support",
  startups: "Startup Operations, Pipeline & Web Support",
  manufacturing: "Manufacturing Automation & Document Processing",
  clinics: "Clinic Call Answering & Appointment Automation",
  ecommerce: "E-commerce Support & Store Automation",
  "recruiting-agencies": "Recruiting Agency Automation & Candidate Handling",
  hvac: "HVAC Business Automation & Call Answering",
  "sales-organizations": "Sales Team Automation & Pipeline Support",
};

export function generateStaticParams() {
  return INDUSTRIES.map((industry) => ({ slug: industry.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const industry = getIndustry(slug);
  if (!industry) notFound();
  const seoTitle = SEO_TITLES[industry.slug] ?? `${industry.name} Automation & Support`;
  return {
    title: seoTitle,
    description: industry.summary,
    alternates: { canonical: `/industries/${industry.slug}` },
  };
}

/** Industry solutions use combined paths ("ai-automation/document-data-processing") — resolve them. */
function solutionHref(serviceSlug: string): string {
  const [servicePart, subPart] = serviceSlug.split("/");
  return subPart ? `/services/${servicePart}/${subPart}` : `/services/${servicePart}`;
}

export default async function IndustryDetailPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const industry = getIndustry(slug);
  if (!industry) notFound();

  const otherIndustries = INDUSTRIES.filter((i) => i.slug !== industry.slug);

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "WebPage",
          name: industry.name,
          description: industry.summary,
          url: absoluteUrl(`/industries/${industry.slug}`),
        }}
      />

      <PageHero
        crumbs={[
          { name: "Industries", href: "/industries" },
          { name: industry.name, href: `/industries/${industry.slug}` },
        ]}
        eyebrow={industry.group}
        title={industry.headline}
        description={industry.summary}
      >
        <Reveal>
          <Link href="/book" className="btn-accent">
            Book Free Consultation
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </Reveal>
      </PageHero>

      {/* Challenges */}
      <section className="bg-white">
        <div className="container-site section">
          <SectionHeading
            eyebrow="The reality"
            title="What hurts right now"
            description="The recurring problems we hear from teams like yours — see which ones sound familiar."
          />
          <StaggerGroup className="mt-14 grid gap-6 sm:grid-cols-2 sm:mt-16">
            {industry.challenges.map((challenge, i) => (
              <StaggerItem key={challenge.title}>
                <article className="card-hover flex h-full gap-5 rounded-xl border border-neutral-200 bg-white p-7">
                  <span
                    className="font-display text-4xl font-semibold leading-none tracking-tight text-neutral-200"
                    aria-hidden="true"
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div>
                    <h3 className="text-lg font-semibold tracking-tight text-[var(--ink)]">{challenge.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-neutral-600">{challenge.description}</p>
                  </div>
                </article>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* Solutions */}
      <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white">
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div className="container-site section relative">
          <SectionHeading
            dark
            eyebrow="Our response"
            title="How we address it"
            description="The services we deploy against these problems — combined to fit your operation, not sold as packages."
          />
          <StaggerGroup className="mt-14 border-t border-white/10 sm:mt-16">
            {industry.solutions.map((solution, i) => (
              <StaggerItem key={solution.serviceSlug} className="border-b border-white/10">
                <article className="group grid gap-x-10 gap-y-3 py-8 sm:py-10 lg:grid-cols-12 lg:items-baseline">
                  <div className="lg:col-span-1">
                    <span
                      className="font-display text-4xl font-semibold leading-none tracking-tight text-neutral-700"
                      aria-hidden="true"
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                  </div>
                  <h3 className="lg:col-span-4">
                    <Link
                      href={solutionHref(solution.serviceSlug)}
                      className="font-display text-2xl font-semibold tracking-tight text-white transition-colors hover:text-[var(--coral)] sm:text-3xl"
                    >
                      {solution.service}
                    </Link>
                  </h3>
                  <p className="text-base leading-relaxed text-neutral-400 lg:col-span-6">
                    {solution.description}
                  </p>
                  <div className="hidden lg:col-span-1 lg:flex lg:justify-end">
                    <ArrowUpRight
                      className="h-5 w-5 text-neutral-600 transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-[var(--coral)]"
                      aria-hidden="true"
                    />
                  </div>
                </article>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* First step */}
      <section className="bg-white">
        <div className="container-site section">
          <Reveal>
            <div className="rounded-xl border-2 border-[var(--ink)] bg-white p-8 sm:p-12">
              <p className="eyebrow">First step</p>
              <h2 className="display-3 mt-4 max-w-2xl text-[var(--ink)]">Start with one conversation.</h2>
              <p className="mt-4 max-w-2xl text-lg leading-relaxed text-neutral-600">{industry.firstStep}</p>
              <Link href="/book" className="btn-accent mt-8">
                Book Free Consultation
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FAQ */}
      <section className="border-t border-neutral-100 bg-white">
        <div className="container-site section">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <SectionHeading
                eyebrow="FAQ"
                title={`${industry.name}: common questions`}
                description="What teams in this sector ask before getting started."
              />
            </div>
            <div className="lg:col-span-8">
              <Reveal>
                <FaqAccordion items={industry.faqs} />
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Other industries */}
      <section className="bg-[#FAFAF8]">
        <div className="container-site py-16 sm:py-20">
          <Reveal>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-neutral-500">Other industries</p>
            <ul className="mt-5 flex flex-wrap gap-2">
              {otherIndustries.map((other) => (
                <li key={other.slug}>
                  <Link
                    href={`/industries/${other.slug}`}
                    className="inline-block rounded-full border border-neutral-200 bg-white px-3.5 py-1.5 text-xs font-medium text-neutral-600 transition-colors hover:border-[var(--coral)] hover:text-[var(--coral)]"
                  >
                    {other.name}
                  </Link>
                </li>
              ))}
            </ul>
            <Link
              href="/industries"
              className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors hover:text-[var(--coral)]"
            >
              All industries
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </Reveal>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
