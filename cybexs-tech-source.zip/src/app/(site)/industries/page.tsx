import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { SectionHeading } from "@/components/site/section-heading";
import { IndustryIcon } from "@/components/site/industry-icon";
import { CtaSection } from "@/components/site/cta-section";
import { StaggerGroup, StaggerItem, Reveal } from "@/components/motion/reveal";
import { INDUSTRIES } from "@/data/industries";

export const metadata: Metadata = {
  title: "Industries — Sector-Specific Automation & Support",
  description:
    "From HVAC and clinics to e-commerce and manufacturing: see how Cybexs Tech combines AI automation, support teams and web delivery around the problems your industry actually has.",
  alternates: { canonical: "/industries" },
};

export default function IndustriesOverviewPage() {
  return (
    <>
      <PageHero
        crumbs={[{ name: "Industries", href: "/industries" }]}
        eyebrow="Industries"
        title="Built around the problems your industry actually has."
        description="We organize our work by the problems we see repeated in specific sectors — missed calls, stalled follow-up, document backlogs, disconnected tools. Find your situation below."
      />

      {/* Industry grid */}
      <section className="bg-white">
        <div className="container-site section">
          <SectionHeading
            eyebrow="Who we work with"
            title="Business types and industry verticals."
            description="Each page below maps the recurring pain points we hear in that sector to the specific services that address them."
          />
          <StaggerGroup className="mt-14 grid gap-6 sm:grid-cols-2 sm:mt-16 lg:grid-cols-3">
            {INDUSTRIES.map((industry) => (
              <StaggerItem key={industry.slug} className="h-full">
                <Link
                  href={`/industries/${industry.slug}`}
                  className="card-hover group flex h-full flex-col rounded-xl border border-neutral-200 bg-white p-7"
                >
                  <div className="flex items-start justify-between">
                    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-[var(--coral)]/10 text-[var(--coral)]">
                      <IndustryIcon icon={industry.icon} className="h-5 w-5" />
                    </span>
                    <ArrowUpRight
                      className="h-5 w-5 text-neutral-300 transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-[var(--coral)]"
                      aria-hidden="true"
                    />
                  </div>
                  <p className="mt-6 text-xs font-semibold uppercase tracking-[0.18em] text-neutral-400">
                    {industry.group}
                  </p>
                  <h3 className="mt-2 text-xl font-semibold tracking-tight text-[var(--ink)]">{industry.name}</h3>
                  <p className="mt-2.5 flex-1 text-sm leading-relaxed text-neutral-600">{industry.headline}</p>
                  <p className="mt-6">
                    <span className="inline-block rounded-full border border-neutral-200 px-3 py-1 text-xs font-medium text-neutral-500 transition-colors group-hover:border-[var(--coral)] group-hover:text-[var(--coral)]">
                      {industry.challenges.length} challenges we address
                    </span>
                  </p>
                </Link>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* Don't see your industry? */}
      <section className="bg-[#FAFAF8]">
        <div className="container-site section">
          <div className="mx-auto max-w-3xl text-center">
            <SectionHeading
              align="center"
              eyebrow="Any sector"
              title="Don't see your industry?"
              description="We work across industries with repetitive processes, follow-up gaps or disconnected systems. If that sounds like your business, the fit is probably better than the label suggests."
            />
            <Reveal delay={0.1} className="mt-10">
              <Link href="/book" className="btn-accent">
                Book Free Consultation
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
