import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Article } from "@prisma/client";
import { format } from "date-fns";
import { db } from "@/lib/db";
import { absoluteUrl, siteConfig } from "@/lib/site";
import { Breadcrumbs, type Crumb } from "@/components/site/breadcrumbs";
import { JsonLd } from "@/components/site/json-ld";
import { Reveal } from "@/components/motion/reveal";
import { SERVICES } from "@/data/services";
import { InsightProse } from "@/components/site/insight-prose";
import { CategoryPill, InsightCard, type InsightTeaser } from "@/components/site/insight-card";

type ArticlePageProps = { params: Promise<{ slug: string }> };

// Most relevant service page per article category, for the closing CTA.
const CATEGORY_SERVICE_SLUG: Record<string, string> = {
  "AI Automation": "ai-automation",
  "Voice AI": "ai-voice-agents",
  "Lead Generation": "sales-lead-generation",
  "Customer Support": "bpo-customer-support",
  Integrations: "technical-services-integrations",
  "Web Development": "website-development",
};

async function getPublishedArticle(slug: string): Promise<Article | null> {
  try {
    return await db.article.findFirst({ where: { slug, status: "PUBLISHED" } });
  } catch {
    return null;
  }
}

/** Two related published articles: same category first, any category as fallback. */
async function getRelated(article: Article): Promise<Article[]> {
  try {
    const sameCategory = await db.article.findMany({
      where: { status: "PUBLISHED", category: article.category, slug: { not: article.slug } },
      orderBy: { publishedAt: "desc" },
      take: 2,
    });
    if (sameCategory.length >= 2) return sameCategory;
    const excluded = [article.slug, ...sameCategory.map((a) => a.slug)];
    const filler = await db.article.findMany({
      where: { status: "PUBLISHED", slug: { notIn: excluded } },
      orderBy: { publishedAt: "desc" },
      take: 2 - sameCategory.length,
    });
    return [...sameCategory, ...filler];
  } catch {
    return [];
  }
}

export async function generateStaticParams() {
  try {
    const articles = await db.article.findMany({
      where: { status: "PUBLISHED" },
      select: { slug: true },
    });
    return articles.map((a) => ({ slug: a.slug }));
  } catch {
    return [];
  }
}

export async function generateMetadata({ params }: ArticlePageProps): Promise<Metadata> {
  const { slug } = await params;
  const article = await getPublishedArticle(slug);

  // Not found or draft: basic fallback metadata (the page itself renders 404).
  if (!article) {
    return {
      title: { absolute: "Insights | Cybexs Tech" },
      description: "Practical thinking on automation, operations and growth from the Cybexs Tech team.",
    };
  }

  const title = article.seoTitle ?? article.title;
  const description = article.seoDescription ?? article.excerpt;

  return {
    title: { absolute: `${title} | Cybexs Tech` },
    description,
    alternates: { canonical: `/insights/${article.slug}` },
    openGraph: {
      title,
      description,
      url: absoluteUrl(`/insights/${article.slug}`),
      type: "article",
      siteName: siteConfig.name,
      publishedTime: article.publishedAt?.toISOString() ?? undefined,
      authors: [siteConfig.legalName],
    },
  };
}

function toTeaser(a: Article): InsightTeaser {
  return {
    slug: a.slug,
    title: a.title,
    excerpt: a.excerpt,
    category: a.category,
    readMinutes: a.readMinutes,
    publishedAt: a.publishedAt,
  };
}

export default async function ArticlePage({ params }: ArticlePageProps) {
  const { slug } = await params;
  const article = await getPublishedArticle(slug);

  // Drafts and missing slugs must 404 — drafts are never publicly rendered.
  if (!article) notFound();

  const related = (await getRelated(article)).map(toTeaser);
  const dateIso = article.publishedAt?.toISOString() ?? null;
  const dateLabel = article.publishedAt ? format(article.publishedAt, "MMMM d, yyyy") : null;

  const serviceSlug = CATEGORY_SERVICE_SLUG[article.category] ?? "ai-automation";
  const serviceName = SERVICES.find((s) => s.slug === serviceSlug)?.name ?? "our services";

  const crumbs: Crumb[] = [
    { name: "Insights", href: "/insights" },
    { name: article.title, href: `/insights/${article.slug}` },
  ];

  return (
    <>
      {/* BlogPosting structured data. BreadcrumbList is emitted by <Breadcrumbs /> below. */}
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          headline: article.title,
          description: article.seoDescription ?? article.excerpt,
          datePublished: dateIso ?? undefined,
          dateModified: article.updatedAt.toISOString(),
          author: { "@type": "Organization", name: "Cybexs Tech Team" },
          publisher: { "@type": "Organization", name: siteConfig.name, url: siteConfig.url },
          mainEntityOfPage: { "@type": "WebPage", "@id": absoluteUrl(`/insights/${article.slug}`) },
          articleSection: article.category,
          keywords: article.tags,
        }}
      />

      {/* Article header — light band */}
      <section className="bg-[#FAFAF8] pb-14 pt-32 sm:pt-40">
        <div className="container-site">
          <Reveal>
            <Breadcrumbs items={crumbs} />
            <div className="mx-auto max-w-3xl">
              <CategoryPill category={article.category} className="mt-10" />
              <h1 className="mt-5 font-display text-4xl font-semibold leading-[1.06] tracking-[-0.03em] text-[var(--ink)] sm:text-5xl">
                {article.title}
              </h1>
              <p className="lede mt-6">{article.excerpt}</p>
              <div className="mt-8 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-sm text-neutral-500">
                <span className="font-semibold text-[var(--ink)]">{article.author}</span>
                {dateLabel && (
                  <>
                    <span aria-hidden="true">·</span>
                    <time dateTime={dateIso ?? undefined}>{dateLabel}</time>
                  </>
                )}
                <span aria-hidden="true">·</span>
                <span>{article.readMinutes} min read</span>
              </div>
              <hr className="mt-10 border-neutral-200" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* Article body */}
      <article className="bg-white py-14 sm:py-16">
        <div className="container-site">
          <InsightProse content={article.content} />
        </div>
      </article>

      {/* Related reading */}
      {related.length > 0 && (
        <section className="bg-[#FAFAF8] py-16 sm:py-20" aria-labelledby="related-reading">
          <div className="container-site">
            <Reveal>
              <h2
                id="related-reading"
                className="font-display text-2xl font-semibold tracking-[-0.02em] text-[var(--ink)] sm:text-3xl"
              >
                Related reading
              </h2>
            </Reveal>
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              {related.map((a, i) => (
                <Reveal key={a.slug} delay={i * 0.08}>
                  <InsightCard article={a} />
                </Reveal>
              ))}
            </div>
            <Reveal className="mt-8">
              <Link
                href="/insights"
                className="link-underline text-sm"
              >
                Browse all articles
              </Link>
            </Reveal>
          </div>
        </section>
      )}

      {/* CTA band */}
      <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] py-20 text-white sm:py-24">
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div
          className="absolute -left-24 -top-24 h-80 w-80 rounded-full opacity-15 blur-[110px]"
          style={{ background: "radial-gradient(circle, #FF3B30 0%, transparent 70%)" }}
          aria-hidden="true"
        />
        <div className="container-site relative">
          <Reveal className="max-w-3xl">
            <p className="eyebrow !text-neutral-400">Free consultation</p>
            <h2 className="display-3 mt-4">Want this implemented in your business?</h2>
            <p className="lede mt-5 !text-neutral-400">
              Book a free consultation. We will look at how this applies to your current processes
              and tools, and point you to the changes with the best effort-to-impact ratio.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <Link href="/book" className="btn-accent">
                Book Free Consultation
              </Link>
              <Link href={`/services/${serviceSlug}`} className="btn-outline-light">
                Explore {serviceName}
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
