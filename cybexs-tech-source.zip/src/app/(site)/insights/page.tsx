import type { Metadata } from "next";
import Link from "next/link";
import type { Article } from "@prisma/client";
import { db } from "@/lib/db";
import { absoluteUrl, siteConfig } from "@/lib/site";
import { PageHero } from "@/components/site/page-hero";
import { JsonLd } from "@/components/site/json-ld";
import { CtaSection } from "@/components/site/cta-section";
import { Reveal } from "@/components/motion/reveal";
import { SERVICES } from "@/data/services";
import { InsightCard, InsightRow, type InsightTeaser } from "@/components/site/insight-card";

export const metadata: Metadata = {
  // Root layout template appends "| Cybexs Tech".
  title: "Insights — Operations, Automation & Growth",
  description:
    "Field notes from implementing automation, support and web projects — what works, what doesn't, and how to decide. Practical articles for business owners.",
  alternates: { canonical: "/insights" },
  openGraph: {
    title: "Insights — Operations, Automation & Growth | Cybexs Tech",
    description:
      "Field notes from implementing automation, support and web projects — what works, what doesn't, and how to decide.",
    url: absoluteUrl("/insights"),
    type: "website",
    siteName: siteConfig.name,
  },
};

const INSIGHTS_DESCRIPTION =
  "Field notes from implementing automation, support and web projects — what works, what doesn't, and how to decide.";

function toTeaser(a: Article): InsightTeaser {
  return {
    slug: a.slug,
    title: a.title,
    excerpt: a.excerpt,
    category: a.category,
    readMinutes: a.readMinutes,
    publishedAt: a.publishedAt,
  };
}

export default async function InsightsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string | string[] }>;
}) {
  const params = await searchParams;
  const rawCategory = Array.isArray(params.category) ? params.category[0] : params.category;

  // Never crash the page if the database is unavailable.
  let articles: Article[] = [];
  try {
    articles = await db.article.findMany({
      where: { status: "PUBLISHED" },
      orderBy: { publishedAt: "desc" },
    });
  } catch {
    articles = [];
  }

  const categories = [...new Set(articles.map((a) => a.category))];
  const activeCategory = rawCategory && categories.includes(rawCategory) ? rawCategory : null;
  const visible = activeCategory ? articles.filter((a) => a.category === activeCategory) : articles;

  const [featured, ...rest] = visible.map(toTeaser);

  return (
    <>
      <PageHero
        eyebrow="Insights"
        title="Practical thinking on automation and operations."
        description={INSIGHTS_DESCRIPTION}
        crumbs={[{ name: "Insights", href: "/insights" }]}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Blog",
          name: "Cybexs Tech Insights",
          url: absoluteUrl("/insights"),
          description: INSIGHTS_DESCRIPTION,
          publisher: { "@type": "Organization", name: siteConfig.name, url: siteConfig.url },
        }}
      />

      <section className="section bg-white">
        <div className="container-site">
          {articles.length > 0 && (
            <Reveal>
              <nav aria-label="Filter articles by category" className="flex flex-wrap gap-2">
                <FilterChip href="/insights" active={!activeCategory}>
                  All
                </FilterChip>
                {categories.map((c) => (
                  <FilterChip
                    key={c}
                    href={`/insights?category=${encodeURIComponent(c)}`}
                    active={activeCategory === c}
                  >
                    {c}
                  </FilterChip>
                ))}
              </nav>
            </Reveal>
          )}

          {visible.length === 0 ? (
            <Reveal className="mt-12">
              <div className="mx-auto max-w-2xl rounded-3xl border border-dashed border-neutral-300 bg-[#FAFAF8] p-10 text-center sm:p-14">
                <p className="eyebrow justify-center">Insights</p>
                <h2 className="mt-4 font-display text-2xl font-semibold tracking-[-0.02em] text-[var(--ink)] sm:text-3xl">
                  First articles are being finalized.
                </h2>
                <p className="mx-auto mt-4 max-w-md leading-relaxed text-neutral-600">
                  We are putting the finishing touches on our first pieces. In the meantime, you can
                  learn how we work on the service pages — or book a free consultation directly.
                </p>
                <Link href="/book" className="btn-dark mt-8">
                  Book Free Consultation
                </Link>
              </div>
            </Reveal>
          ) : (
            <>
              {featured && (
                <Reveal className="mt-12">
                  <InsightCard article={featured} priority />
                </Reveal>
              )}
              {rest.length > 0 && (
                <ul className="mt-8 divide-y divide-neutral-200 border-t border-neutral-200">
                  {rest.map((article, i) => (
                    <InsightRow key={article.slug} article={article} index={i} />
                  ))}
                </ul>
              )}
            </>
          )}

          <Reveal className="mt-20">
            <div className="rounded-3xl bg-[#FAFAF8] p-8 sm:p-10">
              <p className="eyebrow">Explore by topic</p>
              <h2 className="mt-3 font-display text-2xl font-semibold tracking-[-0.02em] text-[var(--ink)]">
                Services these articles come from
              </h2>
              <ul className="mt-6 flex flex-wrap gap-2.5">
                {SERVICES.map((s) => (
                  <li key={s.slug}>
                    <Link
                      href={`/services/${s.slug}`}
                      className="inline-flex items-center rounded-full border border-neutral-200 bg-white px-4 py-2 text-sm font-medium text-neutral-700 transition-all hover:border-[var(--ink)] hover:bg-[var(--ink)] hover:text-white"
                    >
                      {s.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </section>

      <CtaSection />
    </>
  );
}

function FilterChip({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      aria-current={active ? "true" : undefined}
      className={`rounded-full border px-4 py-2 text-sm font-medium transition-all ${
        active
          ? "border-[var(--ink)] bg-[var(--ink)] text-white"
          : "border-neutral-200 bg-white text-neutral-600 hover:border-[var(--ink)] hover:text-[var(--ink)]"
      }`}
    >
      {children}
    </Link>
  );
}
