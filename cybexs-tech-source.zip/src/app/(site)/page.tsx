import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { HomeHero } from "@/components/site/home-hero";
import { CtaSection } from "@/components/site/cta-section";
import { SectionHeading } from "@/components/site/section-heading";
import { FaqAccordion } from "@/components/site/faq-accordion";
import { JsonLd } from "@/components/site/json-ld";
import { ServiceIcon } from "@/components/site/service-icon";
import { StaggerGroup, StaggerItem, Reveal } from "@/components/motion/reveal";
import { SERVICES } from "@/data/services";
import { INDUSTRIES } from "@/data/industries";
import { DEMO_PROJECTS } from "@/data/demos";
import { GENERAL_FAQS } from "@/data/faqs";
import { db } from "@/lib/db";
import { siteConfig } from "@/lib/site";
import { TrackedLink } from "@/components/site/tracked-link";

export const metadata: Metadata = {
  title: { absolute: "Cybexs Tech — AI Automation, Business Services & Web Development" },
  description: siteConfig.description,
  alternates: { canonical: "/" },
};

const OUTCOMES = [
  {
    number: "01",
    title: "Automate repetitive work",
    description:
      "We find the manual processes that quietly consume your team's week — data entry, document handling, routine inquiries, follow-ups — and put them on reliable, monitored automation.",
  },
  {
    number: "02",
    title: "Support business growth",
    description:
      "Sales development, lead reactivation and customer-support capacity that flexes with demand, so growth stops depending on whoever happens to have spare hours.",
  },
  {
    number: "03",
    title: "Build better digital experiences",
    description:
      "Websites and internal tools that are fast, clear and easy to operate — designed to turn attention into conversations and make daily work simpler.",
  },
];

const ENGAGEMENT_STEPS = [
  {
    number: "01",
    title: "Free consultation",
    description:
      "Thirty minutes to understand your processes, tools and goals — and an honest read on where we can help.",
  },
  {
    number: "02",
    title: "Focused proposal",
    description:
      "A concrete scope with clear deliverables, timeline and pricing. No generic decks, no surprises.",
  },
  {
    number: "03",
    title: "Implementation & delivery",
    description:
      "We build, integrate and operate — keeping you updated in plain language throughout.",
  },
  {
    number: "04",
    title: "Ongoing support",
    description:
      "Documentation and training as standard, with optional ongoing improvement plans. You own everything we build.",
  },
];

const ARTICLE_DATE_FORMAT = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" });

type TeaserArticle = { slug: string; title: string; category: string; publishedAt: Date | null; createdAt: Date };

async function getLatestArticles(): Promise<TeaserArticle[]> {
  try {
    return await db.article.findMany({
      where: { status: "PUBLISHED" },
      orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
      take: 3,
      select: { slug: true, title: true, category: true, publishedAt: true, createdAt: true },
    });
  } catch {
    // Database unavailable — the homepage must still render.
    return [];
  }
}

export default async function HomePage() {
  const latestArticles = await getLatestArticles();

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: siteConfig.name,
    url: siteConfig.url,
    description: siteConfig.description,
    email: siteConfig.contactEmail,
  };

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: siteConfig.name,
    url: siteConfig.url,
  };

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@graph": [organizationJsonLd, websiteJsonLd],
        }}
      />

      <HomeHero />

      {/* Outcomes — numbered editorial rows */}
      <section className="section bg-white" aria-label="Outcomes">
        <div className="container-site">
          <SectionHeading
            eyebrow="Outcomes"
            title="What changes when you work with us"
            description="Three shifts our clients hire us for. Everything we deliver traces back to one of them."
          />
          <StaggerGroup className="mt-14 border-t border-neutral-200">
            {OUTCOMES.map((outcome) => (
              <StaggerItem key={outcome.number}>
                <div className="grid gap-4 border-b border-neutral-200 py-10 sm:py-12 lg:grid-cols-[110px_1fr_1.2fr] lg:gap-10">
                  <p className="font-display text-5xl font-semibold leading-none tracking-tight text-neutral-200 sm:text-6xl">
                    {outcome.number}
                  </p>
                  <h3 className="display-3 self-center">
                    {outcome.title}
                  </h3>
                  <p className="self-center text-base leading-relaxed text-neutral-600 sm:text-lg">
                    {outcome.description}
                  </p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* Services — featured first card + six standard cards */}
      <section className="section bg-[#FAFAF8]" aria-label="Services">
        <div className="container-site">
          <div className="flex flex-wrap items-end justify-between gap-8">
            <SectionHeading
              eyebrow="Services"
              title="Seven ways we take work off your plate"
              description="Start with one. Combine as you grow. Every service is delivered by our own team — technology and people working together."
            />
            <Reveal className="hidden lg:block">
              <Link href="/services" className="btn-outline">
                Explore all services
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>

          <StaggerGroup className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((service, index) =>
              index === 0 ? (
                <StaggerItem key={service.slug} className="sm:col-span-2">
                  <Link
                    href={`/services/${service.slug}`}
                    className="group relative flex h-full flex-col justify-between overflow-hidden bg-[var(--ink)] p-8 text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_20px_50px_-24px_rgba(10,10,10,0.25)] sm:p-10"
                  >
                    <div className="grid-lines-dark absolute inset-0 opacity-70" aria-hidden="true" />
                    <div className="relative">
                      <p className="flex h-12 w-12 items-center justify-center border border-white/20">
                        <ServiceIcon icon={service.icon} className="h-5 w-5 text-white" />
                      </p>
                      <h3 className="display-3 mt-8 text-white">{service.name}</h3>
                      <p className="mt-4 max-w-lg text-base leading-relaxed text-neutral-400">{service.intro}</p>
                    </div>
                    <span className="relative mt-10 inline-flex items-center gap-2 text-sm font-semibold text-white">
                      Explore {service.name}
                      <ArrowRight
                        className="h-4 w-4 text-[var(--coral)] transition-transform duration-300 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </span>
                  </Link>
                </StaggerItem>
              ) : (
                <StaggerItem key={service.slug}>
                  <Link
                    href={`/services/${service.slug}`}
                    className="group flex h-full flex-col justify-between border border-neutral-200 bg-white p-7 transition-all duration-300 hover:-translate-y-1 hover:border-neutral-300 hover:shadow-[0_20px_50px_-24px_rgba(10,10,10,0.25)]"
                  >
                    <div>
                      <p className="flex h-11 w-11 items-center justify-center border border-neutral-200">
                        <ServiceIcon icon={service.icon} className="h-5 w-5 text-[var(--ink)]" />
                      </p>
                      <h3 className="mt-6 font-display text-lg font-semibold tracking-tight text-[var(--ink)]">
                        {service.name}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-neutral-600">{service.tagline}</p>
                    </div>
                    <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors group-hover:text-[var(--coral)]">
                      View service
                      <ArrowRight
                        className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </span>
                  </Link>
                </StaggerItem>
              )
            )}
          </StaggerGroup>

          <Reveal className="mt-10 lg:hidden">
            <Link href="/services" className="btn-outline w-full sm:w-auto">
              Explore all services
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* How engagement works — dark timeline */}
      <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white" aria-label="How engagement works">
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div className="container-site section relative">
          <SectionHeading
            dark
            eyebrow="How it works"
            title="From first call to running system"
            description="A deliberately simple engagement path. You always know what happens next and what it costs before it happens."
          />
          <StaggerGroup className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
            {ENGAGEMENT_STEPS.map((step) => (
              <StaggerItem key={step.number} className="border-t border-white/15 pt-6">
                <p className="font-display text-sm font-semibold tracking-[0.2em] text-[var(--coral)]">{step.number}</p>
                <h3 className="mt-4 font-display text-xl font-semibold tracking-tight text-white">{step.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-neutral-400">{step.description}</p>
              </StaggerItem>
            ))}
          </StaggerGroup>
          <Reveal className="mt-14">
            <TrackedLink
              href="/book"
              event="consultation_cta_clicked"
              props={{ location: "home_process" }}
              className="btn-accent"
            >
              Book Free Consultation
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </TrackedLink>
          </Reveal>
        </div>
      </section>

      {/* Industries — pill cloud */}
      <section className="section bg-white" aria-label="Industries">
        <div className="container-site">
          <SectionHeading
            eyebrow="Industries"
            title="Built for businesses like yours"
            description="The same delivery system, adapted to the realities of your industry — from manufacturing documents to clinic phone lines."
          />
          <Reveal className="mt-10 flex flex-wrap gap-3">
            {INDUSTRIES.map((industry) => (
              <Link
                key={industry.slug}
                href={`/industries/${industry.slug}`}
                className="rounded-full border border-neutral-300 bg-white px-5 py-2.5 text-sm font-medium text-neutral-700 transition-all hover:border-[var(--ink)] hover:bg-[var(--ink)] hover:text-white"
              >
                {industry.name}
              </Link>
            ))}
            <Link
              href="/industries"
              className="inline-flex items-center gap-1.5 rounded-full px-5 py-2.5 text-sm font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 transition-colors hover:text-[var(--coral)]"
            >
              All industries
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Selected work — concept demos, transparently labeled */}
      <section className="section bg-[#FAFAF8]" aria-label="Selected work — concept demos">
        <div className="container-site">
          <div className="flex flex-wrap items-end justify-between gap-8">
            <div>
              <SectionHeading
                eyebrow="Selected Concepts — Demo Projects"
                title="Work that shows our craft"
              />
              <Reveal className="mt-4 max-w-xl border-l-2 border-[var(--coral)] pl-4 text-sm leading-relaxed text-neutral-500">
                Fictional brands built by our team to demonstrate our craft. Not client work.
              </Reveal>
            </div>
            <Reveal className="hidden lg:block">
              <Link href="/work" className="btn-outline">
                View all work
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>

          <StaggerGroup className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {DEMO_PROJECTS.slice(0, 3).map((demo) => (
              <StaggerItem key={demo.slug}>
                <TrackedLink
                  href={demo.href}
                  event="demo_opened"
                  props={{ demo: demo.slug }}
                  className="group block h-full border border-neutral-200 bg-white transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_20px_50px_-24px_rgba(10,10,10,0.25)]"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-neutral-100">
                    <Image
                      src={demo.image}
                      alt={`${demo.brand} — ${demo.title} (fictional concept project)`}
                      fill
                      sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                    />
                  </div>
                  <div className="p-6">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-neutral-500">
                      {demo.category} · {demo.year}
                    </p>
                    <h3 className="mt-3 font-display text-xl font-semibold tracking-tight text-[var(--ink)]">
                      {demo.brand}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-neutral-600">{demo.description}</p>
                    <span className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors group-hover:text-[var(--coral)]">
                      Explore concept
                      <ArrowUpRight
                        className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                        aria-hidden="true"
                      />
                    </span>
                  </div>
                </TrackedLink>
              </StaggerItem>
            ))}
          </StaggerGroup>

          <Reveal className="mt-10 lg:hidden">
            <Link href="/work" className="btn-outline w-full sm:w-auto">
              View all work
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Insights teaser — hidden until articles exist */}
      {latestArticles.length > 0 && (
        <section className="section bg-white" aria-label="Latest insights">
          <div className="container-site">
            <div className="flex flex-wrap items-end justify-between gap-8">
              <SectionHeading
                eyebrow="Insights"
                title="Notes from the field"
                description="What we learn building automations, support teams and websites — written down without the fluff."
              />
              <Reveal className="hidden lg:block">
                <Link
                  href="/insights"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 transition-colors hover:text-[var(--coral)]"
                >
                  All insights
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </Reveal>
            </div>
            <div className="mt-12 border-t border-neutral-200">
              {latestArticles.map((article) => (
                <Reveal key={article.slug}>
                  <Link
                    href={`/insights/${article.slug}`}
                    className="group grid gap-2 border-b border-neutral-200 py-7 transition-colors sm:grid-cols-[170px_1fr_auto] sm:items-center sm:gap-8"
                  >
                    <p className="text-sm text-neutral-500">
                      <time dateTime={(article.publishedAt ?? article.createdAt).toISOString()}>
                        {ARTICLE_DATE_FORMAT.format(article.publishedAt ?? article.createdAt)}
                      </time>
                      <span className="mx-2 text-neutral-300" aria-hidden="true">
                        /
                      </span>
                      <span className="font-medium text-neutral-600">{article.category}</span>
                    </p>
                    <h3 className="font-display text-xl font-semibold tracking-tight text-[var(--ink)] transition-colors group-hover:text-[var(--coral)] sm:text-2xl">
                      {article.title}
                    </h3>
                    <ArrowRight
                      className="hidden h-5 w-5 text-neutral-400 transition-all duration-300 group-hover:translate-x-1 group-hover:text-[var(--coral)] sm:block"
                      aria-hidden="true"
                    />
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* FAQ teaser */}
      <section className="section bg-[#FAFAF8]" aria-label="Frequently asked questions">
        <div className="container-site grid gap-12 lg:grid-cols-[1fr_1.5fr] lg:gap-20">
          <div>
            <SectionHeading eyebrow="FAQs" title="Straight answers" />
            <Reveal className="mt-6">
              <p className="text-base leading-relaxed text-neutral-600">
                The questions we hear most — answered the way we'd answer them on a call. Anything missing?
                Ask us directly.
              </p>
              <Link
                href="/faqs"
                className="link-underline mt-6 text-sm"
              >
                View all FAQs
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>
          <Reveal>
            <FaqAccordion items={GENERAL_FAQS.slice(0, 5)} />
          </Reveal>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
