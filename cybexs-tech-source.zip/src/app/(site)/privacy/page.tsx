import type { Metadata } from "next";
import { PageHero } from "@/components/site/page-hero";
import { CtaSection } from "@/components/site/cta-section";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How Cybexs Tech collects, uses, stores and protects the information you share through this website — and the rights you have over it.",
  alternates: { canonical: "/privacy" },
};

const LAST_UPDATED = new Date().toLocaleDateString("en-US", {
  year: "numeric",
  month: "long",
  day: "numeric",
});

function EditorNote() {
  return (
    <aside
      role="note"
      className="border border-neutral-300 border-l-4 border-l-[var(--coral)] bg-[#FAFAF8] p-5 text-sm leading-relaxed text-neutral-600"
    >
      <strong className="font-semibold text-[var(--ink)]">Editor&rsquo;s note:</strong> This document
      reflects the website&rsquo;s implemented functionality. Jurisdiction-specific clauses (company
      registration, governing law) require company input and professional legal review.
    </aside>
  );
}

export default function PrivacyPage() {
  return (
    <>
      <PageHero
        eyebrow="Legal"
        title="Privacy Policy"
        description={`How we collect, use and protect the information you share with us. Last updated ${LAST_UPDATED}.`}
        crumbs={[{ name: "Privacy Policy", href: "/privacy" }]}
      />

      <section className="section bg-white" aria-label="Privacy policy content">
        <div className="container-site">
          <div className="max-w-3xl space-y-4 text-neutral-600">
            <EditorNote />

            <p className="text-lg leading-relaxed">
              This policy explains what Cybexs Tech does — and does not do — with personal information
              collected through this website. We wrote it to be readable, and we keep it aligned with
              what the site actually implements.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              1. Who we are
            </h2>
            <p className="leading-relaxed">
              Cybexs Tech provides AI automation, business services, technical integrations and website
              development. For questions about this policy or your data, contact us at{" "}
              <a
                href={`mailto:${siteConfig.contactEmail}`}
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                {siteConfig.contactEmail}
              </a>
              .
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              2. What we collect
            </h2>
            <p className="leading-relaxed">We collect information only when you submit it to us:</p>
            <ul className="list-disc space-y-2 pl-6 leading-relaxed">
              <li>
                <strong className="text-[var(--ink)]">Consultation requests</strong> (via the booking
                form): your name, work email, company name, optional company website and the service
                area you are interested in.
              </li>
              <li>
                <strong className="text-[var(--ink)]">Contact form messages</strong>: the same details
                plus the message you write.
              </li>
              <li>
                <strong className="text-[var(--ink)]">Scheduling data</strong> (when online scheduling is
                used): handled by our scheduling provider, see section 6.
              </li>
            </ul>
            <p className="leading-relaxed">
              We do not collect payment details through this website, and we do not run advertising
              trackers on it.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              3. Why we use your information
            </h2>
            <ul className="list-disc space-y-2 pl-6 leading-relaxed">
              <li>To respond to your inquiry and prepare for a consultation you requested.</li>
              <li>To deliver services you engage us for, including project communication.</li>
              <li>To keep an internal record of inquiries in our customer-relationship system, so
              nothing you send us gets lost between team members.</li>
            </ul>
            <p className="leading-relaxed">
              We do not use your details for automated profiling, and we do not add you to marketing
              lists without your explicit request.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              4. Where your information is stored
            </h2>
            <p className="leading-relaxed">
              Form submissions are stored in this application&rsquo;s database, which is hosted by our
              infrastructure provider and accessible only to the Cybexs Tech team. Access is limited to
              team members who need it to respond to inquiries and deliver work.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              5. Email notifications
            </h2>
            <p className="leading-relaxed">
              When you submit a form, two emails are generated: a notification to our team, and an
              acknowledgement to you confirming we received your inquiry. These are delivered through the
              transactional email provider configured at deployment (currently a Resend-compatible
              provider). If email delivery fails, your submission is still saved and we can still see and
              act on it.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              6. Booking and scheduling
            </h2>
            <p className="leading-relaxed">
              When online scheduling is enabled, the booking step embeds a calendar from{" "}
              <strong className="text-[var(--ink)]">Cal.com</strong>. If you use it, the details you enter
              into that scheduler (name, email, availability choices) are processed by Cal.com under{" "}
              <a
                href="https://cal.com/privacy"
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                Cal.com&rsquo;s privacy policy
              </a>
              . We receive the booking details needed to prepare for the call. Where scheduling is not yet
              enabled, we schedule directly with you by email — nothing extra is collected.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              7. Cookies and analytics
            </h2>
            <p className="leading-relaxed">
              At launch, this website does not set analytics or advertising cookies and does not use
              third-party tracking scripts. If that changes, this policy will be updated and, where
              required, consent will be requested before anything non-essential is set.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              8. Sharing of your information
            </h2>
            <p className="leading-relaxed">
              We do not sell your personal information — to anyone, ever. We share it only with the
              infrastructure and communication providers required to operate this website and respond to
              you (hosting, database, transactional email, scheduling provider), or where we are legally
              required to disclose it.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              9. How long we keep it
            </h2>
            <p className="leading-relaxed">
              Inquiry records are kept while they are relevant to our working relationship and for a
              reasonable period afterwards for accountability. When you ask us to delete your data, we
              remove inquiry records associated with you unless we are legally required to retain
              something specific.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              10. Your rights
            </h2>
            <p className="leading-relaxed">
              You can ask us for a copy of the personal data we hold about you, ask us to correct it, or
              ask us to delete it. Send your request to{" "}
              <a
                href={`mailto:${siteConfig.contactEmail}`}
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                {siteConfig.contactEmail}
              </a>{" "}
              — we respond within one business day and complete requests within a reasonable timeframe.
              Depending on your jurisdiction, additional rights (such as data portability or objection to
              processing) may apply; tell us where you are located and we will honour the applicable
              requirements.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              11. International transfers
            </h2>
            <p className="leading-relaxed">
              Our infrastructure and communication providers may process data in countries other than
              yours. Where that happens, we rely on the providers&rsquo; standard contractual safeguards.
              If your jurisdiction imposes specific transfer requirements, raise them with us and we will
              assess and document how we meet them.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              12. Children
            </h2>
            <p className="leading-relaxed">
              This website is intended for business inquiries from adults. We do not knowingly collect
              personal information from children. If you believe a child has submitted information to us,
              contact us and we will delete it.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              13. Changes to this policy
            </h2>
            <p className="leading-relaxed">
              If our data practices change — for example, if we add analytics or new processors — we will
              update this page and change the &ldquo;last updated&rdquo; date above. Material changes will
              be highlighted on this page.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              14. Contact
            </h2>
            <p className="leading-relaxed">
              Privacy questions, access requests and deletions:{" "}
              <a
                href={`mailto:${siteConfig.contactEmail}`}
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                {siteConfig.contactEmail}
              </a>
              .
            </p>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
