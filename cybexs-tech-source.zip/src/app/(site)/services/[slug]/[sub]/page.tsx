import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ArrowUpRight, Check } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { SectionHeading } from "@/components/site/section-heading";
import { ServiceIcon } from "@/components/site/service-icon";
import { FaqAccordion } from "@/components/site/faq-accordion";
import { JsonLd } from "@/components/site/json-ld";
import { CtaSection } from "@/components/site/cta-section";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { SERVICES, getSubservice, type Service } from "@/data/services";
import { siteConfig, absoluteUrl } from "@/lib/site";

type Params = { slug: string; sub: string };

export function generateStaticParams() {
  return SERVICES.flatMap((service) =>
    service.subservices.map((sub) => ({ slug: service.slug, sub: sub.slug }))
  );
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug, sub } = await params;
  const result = getSubservice(slug, sub);
  if (!result) notFound();
  const { service, sub: subservice } = result;
  return {
    title: `${subservice.name} — ${service.name}`,
    description: subservice.description,
    alternates: { canonical: `/services/${service.slug}/${subservice.slug}` },
  };
}

export default async function SubserviceDetailPage({ params }: { params: Promise<Params> }) {
  const { slug, sub } = await params;
  const result = getSubservice(slug, sub);
  if (!result) notFound();
  const { service, sub: subservice } = result;

  const siblings = service.subservices.filter((s) => s.slug !== subservice.slug);
  const relatedServices = service.relatedSlugs
    .slice(0, 2)
    .map((relatedSlug) => SERVICES.find((s) => s.slug === relatedSlug))
    .filter((s): s is Service => Boolean(s));

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: subservice.name,
          description: subservice.description,
          serviceType: subservice.name,
          url: absoluteUrl(`/services/${service.slug}/${subservice.slug}`),
          provider: { "@type": "Organization", name: siteConfig.name, url: absoluteUrl("/") },
        }}
      />

      <PageHero
        crumbs={[
          { name: "Services", href: "/services" },
          { name: service.name, href: `/services/${service.slug}` },
          { name: subservice.name, href: `/services/${service.slug}/${subservice.slug}` },
        ]}
        eyebrow={service.name}
        title={subservice.name}
        description={subservice.tagline}
      >
        <Reveal>
          <div className="flex flex-wrap items-center gap-4">
            <Link href="/book" className="btn-accent">
              Book Free Consultation
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
            <Link href={`/services/${service.slug}`} className="btn-outline-light">
              Back to {service.shortName}
            </Link>
          </div>
        </Reveal>
      </PageHero>

      {/* Overview + how it works */}
      <section className="bg-white">
        <div className="container-site section">
          <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
            <div className="lg:col-span-6">
              <Reveal>
                <p className="eyebrow">Overview</p>
                <p className="mt-6 max-w-xl text-xl font-medium leading-relaxed tracking-tight text-[var(--ink)] sm:text-2xl">
                  {subservice.description}
                </p>
              </Reveal>
            </div>
            <div className="lg:col-span-6">
              <Reveal delay={0.1}>
                <div className="rounded-xl border border-neutral-200 bg-white p-7 sm:p-9">
                  <h2 className="display-3 text-[var(--ink)]">How it works in practice</h2>
                  <ul className="mt-7 space-y-4">
                    {subservice.bullets.map((bullet) => (
                      <li key={bullet} className="flex items-start gap-3.5">
                        <span
                          className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--coral)] text-white"
                          aria-hidden="true"
                        >
                          <Check className="h-3.5 w-3.5" />
                        </span>
                        <span className="text-base leading-relaxed text-neutral-700">{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Use cases */}
      <section className="bg-[#FAFAF8]">
        <div className="container-site section">
          <SectionHeading
            eyebrow="Use cases"
            title="Scenarios we build for"
            description="Illustrative situations drawn from the kind of work this subservice handles."
          />
          <div className="mt-14 space-y-12 sm:mt-16">
            {subservice.useCases.map((useCase, i) => (
              <Reveal key={useCase} delay={i * 0.06}>
                <figure className="grid gap-5 sm:grid-cols-[auto_1fr] sm:gap-10">
                  <span
                    className="font-display text-5xl font-semibold leading-none tracking-tight text-neutral-300 sm:text-6xl"
                    aria-hidden="true"
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <blockquote className="border-l-2 border-[var(--coral)] pl-6 sm:pl-8">
                    <p className="max-w-3xl font-display text-2xl font-medium leading-snug tracking-tight text-[var(--ink)] sm:text-3xl">
                      {useCase}
                    </p>
                  </blockquote>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Parent service strip + siblings + related services */}
      <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white">
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div className="container-site py-16 sm:py-20 relative">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-2xl">
              <p className="eyebrow !text-neutral-400">Part of {service.name}</p>
              <Link
                href={`/services/${service.slug}`}
                className="group mt-4 inline-flex items-center gap-3.5"
              >
                <span className="text-[var(--coral)]">
                  <ServiceIcon icon={service.icon} className="h-7 w-7" />
                </span>
                <span className="font-display text-2xl font-semibold tracking-tight text-white transition-colors group-hover:text-[var(--coral)] sm:text-3xl">
                  {service.name}
                </span>
                <ArrowUpRight
                  className="h-5 w-5 text-neutral-500 transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-[var(--coral)]"
                  aria-hidden="true"
                />
              </Link>
              <p className="mt-3 text-base leading-relaxed text-neutral-400">{service.tagline}</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <Link href={`/services/${service.slug}`} className="btn-outline-light">
                View service
              </Link>
              <Link href="/book" className="btn-accent">
                Book Free Consultation
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </div>
          </div>

          <div className="mt-12 space-y-8 border-t border-white/10 pt-10">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-neutral-400">
                More under {service.shortName}
              </p>
              <ul className="mt-4 flex flex-wrap gap-2">
                {siblings.map((sibling) => (
                  <li key={sibling.slug}>
                    <Link
                      href={`/services/${service.slug}/${sibling.slug}`}
                      className="inline-block rounded-full border border-white/20 px-3.5 py-1.5 text-xs font-medium text-neutral-300 transition-colors hover:border-white hover:text-white"
                    >
                      {sibling.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            {relatedServices.length > 0 && (
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-neutral-400">
                  Related services
                </p>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {relatedServices.map((relatedService) => (
                    <li key={relatedService.slug}>
                      <Link
                        href={`/services/${relatedService.slug}`}
                        className="inline-block rounded-full border border-white/20 px-3.5 py-1.5 text-xs font-medium text-neutral-300 transition-colors hover:border-white hover:text-white"
                      >
                        {relatedService.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* FAQ from parent service */}
      <section className="bg-white">
        <div className="container-site section">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <SectionHeading
                eyebrow="FAQ"
                title={`Questions about ${service.name}`}
                description="The broader service answers these most often — the same principles apply to this subservice."
              />
            </div>
            <div className="lg:col-span-8">
              <Reveal>
                <FaqAccordion items={service.faqs.slice(0, 3)} />
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
