import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Blocks,
  CalendarCheck,
  CheckCircle2,
  Clock,
  Database,
  FileText,
  Gauge,
  Headphones,
  Keyboard,
  Layers,
  Network,
  PhoneIncoming,
  Puzzle,
  RefreshCcw,
  ShieldCheck,
  Sparkles,
  UserCheck,
  Wallet,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { SectionHeading } from "@/components/site/section-heading";
import { ServiceIcon } from "@/components/site/service-icon";
import { FaqAccordion } from "@/components/site/faq-accordion";
import { JsonLd } from "@/components/site/json-ld";
import { CtaSection } from "@/components/site/cta-section";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { SERVICES, getService, type Service } from "@/data/services";
import { INDUSTRIES } from "@/data/industries";
import { siteConfig, absoluteUrl } from "@/lib/site";

type Params = { slug: string };

const SEO_PITCH: Record<string, string> = {
  "ai-automation": "Automate Repetitive Work",
  "ai-voice-agents": "Answer Every Call",
  "lead-reactivation": "Reopen Dormant Conversations",
  "sales-lead-generation": "Build a Steadier Pipeline",
  "bpo-customer-support": "Dependable Human Support",
  "technical-services-integrations": "Connect Your Business Systems",
  "website-development": "Websites That Work Hard",
};

const OUTCOME_ICONS: Record<string, [LucideIcon, LucideIcon, LucideIcon]> = {
  "ai-automation": [Zap, Clock, Layers],
  "ai-voice-agents": [PhoneIncoming, UserCheck, FileText],
  "lead-reactivation": [RefreshCcw, Database, ShieldCheck],
  "sales-lead-generation": [UserCheck, CalendarCheck, BarChart3],
  "bpo-customer-support": [Headphones, Wallet, BadgeCheck],
  "technical-services-integrations": [Network, Keyboard, Puzzle],
  "website-development": [Sparkles, Gauge, Blocks],
};

const FALLBACK_OUTCOME_ICONS: [LucideIcon, LucideIcon, LucideIcon] = [CheckCircle2, Clock, BarChart3];

export function generateStaticParams() {
  return SERVICES.map((service) => ({ slug: service.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) notFound();
  const pitch = SEO_PITCH[service.slug] ?? service.tagline;
  return {
    title: `${service.name} Services — ${pitch}`,
    description: service.intro,
    alternates: { canonical: `/services/${service.slug}` },
  };
}

export default async function ServiceDetailPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) notFound();

  const related = service.relatedSlugs
    .map((relatedSlug) => getService(relatedSlug))
    .filter((s): s is Service => Boolean(s));
  const relevantIndustries = INDUSTRIES.filter((industry) =>
    industry.solutions.some(
      (solution) =>
        solution.serviceSlug === service.slug || solution.serviceSlug.startsWith(`${service.slug}/`)
    )
  );
  const outcomeIcons = OUTCOME_ICONS[service.slug] ?? FALLBACK_OUTCOME_ICONS;

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: service.name,
          description: service.intro,
          url: absoluteUrl(`/services/${service.slug}`),
          provider: { "@type": "Organization", name: siteConfig.name, url: absoluteUrl("/") },
        }}
      />

      <PageHero
        crumbs={[
          { name: "Services", href: "/services" },
          { name: service.name, href: `/services/${service.slug}` },
        ]}
        eyebrow={service.name}
        title={service.tagline}
        description={service.intro}
      >
        <Reveal>
          <div className="flex flex-wrap items-center gap-4">
            <Link href="/book" className="btn-accent">
              Book Free Consultation
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
            <Link
              href="#subservices"
              className="btn-outline-light"
            >
              See what we deliver
            </Link>
          </div>
        </Reveal>
      </PageHero>

      {/* Outcomes */}
      <section className="bg-white">
        <div className="container-site section">
          <SectionHeading
            eyebrow="Outcomes"
            title="What this service changes"
            description="The practical differences clients hire this service for."
          />
          <StaggerGroup className="mt-14 grid gap-6 sm:mt-16 md:grid-cols-3">
            {service.outcomes.map((outcome, i) => {
              const Icon = outcomeIcons[i] ?? CheckCircle2;
              return (
                <StaggerItem key={outcome.title}>
                  <div className="card-hover h-full rounded-xl border border-neutral-200 bg-white p-7">
                    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-[var(--coral)]/10 text-[var(--coral)]">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <h3 className="mt-5 text-lg font-semibold tracking-tight text-[var(--ink)]">{outcome.title}</h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-neutral-600">{outcome.description}</p>
                  </div>
                </StaggerItem>
              );
            })}
          </StaggerGroup>
        </div>
      </section>

      {/* Narrative */}
      <section className="grid-lines border-t border-neutral-100 bg-white">
        <div className="container-site section">
          <div className="max-w-3xl">
            <Reveal>
              <p className="eyebrow">Why it works</p>
            </Reveal>
            <div className="mt-6 space-y-6">
              {service.description.map((paragraph, i) => (
                <Reveal key={i} delay={i * 0.08}>
                  <p className={i === 0 ? "lede text-[var(--ink)]" : "text-lg leading-relaxed text-neutral-600"}>
                    {paragraph}
                  </p>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Subservices */}
      <section id="subservices" className="scroll-mt-24 bg-[#FAFAF8]">
        <div className="container-site section">
          <SectionHeading
            eyebrow="Capabilities"
            title={`What we deliver under ${service.name}`}
            description="Focused subservices you can start with — each one documented, scoped and delivered against agreed outcomes."
          />
          <StaggerGroup className="mt-14 border-t border-neutral-200 sm:mt-16">
            {service.subservices.map((sub, i) => (
              <StaggerItem key={sub.slug} className="border-b border-neutral-200">
                <article className="group grid gap-x-10 gap-y-6 py-10 sm:py-12 lg:grid-cols-12">
                  <div className="lg:col-span-1">
                    <span
                      className="font-display text-5xl font-semibold leading-none tracking-tight text-neutral-300 transition-colors group-hover:text-[var(--coral)]"
                      aria-hidden="true"
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                  </div>
                  <div className="lg:col-span-7">
                    <h3 className="display-3">
                      <Link
                        href={`/services/${service.slug}/${sub.slug}`}
                        className="transition-colors hover:text-[var(--coral)]"
                      >
                        {sub.name}
                      </Link>
                    </h3>
                    <p className="mt-2 text-lg font-medium text-[var(--ink)]">{sub.tagline}</p>
                    <ul className="mt-6 grid gap-x-8 gap-y-2.5 sm:grid-cols-2">
                      {sub.bullets.slice(0, 3).map((bullet) => (
                        <li key={bullet} className="flex items-start gap-2.5 text-sm leading-relaxed text-neutral-600">
                          <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--coral)]" aria-hidden="true" />
                          {bullet}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="lg:col-span-4 lg:flex lg:justify-end">
                    <Link
                      href={`/services/${service.slug}/${sub.slug}`}
                      className="inline-flex items-center gap-2 self-start text-sm font-semibold text-[var(--ink)] transition-colors hover:text-[var(--coral)] lg:mt-2"
                    >
                      Full details
                      <ArrowRight
                        className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
                        aria-hidden="true"
                      />
                    </Link>
                  </div>
                </article>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* Process */}
      <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white">
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div className="container-site section relative">
          <SectionHeading
            dark
            eyebrow="Process"
            title="From first call to running system"
            description="Four steps, no mystery. You always know what is happening, what comes next and what we need from you."
          />
          <StaggerGroup className="mt-14 grid gap-10 sm:mt-16 sm:grid-cols-2 lg:grid-cols-4">
            {service.process.map((step) => (
              <StaggerItem key={step.step}>
                <div className="border-t-2 border-white/10 pt-6">
                  <span
                    className="text-stroke font-display text-6xl font-semibold tracking-tight"
                    aria-hidden="true"
                  >
                    {step.step}
                  </span>
                  <h3 className="mt-4 text-xl font-semibold tracking-tight text-white">{step.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-neutral-400">{step.description}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-white">
        <div className="container-site section">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <SectionHeading
                eyebrow="FAQ"
                title="Questions, answered"
                description="Straight answers to what clients ask most before starting with this service."
              />
            </div>
            <div className="lg:col-span-8">
              <Reveal>
                <FaqAccordion items={service.faqs} />
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Related services + relevant industries */}
      <section className="bg-[#FAFAF8]">
        <div className="container-site section">
          <SectionHeading
            eyebrow="Keep exploring"
            title="Related services"
            description={`Capabilities that pair well with ${service.name} — most clients combine at least two.`}
          />
          <StaggerGroup className="mt-12 grid gap-6 md:grid-cols-2">
            {related.map((relatedService) => (
              <StaggerItem key={relatedService.slug}>
                <Link
                  href={`/services/${relatedService.slug}`}
                  className="card-hover group flex h-full items-start gap-5 rounded-xl border border-neutral-200 bg-white p-7"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-[var(--coral)]/10 text-[var(--coral)]">
                    <ServiceIcon icon={relatedService.icon} className="h-5 w-5" />
                  </span>
                  <span className="flex-1">
                    <span className="flex items-center justify-between gap-4">
                      <span className="text-lg font-semibold tracking-tight text-[var(--ink)]">
                        {relatedService.name}
                      </span>
                      <ArrowRight
                        className="h-4 w-4 shrink-0 text-neutral-300 transition-all group-hover:translate-x-0.5 group-hover:text-[var(--coral)]"
                        aria-hidden="true"
                      />
                    </span>
                    <span className="mt-1.5 block text-sm leading-relaxed text-neutral-600">
                      {relatedService.tagline}
                    </span>
                  </span>
                </Link>
              </StaggerItem>
            ))}
          </StaggerGroup>
          {relevantIndustries.length > 0 && (
            <Reveal className="mt-12 border-t border-neutral-200 pt-10">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-neutral-500">
                Industries where this service does heavy lifting
              </p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {relevantIndustries.map((industry) => (
                  <li key={industry.slug}>
                    <Link
                      href={`/industries/${industry.slug}`}
                      className="inline-block rounded-full border border-neutral-200 bg-white px-3.5 py-1.5 text-xs font-medium text-neutral-600 transition-colors hover:border-[var(--coral)] hover:text-[var(--coral)]"
                    >
                      {industry.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </Reveal>
          )}
        </div>
      </section>

      {/* Mid-page CTA */}
      <section className="bg-white">
        <div className="container-site pb-20 sm:pb-24 lg:pb-32">
          <Reveal>
            <div className="rounded-xl border-2 border-[var(--ink)] p-8 sm:p-12">
              <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
                <div className="max-w-2xl">
                  <h2 className="display-3 text-[var(--ink)]">Not sure where to start?</h2>
                  <p className="mt-3 text-lg leading-relaxed text-neutral-600">
                    Book the free consultation — we&rsquo;ll point you to the right service even if it&rsquo;s not us.
                  </p>
                </div>
                <Link href="/book" className="btn-accent shrink-0">
                  Book Free Consultation
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
