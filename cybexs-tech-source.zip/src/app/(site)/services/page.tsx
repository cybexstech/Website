import type { Metadata } from "next";
import Link from "next/link";
import { Activity, ArrowRight, ArrowUpRight, Cog, Users } from "lucide-react";
import { PageHero } from "@/components/site/page-hero";
import { SectionHeading } from "@/components/site/section-heading";
import { ServiceIcon } from "@/components/site/service-icon";
import { CtaSection } from "@/components/site/cta-section";
import { StaggerGroup, StaggerItem, Reveal } from "@/components/motion/reveal";
import { SERVICES, countSubservices } from "@/data/services";
import { INDUSTRIES } from "@/data/industries";

export const metadata: Metadata = {
  title: "Services — AI Automation, Support & Digital Delivery",
  description:
    "Seven services spanning AI automation, voice agents, lead reactivation, sales development, customer support, system integrations and website development — combining technology with human-powered delivery.",
  alternates: { canonical: "/services" },
};

const APPROACH_POINTS = [
  {
    icon: Cog,
    title: "Automate the repetitive",
    description:
      "AI agents and workflow platforms absorb rule-based, language-heavy work — with guardrails, monitoring and human checkpoints built in.",
  },
  {
    icon: Users,
    title: "Keep people where judgment matters",
    description:
      "Trained specialists own empathy, negotiation and exceptions: support conversations, sales follow-up, quality review and escalation handling.",
  },
  {
    icon: Activity,
    title: "Measure everything we deploy",
    description:
      "Every workflow and team runs against agreed metrics, reviewed with you on a fixed cadence — no black boxes, no vanity reports.",
  },
];

export default function ServicesOverviewPage() {
  return (
    <>
      <PageHero
        crumbs={[{ name: "Services", href: "/services" }]}
        eyebrow="Services"
        title="Seven services. One capable partner."
        description="Practical AI automation, dependable human-powered support, and the technical glue in between — organized into services you can combine as you grow."
      >
        <Reveal>
          <p className="text-sm font-medium text-neutral-400">
            <span className="font-display text-2xl font-semibold text-white">{SERVICES.length}</span> services
            <span className="mx-3 text-neutral-600">·</span>
            <span className="font-display text-2xl font-semibold text-white">{countSubservices()}</span> subservices
            <span className="mx-3 text-neutral-600">·</span>
            technology + people
          </p>
        </Reveal>
      </PageHero>

      {/* Editorial numbered index of all services */}
      <section className="bg-white">
        <div className="container-site section">
          <SectionHeading
            eyebrow="What we do"
            title="Choose the capability you need — or combine them."
            description="Most engagements start with one service and grow as results show up. Everything connects, so nothing you build with us becomes a dead end."
          />
          <StaggerGroup className="mt-14 border-t border-neutral-200 sm:mt-16">
            {SERVICES.map((service, i) => (
              <StaggerItem key={service.slug} className="border-b border-neutral-200">
                <article className="group grid gap-x-10 gap-y-6 py-10 sm:py-12 lg:grid-cols-12 lg:gap-y-0">
                  <div className="flex items-start gap-4 lg:col-span-1">
                    <span
                      className="font-display text-5xl font-semibold leading-none tracking-tight text-neutral-200 transition-colors group-hover:text-[var(--coral)] sm:text-6xl"
                      aria-hidden="true"
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="mt-1.5 text-[var(--coral)] lg:hidden">
                      <ServiceIcon icon={service.icon} className="h-6 w-6" />
                    </span>
                  </div>
                  <div className="lg:col-span-6">
                    <h2 className="display-3">
                      <Link
                        href={`/services/${service.slug}`}
                        className="transition-colors hover:text-[var(--coral)]"
                      >
                        {service.name}
                      </Link>
                    </h2>
                    <p className="mt-2 text-lg font-medium text-[var(--ink)]">{service.tagline}</p>
                    <p className="mt-3 max-w-xl text-base leading-relaxed text-neutral-600">{service.intro}</p>
                  </div>
                  <div className="lg:col-span-4">
                    <p className="sr-only">Included capabilities</p>
                    <ul className="flex flex-wrap gap-2">
                      {service.subservices.map((sub) => (
                        <li key={sub.slug}>
                          <Link
                            href={`/services/${service.slug}/${sub.slug}`}
                            className="inline-block rounded-full border border-neutral-200 bg-white px-3.5 py-1.5 text-xs font-medium text-neutral-600 transition-colors hover:border-[var(--coral)] hover:text-[var(--coral)]"
                          >
                            {sub.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                    <Link
                      href={`/services/${service.slug}`}
                      className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors hover:text-[var(--coral)]"
                    >
                      Explore service
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                    </Link>
                  </div>
                  <div className="hidden lg:col-span-1 lg:flex lg:justify-end">
                    <span className="mt-2 text-neutral-300 transition-colors group-hover:text-[var(--coral)]">
                      <ArrowUpRight className="h-6 w-6" aria-hidden="true" />
                    </span>
                  </div>
                </article>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* Technology + people positioning band */}
      <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white">
        <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
        <div className="container-site section relative">
          <SectionHeading
            dark
            eyebrow="Our approach"
            title="Technology plus people, applied pragmatically."
            description="Pure-software projects stall on edge cases; people-only solutions get expensive as volume grows. We build with both — and draw the line deliberately."
          />
          <StaggerGroup className="mt-14 grid gap-10 sm:mt-16 md:grid-cols-3">
            {APPROACH_POINTS.map((point, i) => (
              <StaggerItem key={point.title}>
                <div className="border-l-2 border-white/10 pl-6">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 text-[var(--coral)]">
                      <point.icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <span className="font-display text-sm font-semibold tracking-[0.2em] text-neutral-500" aria-hidden="true">
                      0{i + 1}
                    </span>
                  </div>
                  <h3 className="mt-5 text-lg font-semibold tracking-tight text-white">{point.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-neutral-400">{point.description}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
          <Reveal delay={0.15} className="mt-14">
            <Link href="/book" className="btn-outline-light">
              Book Free Consultation
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Industries teaser strip */}
      <section className="bg-[#FAFAF8]">
        <div className="container-site section">
          <div className="grid gap-10 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-7">
              <SectionHeading
                eyebrow="Industries"
                title="Built around the problems your industry actually has."
                description="Missed calls, stalled follow-up, document backlogs, disconnected tools — we organize delivery around the problems we see repeated in specific sectors."
              />
            </div>
            <div className="lg:col-span-5">
              <Reveal>
                <ul className="flex flex-wrap gap-2">
                  {INDUSTRIES.map((industry) => (
                    <li key={industry.slug}>
                      <Link
                        href={`/industries/${industry.slug}`}
                        className="inline-block rounded-full border border-neutral-200 bg-white px-3.5 py-1.5 text-xs font-medium text-neutral-600 transition-colors hover:border-[var(--coral)] hover:text-[var(--coral)]"
                      >
                        {industry.name}
                      </Link>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/industries"
                  className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[var(--ink)] transition-colors hover:text-[var(--coral)]"
                >
                  Explore industries
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
