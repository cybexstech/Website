import type { Metadata } from "next";
import { PageHero } from "@/components/site/page-hero";
import { CtaSection } from "@/components/site/cta-section";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "The terms that apply when you use this website, book a free consultation or engage Cybexs Tech — including our demo-project disclaimer and honest limits of liability.",
  alternates: { canonical: "/terms" },
};

const LAST_UPDATED = new Date().toLocaleDateString("en-US", {
  year: "numeric",
  month: "long",
  day: "numeric",
});

function EditorNote() {
  return (
    <aside
      role="note"
      className="border border-neutral-300 border-l-4 border-l-[var(--coral)] bg-[#FAFAF8] p-5 text-sm leading-relaxed text-neutral-600"
    >
      <strong className="font-semibold text-[var(--ink)]">Editor&rsquo;s note:</strong> This document
      reflects the website&rsquo;s implemented functionality. Jurisdiction-specific clauses (company
      registration, governing law) require company input and professional legal review.
    </aside>
  );
}

export default function TermsPage() {
  return (
    <>
      <PageHero
        eyebrow="Legal"
        title="Terms of Service"
        description={`The terms that apply when you use this website or engage with us. Last updated ${LAST_UPDATED}.`}
        crumbs={[{ name: "Terms of Service", href: "/terms" }]}
      />

      <section className="section bg-white" aria-label="Terms of service content">
        <div className="container-site">
          <div className="max-w-3xl space-y-4 text-neutral-600">
            <EditorNote />

            <p className="text-lg leading-relaxed">
              These terms govern your use of this website and your initial interactions with Cybexs Tech.
              Engagements for paid work are agreed individually in a written proposal or contract, which
              takes precedence over anything on this page.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              1. Our services
            </h2>
            <p className="leading-relaxed">
              Cybexs Tech provides AI automation, business services (including customer support and sales
              operations), technical services and integrations, and website development. The{" "}
              <a
                href="/services"
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                services pages
              </a>{" "}
              describe these offerings for general information. Specific deliverables, timelines and
              pricing are defined per engagement in a written scope — nothing on this website constitutes
              a binding offer.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              2. Consultations
            </h2>
            <ul className="list-disc space-y-2 pl-6 leading-relaxed">
              <li>The initial consultation is free of charge and comes with no obligation.</li>
              <li>
                Booking a consultation — through the form on this website or by email — is a request to
                talk, not a contract for services, and creates no payment obligation.
              </li>
              <li>
                During or after the consultation we may share observations and recommendations. These are
                general guidance based on what you tell us; they are not a professional audit of your
                business.
              </li>
              <li>You may cancel or reschedule a consultation at any time without penalty.</li>
            </ul>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              3. Demo and concept projects
            </h2>
            <p className="leading-relaxed">
              The projects shown on this website under{" "}
              <a
                href="/work"
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                Selected Work
              </a>{" "}
              are concept and demonstration projects built by our team. The brands shown (for example
              Maison Élore, Aurion, Northbeam, SOLSTICE, Garam Theory) are fictional. They are not client
              work, no client relationship is implied, and any interactions with the demo sites (carts,
              forms, configurators) are demonstrative only — no real transactions, orders or purchases
              exist or can be made there.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              4. Intellectual property
            </h2>
            <p className="leading-relaxed">
              The content, design and code of this website are owned by Cybexs Tech unless stated
              otherwise. Work delivered to you under an engagement is governed by that engagement&rsquo;s
              written agreement — as a default position, our aim is that you own what we build for you,
              documented and handed over. Demo projects remain the property of Cybexs Tech.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              5. Acceptable use
            </h2>
            <ul className="list-disc space-y-2 pl-6 leading-relaxed">
              <li>Do not submit false, misleading or third-party personal information through our forms.</li>
              <li>Do not attempt to breach, probe or disrupt the website or its infrastructure.</li>
              <li>Do not scrape the website in ways that degrade its operation, and do not reuse our content commercially without written permission.</li>
            </ul>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              6. No warranties or guaranteed outcomes
            </h2>
            <p className="leading-relaxed">
              This website is provided &ldquo;as is&rdquo;. We describe our services honestly, but we do
              not guarantee specific business results — rankings, revenue, cost savings or response
              outcomes — since those depend on factors outside our control. Deliverable-level commitments
              are made only in written, signed scopes. Nothing on this website is financial, legal or tax
              advice.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              7. Limitation of liability
            </h2>
            <p className="leading-relaxed">
              To the maximum extent permitted by applicable law, Cybexs Tech is not liable for indirect,
              incidental or consequential damages arising from your use of this website or from reliance
              on its general content. Our liability for paid engagements is defined in the applicable
              written agreement. Nothing in these terms limits liability that cannot be limited by law.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              8. Third-party services
            </h2>
            <p className="leading-relaxed">
              This website and our engagements rely on third-party services (for example hosting,
              transactional email and, when enabled, Cal.com scheduling). Their availability and their own
              terms apply to the parts they operate; we are transparent about which providers are involved
              wherever it matters. Demo sites may link outward for illustration; we are not responsible
              for external content.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              9. Governing law
            </h2>
            <p className="leading-relaxed">
              [Placeholder — to be completed with company input and legal review.] These terms will
              specify a governing law and venue of jurisdiction once the company&rsquo;s registration
              details are finalized.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              10. Changes to these terms
            </h2>
            <p className="leading-relaxed">
              We may update these terms as the website and our services evolve. The &ldquo;last
              updated&rdquo; date above reflects the current version; significant changes will be
              highlighted on this page.
            </p>

            <h2 className="mt-10 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
              11. Contact
            </h2>
            <p className="leading-relaxed">
              Questions about these terms:{" "}
              <a
                href={`mailto:${siteConfig.contactEmail}`}
                className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
              >
                {siteConfig.contactEmail}
              </a>
              .
            </p>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
