import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Check } from "lucide-react";
import { DEMO_PROJECTS, type DemoProject } from "@/data/demos";
import { PageHero } from "@/components/site/page-hero";
import { CtaSection } from "@/components/site/cta-section";
import { Reveal } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: { absolute: "Selected Work — Concept Demo Projects | Cybexs Tech" },
  description:
    "Five interactive concept projects — fictional brands designed and built in-house by Cybexs Tech to demonstrate our art direction, interaction design and engineering craft.",
};

/** Some registry accents are too light for text on white — readable variants. */
const ACCENT_TEXT: Record<string, string> = {
  "#C6FF3E": "#55700A",
};

function ProjectShowcase({ project, index }: { project: DemoProject; index: number }) {
  const flip = index % 2 === 1;
  const accentText = ACCENT_TEXT[project.accent] ?? project.accent;

  return (
    <Reveal className="mt-20 first:mt-0 sm:mt-28">
      <article className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
        <Link
          href={project.href}
          aria-label={`Open the ${project.brand} interactive concept demo`}
          className={cn("group block lg:col-span-7", flip && "lg:order-2")}
        >
          <DemoImage
            src={project.image}
            alt={`${project.brand} — ${project.title} concept demo preview`}
            sizes="(min-width: 1024px) 58vw, 100vw"
            fallbackLabel={project.brand}
            className="aspect-[16/10] w-full rounded-lg border border-neutral-200 shadow-[0_24px_60px_-40px_rgba(10,10,10,0.4)]"
            imgClassName="transition-transform duration-700 ease-out group-hover:scale-[1.04]"
            style={{
              backgroundImage: `linear-gradient(135deg, ${project.accent}38 0%, #EDECE8 52%, ${project.accent}5C 100%)`,
            }}
          />
        </Link>

        <div className={cn("lg:col-span-5", flip && "lg:order-1")}>
          <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-neutral-500">
            <span aria-hidden="true">{String(index + 1).padStart(2, "0")}</span>
            <span className="h-px w-8" style={{ backgroundColor: project.accent }} aria-hidden="true" />
            <span>{project.category}</span>
            <span className="text-neutral-300" aria-hidden="true">/</span>
            <span>{project.year}</span>
          </div>

          <h2 className="display-2 mt-5">{project.brand}</h2>
          <p className="mt-2 text-sm font-semibold uppercase tracking-[0.18em]" style={{ color: accentText }}>
            {project.title}
          </p>

          <p className="mt-5 max-w-xl text-base leading-relaxed text-neutral-600 sm:text-lg">
            {project.description}
          </p>

          <ul className="mt-7 space-y-2.5">
            {project.highlights.map((highlight) => (
              <li key={highlight} className="flex items-start gap-3 text-sm text-neutral-700">
                <span
                  className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border"
                  style={{ borderColor: project.accent, color: accentText }}
                  aria-hidden="true"
                >
                  <Check className="h-3 w-3" />
                </span>
                {highlight}
              </li>
            ))}
          </ul>

          <Link
            href={project.href}
            className="group/link mt-8 inline-flex items-center gap-2 text-sm font-semibold transition-opacity hover:opacity-75 focus-visible:outline-2 focus-visible:outline-offset-2"
            style={{ color: accentText }}
          >
            Explore the interactive demo
            <ArrowRight className="h-4 w-4 transition-transform group-hover/link:translate-x-1" aria-hidden="true" />
          </Link>
        </div>
      </article>
    </Reveal>
  );
}

export default function WorkPage() {
  return (
    <>
      <PageHero
        eyebrow="Selected work"
        title="Concept projects that show how we think."
        description="Five fictional brands, designed and built entirely in-house. Every product, price and interaction on these sites actually works — only the brands are invented. It is how we sharpen our art direction, interaction design and engineering before we apply it to client work."
        crumbs={[{ name: "Work", href: "/work" }]}
      />

      <section className="section">
        <div className="container-site">
          <Reveal>
            <aside className="border border-neutral-200 border-l-2 border-l-[var(--coral)] bg-[#FAFAF8] p-6 sm:p-8" role="note">
              <p className="text-sm leading-relaxed text-neutral-600">
                <span className="font-semibold text-[var(--ink)]">Please note — </span>
                All five projects are concept demonstrations with fictional brands, products and prices. They are not
                client engagements and imply no client endorsements.
              </p>
            </aside>
          </Reveal>

          <div className="mt-20 sm:mt-28">
            {DEMO_PROJECTS.map((project, i) => (
              <ProjectShowcase key={project.slug} project={project} index={i} />
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Want work like this for your business?"
        description="Every concept on this page started as a conversation about a real problem. Book a free consultation and we will show you what the same thinking could do for your brand — no obligation."
      />
    </>
  );
}
