import type { Metadata } from "next";

import { ContentManager } from "@/components/admin/content-manager";

export const metadata: Metadata = {
  title: { absolute: "Content | Cybexs Tech Admin" },
  robots: { index: false, follow: false },
};

export default function AdminContentPage() {
  return <ContentManager />;
}
