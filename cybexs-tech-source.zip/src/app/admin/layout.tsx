import type { Metadata } from "next";

import { getSession } from "@/lib/auth";
import { AdminLogin } from "@/components/admin/login-form";
import { AdminShell } from "@/components/admin/sidebar";

export const metadata: Metadata = {
  title: {
    template: "%s | Cybexs Tech Admin",
    absolute: "Cybexs Tech Admin",
  },
  robots: { index: false, follow: false },
};

/**
 * Admin layout. Without a valid session every /admin/* route renders the
 * sign-in screen (inline — no redirect). With a session it renders the
 * dashboard shell (dark sidebar + top bar) around the active page.
 */
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();

  if (!session) {
    return <AdminLogin />;
  }

  return <AdminShell user={session}>{children}</AdminShell>;
}
