import type { Metadata } from "next";

import { LeadDetail } from "@/components/admin/lead-detail";

export const metadata: Metadata = {
  title: { absolute: "Lead detail | Cybexs Tech Admin" },
  robots: { index: false, follow: false },
};

export default async function AdminLeadDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <LeadDetail leadId={id} />;
}
