import type { Metadata } from "next";

import { LeadsTable } from "@/components/admin/leads-table";

export const metadata: Metadata = {
  title: { absolute: "Leads | Cybexs Tech Admin" },
  robots: { index: false, follow: false },
};

export default function AdminLeadsPage() {
  return <LeadsTable />;
}
