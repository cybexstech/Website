import type { Metadata } from "next";

import { OverviewClient } from "@/components/admin/overview-client";

export const metadata: Metadata = {
  title: { absolute: "Overview | Cybexs Tech Admin" },
  robots: { index: false, follow: false },
};

export default function AdminOverviewPage() {
  return <OverviewClient />;
}
