import type { Metadata } from "next";

import { TeamPanel } from "@/components/admin/team-panel";

export const metadata: Metadata = {
  title: { absolute: "Team | Cybexs Tech Admin" },
  robots: { index: false, follow: false },
};

export default function AdminTeamPage() {
  return <TeamPanel />;
}
