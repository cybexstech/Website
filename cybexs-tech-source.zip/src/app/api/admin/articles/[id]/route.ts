import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";
import { articleUpsertSchema } from "@/lib/validations";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    await requireSession();
    const { id } = await ctx.params;
    const article = await db.article.findUnique({ where: { id } });
    if (!article) return NextResponse.json({ ok: false, error: "Article not found." }, { status: 404 });
    return NextResponse.json({ ok: true, article });
  } catch (err) {
    if (isAdminError(err)) return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    console.error("[api/admin/articles/id]", err);
    return NextResponse.json({ ok: false, error: "Failed to load article." }, { status: 500 });
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    await requireSession(true); // ADMIN only can edit content
    const { id } = await ctx.params;
    const body = await req.json().catch(() => null);
    const parsed = articleUpsertSchema.safeParse(body);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = String(issue.path[0] ?? "form");
        if (!fieldErrors[key]) fieldErrors[key] = issue.message;
      }
      return NextResponse.json({ ok: false, error: "Please correct the highlighted fields.", fieldErrors }, { status: 422 });
    }

    const existing = await db.article.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ ok: false, error: "Article not found." }, { status: 404 });

    const d = parsed.data;
    const slugConflict = await db.article.findFirst({ where: { slug: d.slug, id: { not: id } }, select: { id: true } });
    if (slugConflict) {
      return NextResponse.json({ ok: false, error: "That slug is already in use.", fieldErrors: { slug: "Already in use." } }, { status: 409 });
    }

    const article = await db.article.update({
      where: { id },
      data: {
        slug: d.slug,
        title: d.title,
        excerpt: d.excerpt,
        content: d.content,
        category: d.category,
        tags: d.tags,
        status: d.status,
        seoTitle: d.seoTitle || null,
        seoDescription: d.seoDescription || null,
        featuredImage: d.featuredImage || null,
        author: d.author,
        readMinutes: d.readMinutes,
        publishedAt:
          d.status === "PUBLISHED"
            ? existing.publishedAt ?? (d.publishedAt ? new Date(d.publishedAt) : new Date())
            : null,
      },
    });
    return NextResponse.json({ ok: true, article });
  } catch (err) {
    if (isAdminError(err)) {
      const status = err.message.includes("Administrator") ? 403 : 401;
      return NextResponse.json({ ok: false, error: err.message }, { status });
    }
    console.error("[api/admin/articles/id PATCH]", err);
    return NextResponse.json({ ok: false, error: "Failed to update article." }, { status: 500 });
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    await requireSession(true);
    const { id } = await ctx.params;
    await db.article.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (isAdminError(err)) {
      const status = err.message.includes("Administrator") ? 403 : 401;
      return NextResponse.json({ ok: false, error: err.message }, { status });
    }
    console.error("[api/admin/articles/id DELETE]", err);
    return NextResponse.json({ ok: false, error: "Failed to delete article." }, { status: 500 });
  }
}
