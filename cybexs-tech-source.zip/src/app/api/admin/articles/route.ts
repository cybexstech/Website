import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";
import { articleUpsertSchema } from "@/lib/validations";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  try {
    await requireSession();
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const where = status === "DRAFT" || status === "PUBLISHED" ? { status } : {};
    const articles = await db.article.findMany({
      where,
      orderBy: [{ updatedAt: "desc" }],
      select: {
        id: true, slug: true, title: true, excerpt: true, category: true, tags: true,
        status: true, author: true, publishedAt: true, createdAt: true, updatedAt: true, readMinutes: true,
      },
    });
    return NextResponse.json({ ok: true, articles });
  } catch (err) {
    if (isAdminError(err)) return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    console.error("[api/admin/articles]", err);
    return NextResponse.json({ ok: false, error: "Failed to load articles." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await requireSession(true); // ADMIN only can create
    const body = await req.json().catch(() => null);
    const parsed = articleUpsertSchema.safeParse(body);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = String(issue.path[0] ?? "form");
        if (!fieldErrors[key]) fieldErrors[key] = issue.message;
      }
      return NextResponse.json({ ok: false, error: "Please correct the highlighted fields.", fieldErrors }, { status: 422 });
    }

    const d = parsed.data;
    const exists = await db.article.findUnique({ where: { slug: d.slug }, select: { id: true } });
    if (exists) {
      return NextResponse.json({ ok: false, error: "That slug is already in use.", fieldErrors: { slug: "Already in use." } }, { status: 409 });
    }

    const article = await db.article.create({
      data: {
        slug: d.slug,
        title: d.title,
        excerpt: d.excerpt,
        content: d.content,
        category: d.category,
        tags: d.tags,
        status: d.status,
        seoTitle: d.seoTitle || null,
        seoDescription: d.seoDescription || null,
        featuredImage: d.featuredImage || null,
        author: d.author || session.name,
        readMinutes: d.readMinutes,
        publishedAt: d.status === "PUBLISHED" ? (d.publishedAt ? new Date(d.publishedAt) : new Date()) : null,
      },
    });
    return NextResponse.json({ ok: true, article }, { status: 201 });
  } catch (err) {
    if (isAdminError(err)) {
      const status = err.message.includes("Administrator") ? 403 : 401;
      return NextResponse.json({ ok: false, error: err.message }, { status });
    }
    console.error("[api/admin/articles POST]", err);
    return NextResponse.json({ ok: false, error: "Failed to create article." }, { status: 500 });
  }
}
