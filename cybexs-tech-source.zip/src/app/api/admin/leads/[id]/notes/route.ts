import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";
import { noteCreateSchema } from "@/lib/validations";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  try {
    const session = await requireSession();
    const { id } = await ctx.params;
    const body = await req.json().catch(() => null);
    const parsed = noteCreateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid note." },
        { status: 422 }
      );
    }

    const lead = await db.lead.findUnique({ where: { id }, select: { id: true } });
    if (!lead) return NextResponse.json({ ok: false, error: "Lead not found." }, { status: 404 });

    const note = await db.note.create({
      data: { leadId: id, body: parsed.data.body, author: session.name },
    });
    return NextResponse.json({ ok: true, note }, { status: 201 });
  } catch (err) {
    if (isAdminError(err)) return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    console.error("[api/admin/notes]", err);
    return NextResponse.json({ ok: false, error: "Failed to add note." }, { status: 500 });
  }
}
