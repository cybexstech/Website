import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";
import { sendLeadNotification } from "@/lib/email";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

/** Manual retry of the business notification for a lead (admin only). */
export async function POST(_req: Request, ctx: Ctx) {
  try {
    await requireSession(true); // ADMIN only
    const { id } = await ctx.params;
    const lead = await db.lead.findUnique({ where: { id } });
    if (!lead) return NextResponse.json({ ok: false, error: "Lead not found." }, { status: 404 });

    const result = await sendLeadNotification({
      leadId: lead.id,
      fullName: lead.fullName,
      email: lead.email,
      companyName: lead.companyName,
      companyWebsite: lead.companyWebsite,
      serviceInterest: lead.serviceInterest,
      source: lead.source,
      message: lead.message,
    });

    await db.lead.update({
      where: { id },
      data: {
        emailStatus: result.status,
        emailError: result.error ?? null,
      },
    });

    return NextResponse.json({ ok: true, result });
  } catch (err) {
    if (isAdminError(err)) return NextResponse.json({ ok: false, error: "Administrator privileges required." }, { status: 403 });
    console.error("[api/admin/resend-email]", err);
    return NextResponse.json({ ok: false, error: "Retry failed." }, { status: 500 });
  }
}
