import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";
import { leadUpdateSchema } from "@/lib/validations";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    await requireSession();
    const { id } = await ctx.params;
    const lead = await db.lead.findUnique({
      where: { id },
      include: { notes: { orderBy: { createdAt: "desc" } } },
    });
    if (!lead) return NextResponse.json({ ok: false, error: "Lead not found." }, { status: 404 });
    return NextResponse.json({ ok: true, lead });
  } catch (err) {
    if (isAdminError(err)) return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    console.error("[api/admin/leads/id]", err);
    return NextResponse.json({ ok: false, error: "Failed to load lead." }, { status: 500 });
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const session = await requireSession();
    const { id } = await ctx.params;
    const body = await req.json().catch(() => null);
    const parsed = leadUpdateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: "Invalid update payload." }, { status: 422 });
    }

    const data: Record<string, unknown> = {};
    if (parsed.data.status !== undefined) data.status = parsed.data.status;
    if (parsed.data.ownerName !== undefined) data.ownerName = parsed.data.ownerName;
    if (parsed.data.followUpDate !== undefined) {
      data.followUpDate = parsed.data.followUpDate ? new Date(parsed.data.followUpDate) : null;
    }

    const lead = await db.lead.update({ where: { id }, data });

    if (parsed.data.status !== undefined) {
      await db.note.create({
        data: {
          leadId: id,
          body: `Status changed to ${parsed.data.status.replace("_", " ")} by ${session.name}.`,
          author: "System",
        },
      });
    }

    return NextResponse.json({ ok: true, lead });
  } catch (err) {
    if (isAdminError(err)) return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    console.error("[api/admin/leads/id PATCH]", err);
    return NextResponse.json({ ok: false, error: "Failed to update lead." }, { status: 500 });
  }
}
