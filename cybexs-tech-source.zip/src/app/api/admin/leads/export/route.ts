import { type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";

export const runtime = "nodejs";

function csvEscape(value: unknown): string {
  const s = value === null || value === undefined ? "" : String(value);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

/** CSV export of lead data. Requires ADMIN role — TEAM members cannot export. */
export async function GET(_req: NextRequest) {
  try {
    await requireSession(true);

    const leads = await db.lead.findMany({
      orderBy: { createdAt: "desc" },
      include: { notes: { orderBy: { createdAt: "desc" } } },
    });

    const header = [
      "Lead ID",
      "Full Name",
      "Email",
      "Company",
      "Website",
      "Service Interest",
      "Source",
      "Status",
      "Owner",
      "Follow-up Date",
      "Booking Ref",
      "Email Status",
      "Created At",
      "Internal Notes",
    ];

    const rows = leads.map((l) =>
      [
        l.id,
        l.fullName,
        l.email,
        l.companyName,
        l.companyWebsite,
        l.serviceInterest,
        l.source,
        l.status,
        l.ownerName,
        l.followUpDate?.toISOString(),
        l.bookingRef,
        l.emailStatus,
        l.createdAt.toISOString(),
        l.notes.map((n) => `[${n.createdAt.toISOString()} ${n.author}] ${n.body}`).join(" | "),
      ]
        .map(csvEscape)
        .join(",")
    );

    const csv = [header.join(","), ...rows].join("\r\n");

    return new Response(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="cybexs-tech-leads-${new Date().toISOString().slice(0, 10)}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    if (isAdminError(err)) {
      const status = err.message.includes("Administrator") ? 403 : 401;
      return new Response(JSON.stringify({ ok: false, error: err.message }), { status, headers: { "Content-Type": "application/json" } });
    }
    console.error("[api/admin/export]", err);
    return new Response(JSON.stringify({ ok: false, error: "Export failed." }), { status: 500, headers: { "Content-Type": "application/json" } });
  }
}
