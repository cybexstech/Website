import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError } from "@/lib/auth";
import { LEAD_STATUSES } from "@/lib/validations";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  try {
    await requireSession();

    const { searchParams } = new URL(req.url);
    const query = searchParams.get("query")?.trim() || "";
    const status = searchParams.get("status")?.trim() || "";
    const owner = searchParams.get("owner")?.trim() || "";
    const source = searchParams.get("source")?.trim() || "";
    const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10) || 1);
    const pageSize = Math.min(100, Math.max(5, parseInt(searchParams.get("pageSize") || "25", 10) || 25));

    const where: Record<string, unknown> = {};
    if (status && (LEAD_STATUSES as readonly string[]).includes(status)) where.status = status;
    if (owner) where.ownerName = owner;
    if (source) where.source = source;
    if (query) {
      where.OR = [
        { fullName: { contains: query } },
        { email: { contains: query } },
        { companyName: { contains: query } },
        { serviceInterest: { contains: query } },
      ];
    }

    const [total, leads] = await Promise.all([
      db.lead.count({ where }),
      db.lead.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { notes: { orderBy: { createdAt: "desc" }, take: 1 } },
      }),
    ]);

    const owners = await db.lead.findMany({
      where: { ownerName: { not: null } },
      select: { ownerName: true },
      distinct: ["ownerName"],
    });

    return NextResponse.json({
      ok: true,
      leads: leads.map((l) => ({
        ...l,
        lastNote: l.notes[0]?.body ?? null,
        notes: undefined,
      })),
      total,
      page,
      pageSize,
      owners: owners.map((o) => o.ownerName).filter(Boolean),
    });
  } catch (err) {
    if (isAdminError(err)) {
      return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    }
    console.error("[api/admin/leads]", err);
    return NextResponse.json({ ok: false, error: "Failed to load leads." }, { status: 500 });
  }
}
