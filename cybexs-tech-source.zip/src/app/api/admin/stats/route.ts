import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession, isAdminError, UnauthorizedError } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  try {
    await requireSession();

    const [total, byStatusRaw, recent, last14] = await Promise.all([
      db.lead.count(),
      db.lead.groupBy({ by: ["status"], _count: { _all: true } }),
      db.lead.findMany({ orderBy: { createdAt: "desc" }, take: 8, select: { id: true, fullName: true, companyName: true, serviceInterest: true, status: true, createdAt: true, source: true } }),
      db.lead.findMany({
        where: { createdAt: { gte: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000) } },
        select: { createdAt: true },
      }),
    ]);

    const byStatus: Record<string, number> = {};
    for (const row of byStatusRaw) byStatus[row.status] = row._count._all;

    // 14-day trend buckets (per day).
    const trend: { date: string; count: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      const next = new Date(d);
      next.setDate(next.getDate() + 1);
      const count = last14.filter((l) => l.createdAt >= d && l.createdAt < next).length;
      trend.push({ date: d.toISOString().slice(0, 10), count });
    }

    const followUpsDue = await db.lead.count({
      where: {
        followUpDate: { lte: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) },
        status: { in: ["NEW", "CONTACTED", "QUALIFIED", "MEETING_BOOKED"] },
      },
    });

    return NextResponse.json({
      ok: true,
      stats: { total, byStatus, followUpsDue, trend, recent },
    });
  } catch (err) {
    if (isAdminError(err) || err instanceof UnauthorizedError) {
      return NextResponse.json({ ok: false, error: "Authentication required." }, { status: 401 });
    }
    console.error("[api/admin/stats]", err);
    return NextResponse.json({ ok: false, error: "Failed to load stats." }, { status: 500 });
  }
}
