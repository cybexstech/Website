import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { contactLeadSchema } from "@/lib/validations";
import { sendLeadNotification, sendProspectAcknowledgement } from "@/lib/email";

export const runtime = "nodejs";

/** Public contact form endpoint. Same persistence-first guarantees as /api/leads. */
export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  const parsed = contactLeadSchema.safeParse(body);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      if (!fieldErrors[key]) fieldErrors[key] = issue.message;
    }
    return NextResponse.json(
      { ok: false, error: "Please correct the highlighted fields.", fieldErrors },
      { status: 422 }
    );
  }

  const data = parsed.data;

  try {
    const lead = await db.lead.create({
      data: {
        fullName: data.fullName,
        email: data.email,
        companyName: data.companyName,
        companyWebsite: data.companyWebsite ?? null,
        serviceInterest: data.serviceInterest,
        source: "contact",
        inquiryType: "general_inquiry",
        message: data.message,
        status: "NEW",
      },
    });

    void (async () => {
      try {
        const [teamResult, prospectResult] = await Promise.all([
          sendLeadNotification({ ...data, leadId: lead.id, source: "contact" }),
          sendProspectAcknowledgement({ ...data, leadId: lead.id, source: "contact" }),
        ]);
        const failed = [teamResult, prospectResult].find((r) => r.status === "FAILED");
        await db.lead.update({
          where: { id: lead.id },
          data: {
            emailStatus: failed ? "FAILED" : teamResult.status === "SENT" ? "SENT" : "SKIPPED_NO_PROVIDER",
            emailError: failed?.error ?? null,
          },
        });
      } catch (err) {
        console.error("[api/contact] notification pipeline error", err);
        await db.lead
          .update({ where: { id: lead.id }, data: { emailStatus: "FAILED", emailError: "Notification pipeline error" } })
          .catch(() => undefined);
      }
    })();

    return NextResponse.json({ ok: true, leadId: lead.id }, { status: 201 });
  } catch (err) {
    console.error("[api/contact] persistence error", err);
    return NextResponse.json(
      { ok: false, error: "We could not send your message. Please try again or email us directly." },
      { status: 500 }
    );
  }
}
