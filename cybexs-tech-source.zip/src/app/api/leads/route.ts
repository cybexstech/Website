import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { consultationLeadSchema } from "@/lib/validations";
import { sendLeadNotification, sendProspectAcknowledgement } from "@/lib/email";

export const runtime = "nodejs";

/**
 * Public consultation lead capture.
 * - Validates input (zod)
 * - Persists the lead BEFORE anything is reported as successful
 * - De-duplicates repeated submissions by email within 24h (returns the existing lead)
 * - Sends notifications asynchronously; email failure never discards the lead
 */
export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  const parsed = consultationLeadSchema.safeParse(body);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      if (!fieldErrors[key]) fieldErrors[key] = issue.message;
    }
    return NextResponse.json(
      { ok: false, error: "Please correct the highlighted fields.", fieldErrors },
      { status: 422 }
    );
  }

  const data = parsed.data;

  try {
    // Duplicate prevention: same email + consultation source within 24h.
    const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const existing = await db.lead.findFirst({
      where: {
        email: data.email,
        source: "consultation",
        createdAt: { gte: dayAgo },
      },
      orderBy: { createdAt: "desc" },
    });

    if (existing) {
      return NextResponse.json({ ok: true, leadId: existing.id, existing: true });
    }

    const lead = await db.lead.create({
      data: {
        fullName: data.fullName,
        email: data.email,
        companyName: data.companyName,
        companyWebsite: data.companyWebsite ?? null,
        serviceInterest: data.serviceInterest,
        source: "consultation",
        status: "NEW",
      },
    });

    // Notifications run after persistence; results are recorded on the lead row.
    void (async () => {
      try {
        const [teamResult, prospectResult] = await Promise.all([
          sendLeadNotification({ ...data, leadId: lead.id, source: "consultation" }),
          sendProspectAcknowledgement({ ...data, leadId: lead.id, source: "consultation" }),
        ]);
        const failed = [teamResult, prospectResult].find((r) => r.status === "FAILED");
        await db.lead.update({
          where: { id: lead.id },
          data: {
            emailStatus: failed ? "FAILED" : teamResult.status === "SENT" ? "SENT" : "SKIPPED_NO_PROVIDER",
            emailError: failed?.error ?? null,
          },
        });
      } catch (err) {
        console.error("[api/leads] notification pipeline error", err);
        await db.lead
          .update({ where: { id: lead.id }, data: { emailStatus: "FAILED", emailError: "Notification pipeline error" } })
          .catch(() => undefined);
      }
    })();

    return NextResponse.json({ ok: true, leadId: lead.id }, { status: 201 });
  } catch (err) {
    console.error("[api/leads] persistence error", err);
    return NextResponse.json(
      { ok: false, error: "We could not save your request. Please try again or email us directly." },
      { status: 500 }
    );
  }
}
