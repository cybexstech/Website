import type { Metadata } from "next";
import { Archivo, Oswald } from "next/font/google";
import { Counter } from "@/components/motion/counter";
import { HeroEntrance } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { Lineup } from "@/components/demos/automotive/lineup";
import { Performance } from "@/components/demos/automotive/performance";
import { BriefingForm } from "@/components/demos/automotive/briefing-form";
import { cn } from "@/lib/utils";

const oswald = Oswald({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-aurion-display",
  display: "swap",
});

const archivo = Archivo({
  subsets: ["latin"],
  variable: "--font-aurion-body",
  display: "swap",
});

const DISPLAY = "font-[family-name:var(--font-aurion-display)]";

export const metadata: Metadata = {
  title: { absolute: "AURION — Concept Demo | Cybexs Tech" },
  description:
    "Interactive concept demo: a cinematic electric hyper-GT marque with a model line-up selector, animated performance bars and a demo briefing form. A fictional brand by Cybexs Tech.",
  robots: { index: false, follow: false },
};

const HERO_STATS: { value: number; decimals: number; suffix: string; label: string }[] = [
  { value: 2.4, decimals: 1, suffix: " s", label: "0–100 km/h" },
  { value: 745, decimals: 0, suffix: " kW", label: "Peak power" },
  { value: 920, decimals: 0, suffix: " km", label: "Range, WLTP" },
];

export default function AutomotiveDemoPage() {
  return (
    <div
      className={cn(
        oswald.variable,
        archivo.variable,
        "relative min-h-screen bg-[#0B0D0C] font-[family-name:var(--font-aurion-body)] text-white",
      )}
    >
      <header className="absolute inset-x-0 top-0 z-40">
        <nav aria-label="AURION" className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
          <a href="#top" className={cn(DISPLAY, "flex items-center gap-2.5 text-lg font-semibold uppercase tracking-[0.35em] text-white")}>
            <span className="inline-block h-2 w-2 bg-[#C6FF3E]" aria-hidden="true" />
            AURION
          </a>
          <div className="flex items-center gap-4 sm:gap-8">
            <nav aria-label="AURION sections" className="hidden items-center gap-7 sm:flex">
              {[
                { label: "Models", href: "#models" },
                { label: "Performance", href: "#performance" },
                { label: "Contact", href: "#contact" },
              ].map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-[11px] uppercase tracking-[0.25em] text-neutral-400 transition-colors hover:text-white"
                >
                  {item.label}
                </a>
              ))}
            </nav>
            <a
              href="#contact"
              className="border border-[#C6FF3E] px-4 py-2 text-[10px] font-bold uppercase tracking-[0.25em] text-[#C6FF3E] transition-colors hover:bg-[#C6FF3E] hover:text-[#0B0D0C] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C6FF3E] sm:text-[11px]"
            >
              Private briefing
            </a>
          </div>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="relative flex min-h-[92svh] items-end overflow-hidden">
          <DemoImage
            priority
            src="/demo-assets/automotive/hero.jpg"
            alt="AURION GT concept car in a dark studio, lit by a single volt-green strip"
            sizes="100vw"
            className="absolute inset-0 bg-gradient-to-br from-[#141A12] via-[#1B2417] to-[#0B0D0C]"
            fallbackLabel="AURION"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#0B0D0C] via-[#0B0D0C]/55 to-[#0B0D0C]/60"
          />
          <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-32 sm:px-8 sm:pb-20">
            <HeroEntrance>
              <p className="text-[11px] uppercase tracking-[0.4em] text-[#C6FF3E]">
                Electric hyper-GT — a fictional marque
              </p>
              <h1
                className={cn(
                  DISPLAY,
                  "mt-5 text-6xl font-semibold uppercase leading-[0.95] tracking-tight text-white sm:text-8xl lg:text-9xl",
                )}
              >
                Silent.
                <span className="block text-[#C6FF3E]">Violent.</span>
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-neutral-300 sm:text-lg">
                The AURION GT is a fictional electric grand tourer — a demonstration of how a performance brand can
                speak in voltage and restraint. Every figure on this page is invented; every interaction is real.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#models"
                  className="bg-[#C6FF3E] px-7 py-3.5 text-xs font-bold uppercase tracking-[0.25em] text-[#0B0D0C] transition-colors hover:bg-[#D8FF6E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  The line-up
                </a>
                <a
                  href="#contact"
                  className="border border-white/25 px-7 py-3.5 text-xs font-bold uppercase tracking-[0.25em] text-white transition-colors hover:border-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  Private briefing
                </a>
              </div>
            </HeroEntrance>
          </div>
        </section>

        {/* Spec counters */}
        <section aria-label="Headline specifications" className="border-y border-white/10 bg-[#0B0D0C]">
          <div className="mx-auto grid max-w-7xl grid-cols-1 divide-y divide-white/10 px-5 sm:grid-cols-3 sm:divide-x sm:divide-y-0 sm:px-8">
            {HERO_STATS.map((stat) => (
              <div key={stat.label} className="flex flex-col items-start gap-2 py-8 sm:items-center sm:py-12">
                <Counter
                  to={stat.value}
                  decimals={stat.decimals}
                  suffix={stat.suffix}
                  className={cn(DISPLAY, "text-4xl font-semibold text-[#C6FF3E] sm:text-5xl")}
                />
                <span className="text-[10px] uppercase tracking-[0.3em] text-neutral-400">{stat.label}</span>
              </div>
            ))}
          </div>
        </section>

        <Lineup />
        <Performance />
        <BriefingForm />
      </main>

      <footer className="border-t border-white/10 bg-[#0B0D0C]">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-end md:justify-between">
          <div>
            <p className={cn(DISPLAY, "flex items-center gap-2.5 text-lg font-semibold uppercase tracking-[0.35em] text-white")}>
              <span className="inline-block h-2 w-2 bg-[#C6FF3E]" aria-hidden="true" />
              AURION
            </p>
            <p className="mt-3 max-w-sm text-xs leading-relaxed text-neutral-500">
              Fictional concept brand. No real products, orders or payments.
            </p>
          </div>
          <nav aria-label="AURION footer" className="flex flex-wrap items-center gap-x-7 gap-y-3">
            {[
              { label: "Models", href: "#models" },
              { label: "Performance", href: "#performance" },
              { label: "Contact", href: "#contact" },
            ].map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-[11px] uppercase tracking-[0.25em] text-neutral-400 transition-colors hover:text-white"
              >
                {item.label}
              </a>
            ))}
            <a
              href="/work"
              className="text-[11px] uppercase tracking-[0.25em] text-[#C6FF3E] underline underline-offset-4 transition-colors hover:text-white"
            >
              More concept work
            </a>
          </nav>
        </div>
      </footer>
    </div>
  );
}
