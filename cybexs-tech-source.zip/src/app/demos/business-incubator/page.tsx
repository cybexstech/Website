import type { Metadata } from "next";
import { Inter, Spectral } from "next/font/google";
import { Counter } from "@/components/motion/counter";
import { HeroEntrance, Reveal } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Programs } from "@/components/demos/business-incubator/programs";
import { ApplicationJourney } from "@/components/demos/business-incubator/application";
import { cn } from "@/lib/utils";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-northbeam-body",
  display: "swap",
});

const spectral = Spectral({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-northbeam-display",
  display: "swap",
});

const DISPLAY = "font-[family-name:var(--font-northbeam-display)]";

export const metadata: Metadata = {
  title: { absolute: "Northbeam — Concept Demo | Cybexs Tech" },
  description:
    "Interactive concept demo: a credible startup-incubator presence with program discovery, a week-in-the-life schedule and a multi-step application journey. A fictional organization by Cybexs Tech.",
  robots: { index: false, follow: false },
};

const NAV = [
  { label: "Programs", href: "#programs" },
  { label: "About", href: "#about" },
  { label: "Apply", href: "#apply" },
];

const PROGRAM_FACTS: { value: number; label: string; note: string }[] = [
  { value: 64, label: "Startups supported", note: "Across all cohorts since (fictional) 2019" },
  { value: 120, label: "Mentors in network", note: "Operators, investors and domain specialists" },
  { value: 12, label: "Program weeks", note: "The length of the flagship Foundry program" },
];

const WEEK_SCHEDULE: [string, string, string][] = [
  ["Monday", "09:00", "Stand-up, then long focus blocks — calendars stay closed until noon"],
  ["Tuesday", "11:00", "Mentor office hours: two 45-minute slots, one honest conversation each"],
  ["Wednesday", "14:00", "Founder workshop — pricing, evidence, narrative, on rotation"],
  ["Thursday", "10:00", "Build day. No meetings, no visitors, bread in the kitchen"],
  ["Friday", "16:00", "Demos and close-out: five minutes of progress, shown, not told"],
];

const FAQS: { q: string; a: string }[] = [
  {
    q: "Is Northbeam a real incubator?",
    a: "No. Northbeam is a fictional organization created by Cybexs Tech as a concept demonstration of institutional design: program discovery, cohort storytelling and an application journey, all fully interactive.",
  },
  {
    q: "What does the program cost?",
    a: "Nothing — because there is nothing to buy. Programs, grants, cohorts and mentor counts are illustrative fiction, presented the way a real incubator would present them.",
  },
  {
    q: "Can I actually apply?",
    a: "You can complete the three-step journey, and you will reach a review screen. That is where it ends: this demo collects no applications, stores nothing and sends nothing.",
  },
];

export default function IncubatorDemoPage() {
  return (
    <div
      className={cn(
        inter.variable,
        spectral.variable,
        "min-h-screen bg-white font-[family-name:var(--font-northbeam-body)] text-[#191919]",
      )}
    >
      <header className="border-b border-[#191919]/10 bg-white">
        <nav aria-label="Northbeam" className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
          <a href="#top" className={cn(DISPLAY, "flex items-center gap-2.5 text-xl font-semibold text-[#191919]")}>
            <span className="grid h-7 w-7 place-items-center bg-[#1E5C3F]" aria-hidden="true">
              <span className="h-2.5 w-2.5 bg-[#FAF7F0]" />
            </span>
            Northbeam
          </a>
          <div className="flex items-center gap-4 sm:gap-8">
            <nav aria-label="Northbeam sections" className="hidden items-center gap-7 sm:flex">
              {NAV.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm text-[#191919]/60 transition-colors hover:text-[#191919]"
                >
                  {item.label}
                </a>
              ))}
            </nav>
            <a
              href="#apply"
              className="bg-[#1E5C3F] px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:bg-[#123B2A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E5C3F]"
            >
              Apply
            </a>
          </div>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="relative flex min-h-[78svh] items-end overflow-hidden">
          <DemoImage
            priority
            src="/demo-assets/incubator/hero.jpg"
            alt="Founders working at long shared tables in the fictional Northbeam house"
            sizes="100vw"
            className="absolute inset-0 bg-gradient-to-br from-[#123B2A] via-[#1E5C3F] to-[#0F2C1F]"
            fallbackLabel="Northbeam"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#0F2C1F]/95 via-[#0F2C1F]/70 to-[#0F2C1F]/50"
          />
          <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-32 sm:px-8 sm:pb-20">
            <HeroEntrance>
              <p className="text-[11px] uppercase tracking-[0.35em] text-white/70">
                A fictional incubator — designed by Cybexs Tech
              </p>
              <h1
                className={cn(
                  DISPLAY,
                  "mt-5 max-w-3xl text-4xl font-semibold leading-[1.08] text-white sm:text-6xl",
                )}
              >
                Where good ideas get infrastructure.
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">
                Northbeam exists to shorten the distance between a serious idea and a functioning organization. The
                building, the mentors and the numbers are fiction — the way a site like this should feel is not.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#programs"
                  className="bg-[#FAF7F0] px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-[#123B2A] transition-colors hover:bg-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  Explore programs
                </a>
                <a
                  href="#apply"
                  className="border border-white/30 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:border-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  How it works
                </a>
              </div>
            </HeroEntrance>
          </div>
        </section>

        {/* Program facts */}
        <section aria-label="Program facts" className="bg-[#1E5C3F] text-white">
          <div className="mx-auto grid max-w-7xl gap-px px-0 sm:grid-cols-3">
            {PROGRAM_FACTS.map((fact) => (
              <div key={fact.label} className="border-b border-white/10 p-8 sm:border-b-0 sm:border-r sm:p-10 sm:last:border-r-0">
                <Counter
                  to={fact.value}
                  className={cn(DISPLAY, "text-5xl font-semibold sm:text-6xl")}
                />
                <p className="mt-3 text-xs font-semibold uppercase tracking-[0.2em] text-white/90">{fact.label}</p>
                <p className="mt-1.5 text-sm text-white/55">{fact.note}</p>
              </div>
            ))}
          </div>
          <div className="mx-auto max-w-7xl px-5 pb-4 sm:px-8">
            <p className="text-xs italic text-white/40">Illustrative figures for a fictional organization.</p>
          </div>
        </section>

        <Programs />

        {/* A week at Northbeam */}
        <section id="about" className="scroll-mt-16 bg-[#FAF7F0]">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-2">
            <Reveal>
              <DemoImage
                src="/demo-assets/incubator/space.jpg"
                alt="The fictional Northbeam house: warm workshop space with long tables"
                sizes="(min-width: 1024px) 50vw, 100vw"
                className="aspect-[4/3] w-full border border-[#191919]/10 bg-gradient-to-br from-[#E9E2D2] via-[#D8CFBA] to-[#B9AE93]"
                imgClassName="transition-transform duration-700 ease-out hover:scale-[1.03]"
                fallbackLabel="The Northbeam house"
              />
            </Reveal>
            <Reveal delay={0.1}>
              <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#1E5C3F]">About</p>
              <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold leading-tight text-[#191919] sm:text-5xl")}>
                A week at Northbeam.
              </h2>
              <p className="mt-4 max-w-lg text-base leading-relaxed text-[#191919]/60">
                Programs are built around one belief: momentum comes from rhythm, not heroics. Here is the week every
                cohort can expect — the same shape whether the idea is climate hardware or a better form builder.
              </p>
              <ul className="mt-8">
                {WEEK_SCHEDULE.map(([day, time, activity]) => (
                  <li
                    key={day}
                    className="grid grid-cols-[5.5rem_3.5rem_1fr] items-baseline gap-3 border-b border-[#191919]/10 py-3.5 text-sm sm:grid-cols-[7rem_4rem_1fr] sm:gap-4"
                  >
                    <span className="font-semibold text-[#191919]">{day}</span>
                    <span className="tabular-nums text-[#1E5C3F]">{time}</span>
                    <span className="text-[#191919]/60">{activity}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <ApplicationJourney />

        {/* FAQ */}
        <section className="border-t border-[#191919]/10">
          <div className="mx-auto max-w-3xl px-5 py-20 sm:px-8 sm:py-24">
            <Reveal>
              <h2 className={cn(DISPLAY, "text-3xl font-semibold text-[#191919] sm:text-4xl")}>Questions, answered.</h2>
              <Accordion type="single" collapsible className="mt-8">
                {FAQS.map((faq, i) => (
                  <AccordionItem key={faq.q} value={`faq-${i}`} className="border-[#191919]/10">
                    <AccordionTrigger className="text-left text-base font-medium text-[#191919] hover:text-[#1E5C3F] hover:no-underline">
                      {faq.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-sm leading-relaxed text-[#191919]/65">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </Reveal>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#191919]/10 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-end md:justify-between">
          <div>
            <p className={cn(DISPLAY, "flex items-center gap-2.5 text-xl font-semibold text-[#191919]")}>
              <span className="grid h-6 w-6 place-items-center bg-[#1E5C3F]" aria-hidden="true">
                <span className="h-2 w-2 bg-[#FAF7F0]" />
              </span>
              Northbeam
            </p>
            <p className="mt-3 max-w-sm text-xs leading-relaxed text-[#191919]/50">
              Fictional concept brand. No real products, orders or payments.
            </p>
          </div>
          <nav aria-label="Northbeam footer" className="flex flex-wrap items-center gap-x-7 gap-y-3">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-sm text-[#191919]/55 transition-colors hover:text-[#191919]"
              >
                {item.label}
              </a>
            ))}
            <a
              href="/work"
              className="text-sm text-[#1E5C3F] underline underline-offset-4 transition-colors hover:text-[#123B2A]"
            >
              More concept work
            </a>
          </nav>
        </div>
      </footer>
    </div>
  );
}
