import type { Metadata } from "next";
import { Archivo_Black, Inter } from "next/font/google";
import { HeroEntrance, Reveal } from "@/components/motion/reveal";
import { Marquee } from "@/components/motion/marquee";
import { DemoImage } from "@/components/demos/demo-image";
import { FootwearCartProvider } from "@/components/demos/footwear/cart";
import { FootwearHeader } from "@/components/demos/footwear/header";
import { FootwearShop } from "@/components/demos/footwear/shop";
import { cn } from "@/lib/utils";

const archivoBlack = Archivo_Black({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-solstice-display",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-solstice-body",
  display: "swap",
});

const DISPLAY = "font-[family-name:var(--font-solstice-display)]";

export const metadata: Metadata = {
  title: { absolute: "SOLSTICE — Concept Demo | Cybexs Tech" },
  description:
    "Interactive concept demo: a bold footwear store with category filtering, size selection and a fully working demo cart. A fictional brand by Cybexs Tech.",
  robots: { index: false, follow: false },
};

const MARQUEE_ITEMS = [
  "Free shipping over €120",
  "New drops every Friday",
  "30-day demo returns",
  "Demo store — nothing is for sale",
];

export default function FootwearDemoPage() {
  return (
    <div
      className={cn(
        archivoBlack.variable,
        inter.variable,
        "min-h-screen bg-[#F4F1EA] font-[family-name:var(--font-solstice-body)] text-[#141414]",
      )}
    >
      <FootwearCartProvider>
        <FootwearHeader />

        <main id="top">
          {/* Hero */}
          <section className="relative flex min-h-[80svh] items-end overflow-hidden">
            <DemoImage
              priority
              src="/demo-assets/footwear/hero.jpg"
              alt="SOLSTICE campaign — a sneaker mid-step on city concrete"
              sizes="100vw"
              className="absolute inset-0 bg-gradient-to-br from-[#2B2620] via-[#4A4038] to-[#141414]"
              fallbackLabel="SOLSTICE"
            />
            <div
              aria-hidden="true"
              className="absolute inset-0 bg-gradient-to-t from-[#141414]/85 via-[#141414]/40 to-[#141414]/30"
            />
            <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-32 sm:px-8 sm:pb-20">
              <HeroEntrance>
                <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-[#FF4D2E]">
                  A fictional footwear label
                </p>
                <h1
                  className={cn(
                    DISPLAY,
                    "mt-5 max-w-4xl text-5xl uppercase leading-[0.95] text-white sm:text-7xl lg:text-8xl",
                  )}
                >
                  Built for the <span className="text-[#FF4D2E]">streets.</span>
                </h1>
                <p className="mt-6 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">
                  Four silhouettes, one loud opinion. SOLSTICE is a demo storefront — real filters, real sizes, a real
                  cart, and absolutely nothing to buy.
                </p>
                <div className="mt-9 flex flex-wrap items-center gap-4">
                  <a
                    href="#shop"
                    className="bg-[#FF4D2E] px-7 py-3.5 text-xs font-bold uppercase tracking-[0.2em] text-white transition-colors hover:bg-[#E43E20] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                  >
                    Shop the line
                  </a>
                  <a
                    href="#about"
                    className="border border-white/30 px-7 py-3.5 text-xs font-bold uppercase tracking-[0.2em] text-white transition-colors hover:border-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                  >
                    Why this exists
                  </a>
                </div>
              </HeroEntrance>
            </div>
          </section>

          {/* Marquee strip */}
          <Marquee speed={26} className="border-y border-[#141414]/10 bg-[#FF4D2E] py-3">
            <div className="flex items-center">
              {MARQUEE_ITEMS.map((item) => (
                <span
                  key={item}
                  className="mx-5 flex items-center gap-10 text-xs font-bold uppercase tracking-[0.25em] text-white"
                >
                  {item}
                  <span aria-hidden="true" className="text-[#141414]">•</span>
                </span>
              ))}
            </div>
          </Marquee>

          <FootwearShop />

          {/* About */}
          <section id="about" className="scroll-mt-16 border-t border-[#141414]/10 bg-[#ECE7DB]">
            <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-2">
              <Reveal>
                <h2 className={cn(DISPLAY, "text-4xl uppercase leading-[1.02] text-[#141414] sm:text-5xl")}>
                  Loud shoes. <span className="text-[#FF4D2E]">Quiet honesty.</span>
                </h2>
              </Reveal>
              <Reveal delay={0.1} className="space-y-5 text-base leading-relaxed text-[#141414]/70 sm:text-lg">
                <p>
                  SOLSTICE is not a shoe company. It is a fictional label drawn up by Cybexs Tech to show what an
                  expressive, streetwise storefront feels like when every part of it actually works — the filters, the
                  size pills, the cart drawer, the badge that quietly judges you for buying four pairs.
                </p>
                <p>
                  There is no factory, no warehouse and no checkout that goes anywhere. What you are looking at is the
                  craft: art direction, interaction design and the boring, important details like focus states and
                  reduced-motion support.
                </p>
                <p className="text-sm uppercase tracking-[0.2em] text-[#141414]/45">
                  Fictional concept brand. No real products, orders or payments.
                </p>
              </Reveal>
            </div>
          </section>
        </main>

        <footer className="bg-[#141414] text-[#F4F1EA]">
          <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-14 sm:px-8 md:flex-row md:items-end md:justify-between">
            <div>
              <p className={cn(DISPLAY, "text-3xl uppercase tracking-tight sm:text-4xl")}>
                SOLSTICE<span className="text-[#FF4D2E]">.</span>
              </p>
              <p className="mt-3 max-w-sm text-xs leading-relaxed text-[#F4F1EA]/50">
                Fictional concept brand. No real products, orders or payments.
              </p>
            </div>
            <nav aria-label="SOLSTICE footer" className="flex flex-wrap items-center gap-x-7 gap-y-3">
              <a
                href="#shop"
                className="text-xs font-bold uppercase tracking-[0.2em] text-[#F4F1EA]/60 transition-colors hover:text-white"
              >
                Shop
              </a>
              <a
                href="#about"
                className="text-xs font-bold uppercase tracking-[0.2em] text-[#F4F1EA]/60 transition-colors hover:text-white"
              >
                About
              </a>
              <a
                href="/work"
                className="text-xs font-bold uppercase tracking-[0.2em] text-[#FF4D2E] underline underline-offset-4 transition-colors hover:text-white"
              >
                More concept work
              </a>
            </nav>
          </div>
        </footer>
      </FootwearCartProvider>
    </div>
  );
}
