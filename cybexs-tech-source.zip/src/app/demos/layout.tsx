import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata: Metadata = {
  title: "Concept Demo | Cybexs Tech",
  robots: { index: false, follow: false },
};

/**
 * Root layout for all concept demos. Renders children directly and keeps a
 * persistent disclosure banner visible at all times.
 */
export default function DemosLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <div
        role="note"
        aria-label="Concept demo notice"
        className="sticky top-0 z-50 border-b border-white/10 bg-[#111110] text-white"
      >
        <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-2 sm:justify-between sm:px-6">
          <p className="text-center text-[11px] leading-snug tracking-wide text-neutral-300 sm:text-left sm:text-xs">
            <span className="font-semibold text-white">Concept demo</span>
            {" — "}
            fictional brand created by Cybexs Tech to demonstrate our design &amp; engineering craft.
          </p>
          <Link
            href="/work"
            className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-white/20 px-3 py-1 text-[11px] font-medium text-white transition-colors hover:border-white hover:bg-white hover:text-black focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white sm:text-xs"
          >
            <ArrowLeft className="h-3 w-3" aria-hidden="true" />
            Back to Cybexs Tech
          </Link>
        </div>
      </div>
      {children}
    </div>
  );
}
