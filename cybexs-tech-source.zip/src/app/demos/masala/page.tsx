import type { Metadata } from "next";
import { Fraunces, Karla } from "next/font/google";
import { HeroEntrance, PopIn, Reveal } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { SpiceShop } from "@/components/demos/masala/spice-shop";
import { Recipes } from "@/components/demos/masala/recipes";
import { Newsletter } from "@/components/demos/masala/newsletter";
import { cn } from "@/lib/utils";

const fraunces = Fraunces({
  subsets: ["latin"],
  style: ["normal", "italic"],
  variable: "--font-garam-display",
  display: "swap",
});

const karla = Karla({
  subsets: ["latin"],
  variable: "--font-garam-body",
  display: "swap",
});

const DISPLAY = "font-[family-name:var(--font-garam-display)]";

export const metadata: Metadata = {
  title: { absolute: "Garam Theory — Concept Demo | Cybexs Tech" },
  description:
    "Interactive concept demo: a rich spice-house brand with a heat-level explorer, blend discovery, recipe pairings and a demo newsletter. A fictional brand by Cybexs Tech.",
  robots: { index: false, follow: false },
};

export default function MasalaDemoPage() {
  return (
    <div
      className={cn(
        fraunces.variable,
        karla.variable,
        "relative min-h-screen bg-[#1A0F08] font-[family-name:var(--font-garam-body)] text-[#1A0F08]",
      )}
    >
      <header className="absolute inset-x-0 top-0 z-40">
        <nav aria-label="Garam Theory" className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
          <a href="#top" className={cn(DISPLAY, "text-lg font-semibold tracking-[0.2em] text-[#FBF3E4] sm:text-xl")}>
            GARAM THEORY
          </a>
          <div className="flex items-center gap-4 sm:gap-8">
            <nav aria-label="Garam Theory sections" className="hidden items-center gap-7 sm:flex">
              {[
                { label: "Shop", href: "#shop" },
                { label: "Learn", href: "#learn" },
                { label: "Theory", href: "#theory" },
              ].map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-[11px] uppercase tracking-[0.25em] text-[#FBF3E4]/70 transition-colors hover:text-[#FBF3E4]"
                >
                  {item.label}
                </a>
              ))}
            </nav>
            <a
              href="#shop"
              className="bg-[#E8A020] px-4 py-2 text-[10px] font-bold uppercase tracking-[0.22em] text-[#1A0F08] transition-colors hover:bg-[#F5B53B] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E8A020] sm:text-[11px]"
            >
              Shop blends
            </a>
          </div>
        </nav>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="relative flex min-h-[88svh] items-end overflow-hidden">
          <DemoImage
            priority
            src="/demo-assets/masala/hero.jpg"
            alt="Garam Theory hero — whole spices scattered across dark stoneware"
            sizes="100vw"
            className="absolute inset-0 bg-gradient-to-br from-[#2B180A] via-[#4A2410] to-[#1A0F08]"
            fallbackLabel="Garam Theory"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#1A0F08]/95 via-[#1A0F08]/60 to-[#1A0F08]/55"
          />
          <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-32 sm:px-8 sm:pb-20">
            <HeroEntrance>
              <p className="text-[11px] font-bold uppercase tracking-[0.4em] text-[#E8A020]">
                A fictional spice house
              </p>
              <h1
                className={cn(
                  DISPLAY,
                  "mt-5 max-w-3xl text-5xl font-semibold leading-[1.04] text-[#FBF3E4] sm:text-7xl",
                )}
              >
                Heat, with a <em className="italic text-[#E8A020]">vocabulary</em>.
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-[#FBF3E4]/75 sm:text-lg">
                Small-batch blends from a kitchen that does not exist — built to show how product, story and
                interaction can share one pan. Warmth you can adjust; nothing you can actually buy.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#shop"
                  className="bg-[#E8A020] px-7 py-3.5 text-xs font-bold uppercase tracking-[0.22em] text-[#1A0F08] transition-colors hover:bg-[#F5B53B] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FBF3E4]"
                >
                  Explore the blends
                </a>
                <a
                  href="#theory"
                  className="border border-[#FBF3E4]/30 px-7 py-3.5 text-xs font-bold uppercase tracking-[0.22em] text-[#FBF3E4] transition-colors hover:border-[#FBF3E4] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FBF3E4]"
                >
                  Read the theory
                </a>
              </div>
            </HeroEntrance>
          </div>
        </section>

        <SpiceShop />
        <Recipes />

        {/* The Theory */}
        <section id="theory" className="scroll-mt-16 bg-[#FBF3E4]">
          <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <Reveal>
                <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-[#C2410C]">The Theory</p>
                <h2 className={cn(DISPLAY, "mt-4 text-3xl font-semibold leading-tight text-[#1A0F08] sm:text-4xl")}>
                  Spice is a sentence, not a shout.
                </h2>
              </Reveal>
            </div>
            <div className="lg:col-span-7 lg:col-start-6">
              <Reveal delay={0.1} className="space-y-6 text-base leading-relaxed text-[#1A0F08]/70 sm:text-lg">
                <p>
                  Every serious cuisine arrives at the same trick from a different direction: heat is a frame, not the
                  picture. Bloom the ground spices in fat at the start so they dissolve into the dish instead of
                  sitting on it. Temper whole spices at the end so they arrive late, loud and full of aroma. Everything
                  in between is just salt and acid keeping time.
                </p>
                <PopIn>
                  <blockquote
                    className={cn(
                      DISPLAY,
                      "border-l-2 border-[#E8A020] pl-6 text-2xl font-semibold italic leading-snug text-[#1A0F08] sm:text-3xl",
                    )}
                  >
                    &ldquo;Chili is a volume knob. Garam masala is the chord behind it.&rdquo;
                  </blockquote>
                </PopIn>
                <p>
                  That is the whole theory: layer early for depth, layer late for drama, and never let one note drown
                  the rest. Garam Theory — the brand, the tins, the prices — is a fiction by Cybexs Tech. The cooking
                  advice, unusually for a demo, is real. Try the dal.
                </p>
              </Reveal>
            </div>
          </div>
        </section>

        <Newsletter />
      </main>

      <footer className="border-t border-white/10 bg-[#1A0F08] text-[#FBF3E4]">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-end md:justify-between">
          <div>
            <p className={cn(DISPLAY, "text-xl font-semibold tracking-[0.2em] text-[#FBF3E4]")}>GARAM THEORY</p>
            <p className="mt-3 max-w-sm text-xs leading-relaxed text-[#FBF3E4]/50">
              Fictional concept brand. No real products, orders or payments.
            </p>
          </div>
          <nav aria-label="Garam Theory footer" className="flex flex-wrap items-center gap-x-7 gap-y-3">
            {[
              { label: "Shop", href: "#shop" },
              { label: "Learn", href: "#learn" },
              { label: "Theory", href: "#theory" },
            ].map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-[11px] uppercase tracking-[0.25em] text-[#FBF3E4]/60 transition-colors hover:text-[#FBF3E4]"
              >
                {item.label}
              </a>
            ))}
            <a
              href="/work"
              className="text-[11px] uppercase tracking-[0.25em] text-[#E8A020] underline underline-offset-4 transition-colors hover:text-[#FBF3E4]"
            >
              More concept work
            </a>
          </nav>
        </div>
      </footer>
    </div>
  );
}
