import type { Metadata } from "next";
import { Cormorant_Garamond, Jost } from "next/font/google";
import { HeroEntrance, Reveal } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { PerfumeCartProvider } from "@/components/demos/perfume/cart";
import { PerfumeCollection } from "@/components/demos/perfume/collection";
import { NotesExplorer } from "@/components/demos/perfume/notes-explorer";
import { DiscoverySet } from "@/components/demos/perfume/discovery-set";
import { cn } from "@/lib/utils";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-elore-display",
  display: "swap",
});

const jost = Jost({
  subsets: ["latin"],
  variable: "--font-elore-body",
  display: "swap",
});

const DISPLAY = "font-[family-name:var(--font-elore-display)]";

export const metadata: Metadata = {
  title: { absolute: "Maison Élore — Concept Demo | Cybexs Tech" },
  description:
    "Interactive concept demo: a luxury fragrance house with editorial product storytelling, a scent-note explorer and a demo discovery-set checkout. A fictional brand by Cybexs Tech.",
  robots: { index: false, follow: false },
};

const NAV = [
  { label: "Collection", href: "#collection" },
  { label: "Notes", href: "#notes" },
  { label: "Story", href: "#story" },
];

export default function PerfumeDemoPage() {
  return (
    <div
      id="top"
      className={cn(
        cormorant.variable,
        jost.variable,
        "relative min-h-screen bg-[#F7F3EC] font-[family-name:var(--font-elore-body)] text-[#1C1917]",
      )}
    >
      <header className="absolute inset-x-0 top-0 z-40">
        <nav
          aria-label="Maison Élore"
          className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8"
        >
          <a
            href="#top"
            className={cn(DISPLAY, "text-base font-semibold tracking-[0.35em] text-[#F7F3EC] sm:text-lg")}
          >
            MAISON ÉLORE
          </a>
          <div className="flex items-center gap-4 sm:gap-8">
            <nav aria-label="Maison Élore sections" className="hidden items-center gap-7 sm:flex">
              {NAV.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-[11px] uppercase tracking-[0.25em] text-[#F7F3EC]/75 transition-colors hover:text-[#F7F3EC]"
                >
                  {item.label}
                </a>
              ))}
            </nav>
            <a
              href="#discovery"
              className="border border-[#B49B6C] px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-[#D8C29A] transition-colors hover:bg-[#B49B6C] hover:text-[#1C1917] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B49B6C] sm:text-[11px]"
            >
              Discovery Set
            </a>
          </div>
        </nav>
      </header>

      <main>
        {/* Hero */}
        <section className="relative flex min-h-[92svh] items-end overflow-hidden">
          <DemoImage
            priority
            src="/demo-assets/perfume/hero.jpg"
            alt="Maison Élore campaign — an amber glass flacon in warm directional light"
            sizes="100vw"
            className="absolute inset-0 bg-gradient-to-br from-[#2A231C] via-[#4A3B2A] to-[#14100C]"
            fallbackLabel="Maison Élore"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#14100C]/90 via-[#14100C]/35 to-[#14100C]/45"
          />
          <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-32 sm:px-8 sm:pb-24">
            <HeroEntrance>
              <p className="text-[11px] uppercase tracking-[0.4em] text-[#F7F3EC]/70">
                Haute Parfumerie — Grasse, in fiction
              </p>
              <h1
                className={cn(
                  DISPLAY,
                  "mt-5 max-w-3xl text-5xl font-light leading-[1.05] text-[#F7F3EC] sm:text-7xl",
                )}
              >
                Wear the <em className="italic text-[#D8C29A]">hours</em>.
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-[#F7F3EC]/75 sm:text-lg">
                Three compositions. One discovery set. A fictional house built to show how far restraint, typography
                and patience can carry a product story.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#collection"
                  className="bg-[#B49B6C] px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.25em] text-[#1C1917] transition-colors hover:bg-[#C9B183] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F7F3EC]"
                >
                  Explore the collection
                </a>
                <a
                  href="#story"
                  className="border border-[#F7F3EC]/30 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.25em] text-[#F7F3EC] transition-colors hover:border-[#F7F3EC] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F7F3EC]"
                >
                  Our story
                </a>
              </div>
            </HeroEntrance>
          </div>
        </section>

        {/* Interactive store: collection + notes + discovery set share demo-cart state */}
        <PerfumeCartProvider>
          <PerfumeCollection />
          <NotesExplorer />

          {/* Story */}
          <section id="story" className="scroll-mt-16">
            <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-12">
              <div className="lg:col-span-4">
                <Reveal>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#B49B6C]">The Story</p>
                  <h2 className={cn(DISPLAY, "mt-4 text-3xl font-light leading-tight text-[#1C1917] sm:text-4xl")}>
                    A house that whispers.
                  </h2>
                </Reveal>
              </div>
              <div className="lg:col-span-7 lg:col-start-6">
                <Reveal delay={0.1} className="space-y-6 text-base leading-relaxed text-[#1C1917]/70 sm:text-lg">
                  <p>
                    <span className={cn(DISPLAY, "float-left mr-3 mt-1 text-6xl leading-[0.8] text-[#B49B6C]")}>É</span>
                    lore was founded — on paper, in a design studio — on a single conviction: that luxury is the
                    confidence to leave things out. No logos on the flacon. No color on the box. Just glass, paper,
                    type and time.
                  </p>
                  <p>
                    Each fragrance is composed around a moment rather than an ingredient: the hour the lights go down,
                    the hour the library closes, the hour the forest goes quiet. The collection is deliberately small.
                    We would rather perfect three hours than sample twenty.
                  </p>
                  <blockquote
                    className={cn(
                      DISPLAY,
                      "border-l-2 border-[#B49B6C] pl-6 text-2xl font-light italic leading-snug text-[#1C1917] sm:text-3xl",
                    )}
                  >
                    &ldquo;We wanted a house that whispers — where the type, the paper and the juice all speak at the
                    same volume.&rdquo;
                  </blockquote>
                  <p className="text-sm uppercase tracking-[0.25em] text-[#1C1917]/40">
                    The (fictional) founders, on designing Élore
                  </p>
                  <p className="text-sm leading-relaxed text-[#1C1917]/50">
                    Élore itself is a fiction — a brand invented by Cybexs Tech to demonstrate editorial e-commerce
                    craft: product storytelling, note exploration and a fully working (fully fake) discovery-set
                    checkout.
                  </p>
                </Reveal>
              </div>
            </div>
          </section>

          <DiscoverySet />
        </PerfumeCartProvider>
      </main>

      <footer className="border-t border-[#1C1917]/10 bg-[#F7F3EC]">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-end md:justify-between">
          <div>
            <p className={cn(DISPLAY, "text-xl font-semibold tracking-[0.35em] text-[#1C1917]")}>MAISON ÉLORE</p>
            <p className="mt-3 max-w-sm text-xs leading-relaxed text-[#1C1917]/50">
              Fictional concept brand. No real products, orders or payments.
            </p>
          </div>
          <nav aria-label="Maison Élore footer" className="flex flex-wrap items-center gap-x-7 gap-y-3">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-[11px] uppercase tracking-[0.25em] text-[#1C1917]/55 transition-colors hover:text-[#1C1917]"
              >
                {item.label}
              </a>
            ))}
            <a
              href="/work"
              className="text-[11px] uppercase tracking-[0.25em] text-[#B49B6C] underline underline-offset-4 transition-colors hover:text-[#1C1917]"
            >
              More concept work
            </a>
          </nav>
        </div>
      </footer>
    </div>
  );
}
