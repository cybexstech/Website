import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata = {
  title: { absolute: "Page not found | Cybexs Tech" },
  robots: { index: false, follow: false },
};

export default function NotFound() {
  return (
    <div className="noise-overlay relative flex min-h-screen flex-col overflow-hidden bg-[var(--ink)] text-white">
      <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
      <div
        className="absolute -right-32 -top-32 h-96 w-96 rounded-full opacity-20 blur-[120px]"
        style={{ background: "radial-gradient(circle, #FF3B30 0%, transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="container-site relative flex flex-1 flex-col items-start justify-center py-24">
        <p className="eyebrow !text-neutral-400">404</p>
        <h1 className="display-1 mt-4">
          This page doesn&apos;t <span className="text-stroke">exist.</span>
        </h1>
        <p className="lede mt-6 max-w-xl !text-neutral-400">
          The page you&apos;re looking for was moved, renamed, or never existed. Let&apos;s get you back on track.
        </p>
        <div className="mt-10 flex flex-wrap gap-4">
          <Link href="/" className="btn-accent">
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            Back to homepage
          </Link>
          <Link href="/services" className="btn-outline-light">
            Explore services
          </Link>
        </div>
      </div>
    </div>
  );
}
