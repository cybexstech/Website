"use client";

import * as React from "react";
import ReactMarkdown from "react-markdown";
import { format } from "date-fns";
import {
  ExternalLink,
  FileText,
  Loader2,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";

import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { ApiError, TableSkeletonRows, apiFetch, formatDate, timeAgo, useAdminUser } from "./shared";
import type { ArticleListItem, ArticleRecord, ArticleResponse, ArticlesResponse } from "./types";

/* ---------------------------------------------------------------------------
 * Form state
 * ------------------------------------------------------------------------- */

interface ArticleFormState {
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string;
  author: string;
  readMinutes: string;
  published: boolean;
  publishedAt: string; // datetime-local value
  seoTitle: string;
  seoDescription: string;
  featuredImage: string;
}

const EMPTY_FORM: ArticleFormState = {
  title: "",
  slug: "",
  excerpt: "",
  content: "",
  category: "",
  tags: "",
  author: "Cybexs Tech Team",
  readMinutes: "6",
  published: false,
  publishedAt: "",
  seoTitle: "",
  seoDescription: "",
  featuredImage: "",
};

const SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function toLocalInput(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/* ---------------------------------------------------------------------------
 * Content manager — article list + editor dialog
 * ------------------------------------------------------------------------- */

export function ContentManager() {
  const { toast } = useToast();
  const user = useAdminUser();
  const isAdmin = user?.role === "ADMIN";

  const [articles, setArticles] = React.useState<ArticleListItem[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [reloadKey, setReloadKey] = React.useState(0);

  const [editorOpen, setEditorOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<ArticleListItem | null>(null);
  const [editLoading, setEditLoading] = React.useState(false);
  const [form, setForm] = React.useState<ArticleFormState>(EMPTY_FORM);
  const [slugTouched, setSlugTouched] = React.useState(false);
  const [fieldErrors, setFieldErrors] = React.useState<Record<string, string>>({});
  const [saving, setSaving] = React.useState(false);
  const [contentTab, setContentTab] = React.useState<"write" | "preview">("write");

  const [deleteTarget, setDeleteTarget] = React.useState<ArticleListItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    setError(null);
    apiFetch<ArticlesResponse>("/api/admin/articles")
      .then((json) => {
        if (!cancelled) setArticles(json.articles);
      })
      .catch((err: unknown) => {
        if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load articles.");
      });
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  // Auto-generate slug from the title until the slug field is manually touched.
  React.useEffect(() => {
    if (slugTouched) return;
    setForm((f) => ({ ...f, slug: slugify(f.title) }));
  }, [form.title, slugTouched]);

  function updateField<K extends keyof ArticleFormState>(field: K, value: ArticleFormState[K]) {
    setForm((f) => ({ ...f, [field]: value }));
    setFieldErrors((prev) => {
      if (!(field in prev)) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  }

  function openNewEditor() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setSlugTouched(false);
    setFieldErrors({});
    setContentTab("write");
    setEditorOpen(true);
  }

  async function openEditEditor(item: ArticleListItem) {
    setEditing(item);
    setFieldErrors({});
    setContentTab("write");
    setEditLoading(true);
    setEditorOpen(true);
    try {
      const json = await apiFetch<ArticleResponse>(`/api/admin/articles/${item.id}`);
      const a = json.article;
      setForm({
        title: a.title,
        slug: a.slug,
        excerpt: a.excerpt,
        content: a.content,
        category: a.category,
        tags: a.tags,
        author: a.author || "Cybexs Tech Team",
        readMinutes: String(a.readMinutes),
        published: a.status === "PUBLISHED",
        publishedAt: toLocalInput(a.publishedAt),
        seoTitle: a.seoTitle ?? "",
        seoDescription: a.seoDescription ?? "",
        featuredImage: a.featuredImage ?? "",
      });
      setSlugTouched(true); // keep the stored slug while editing
    } catch (err) {
      setEditorOpen(false);
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not load article",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setEditLoading(false);
    }
  }

  async function saveArticle() {
    if (saving || !form) return;
    setSaving(true);
    setFieldErrors({});

    const payload = {
      title: form.title.trim(),
      slug: form.slug.trim().toLowerCase(),
      excerpt: form.excerpt.trim(),
      content: form.content,
      category: form.category.trim(),
      tags: form.tags.trim(),
      status: form.published ? "PUBLISHED" : "DRAFT",
      seoTitle: form.seoTitle.trim(),
      seoDescription: form.seoDescription.trim(),
      featuredImage: form.featuredImage.trim(),
      author: form.author.trim() || "Cybexs Tech Team",
      readMinutes: Number(form.readMinutes) > 0 ? Math.round(Number(form.readMinutes)) : 6,
      publishedAt: form.published && form.publishedAt ? new Date(form.publishedAt).toISOString() : null,
    };

    try {
      if (editing) {
        await apiFetch<ArticleResponse>(`/api/admin/articles/${editing.id}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        toast({ title: "Article updated", description: payload.title });
      } else {
        await apiFetch<ArticleResponse>("/api/admin/articles", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        toast({ title: "Article created", description: payload.title });
      }
      setEditorOpen(false);
      setReloadKey((k) => k + 1);
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.fieldErrors) setFieldErrors(err.fieldErrors);
        if (err.status !== 401 && err.status !== 0) {
          toast({ title: "Could not save article", description: err.message, variant: "destructive" });
        }
      }
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget || deleting) return;
    setDeleting(true);
    try {
      await apiFetch(`/api/admin/articles/${deleteTarget.id}`, { method: "DELETE" });
      toast({ title: "Article deleted", description: deleteTarget.title });
      setDeleteTarget(null);
      setReloadKey((k) => k + 1);
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not delete article",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  }

  const slugValid = SLUG_PATTERN.test(form.slug.trim());

  return (
    <div className="space-y-4">
      {/* Header row */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral-500" aria-live="polite">
          {articles ? `${articles.length} article${articles.length === 1 ? "" : "s"}` : "Loading articles…"}
        </p>
        {isAdmin ? (
          <Button size="sm" className="self-start bg-neutral-900 text-white hover:bg-neutral-800 sm:self-auto" onClick={openNewEditor}>
            <Plus className="size-4" aria-hidden />
            New article
          </Button>
        ) : (
          <Tooltip>
            <TooltipTrigger asChild>
              <span
                tabIndex={0}
                role="button"
                aria-disabled="true"
                aria-label="New article — administrator role required"
                className="inline-flex cursor-not-allowed self-start rounded-md sm:self-auto"
              >
                <Button size="sm" disabled>
                  <Plus className="size-4" aria-hidden />
                  New article
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent>Administrator role required</TooltipContent>
          </Tooltip>
        )}
      </div>

      {/* List */}
      <Card className="overflow-hidden p-0">
        {articles === null ? (
          <Table>
            <TableHeader>
              <TableRow className="bg-neutral-50/80 hover:bg-transparent">
                <TableHead className="pl-4">Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead>Published</TableHead>
                <TableHead className="pr-4 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {error ? (
                <TableRow className="hover:bg-transparent">
                  <TableCell colSpan={6} className="py-12 text-center text-sm text-neutral-500">
                    {error}
                  </TableCell>
                </TableRow>
              ) : (
                <TableSkeletonRows rows={5} cols={6} />
              )}
            </TableBody>
          </Table>
        ) : articles.length === 0 ? (
          <div className="py-16 text-center">
            <FileText className="mx-auto size-8 text-neutral-300" aria-hidden />
            <p className="mt-3 text-sm text-neutral-500">No articles yet.</p>
            {isAdmin ? (
              <Button variant="outline" size="sm" className="mt-3" onClick={openNewEditor}>
                <Plus className="size-4" aria-hidden />
                Write the first article
              </Button>
            ) : null}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-neutral-50/80 hover:bg-transparent">
                <TableHead className="pl-4">Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead>Published</TableHead>
                <TableHead className="pr-4 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {articles.map((article) => (
                <TableRow key={article.id}>
                  <TableCell className="pl-4">
                    <span className="block max-w-[280px] truncate text-sm font-medium text-neutral-900" title={article.title}>
                      {article.title}
                    </span>
                    <span className="block max-w-[280px] truncate text-xs text-neutral-500" title={`/${article.slug}`}>
                      /{article.slug}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-neutral-700">{article.category}</span>
                  </TableCell>
                  <TableCell>
                    <ArticleStatusBadge status={article.status} />
                  </TableCell>
                  <TableCell>
                    <span className="text-sm whitespace-nowrap text-neutral-600">{timeAgo(article.updatedAt)}</span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm whitespace-nowrap text-neutral-600">
                      {article.publishedAt ? formatDate(article.publishedAt) : "—"}
                    </span>
                  </TableCell>
                  <TableCell className="pr-4">
                    <div className="flex items-center justify-end gap-1.5">
                      {article.status === "PUBLISHED" ? (
                        <Button variant="ghost" size="sm" asChild>
                          <a href={`/insights/${article.slug}`} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="size-4" aria-hidden />
                            View live
                          </a>
                        </Button>
                      ) : null}
                      {isAdmin ? (
                        <>
                          <Button variant="outline" size="sm" onClick={() => void openEditEditor(article)}>
                            <Pencil className="size-4" aria-hidden />
                            Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-[#D93025] hover:bg-[#FF3B30]/10 hover:text-[#C62A21]"
                            onClick={() => setDeleteTarget(article)}
                          >
                            <Trash2 className="size-4" aria-hidden />
                            <span className="sr-only">Delete {article.title}</span>
                          </Button>
                        </>
                      ) : null}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>

      {/* Editor dialog */}
      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit article" : "New article"}</DialogTitle>
            <DialogDescription>
              Markdown content powers the /insights pages. Drafts stay private until published.
            </DialogDescription>
          </DialogHeader>

          {editLoading ? (
            <div className="space-y-4 py-6">
              <Skeleton className="h-9 w-full" />
              <Skeleton className="h-9 w-full" />
              <Skeleton className="h-32 w-full" />
              <div className="flex justify-end">
                <Loader2 className="size-4 animate-spin text-neutral-400" aria-hidden />
              </div>
            </div>
          ) : (
            <>
              <div className="scrollbar-slim max-h-[calc(85vh-11rem)] space-y-5 overflow-y-auto pr-2">
                <div className="grid gap-4 sm:grid-cols-2">
                  <EditorField label="Title" htmlFor="article-title" required error={fieldErrors.title} counter={`${form.title.length}/200`}>
                    <Input
                      id="article-title"
                      value={form.title}
                      onChange={(e) => updateField("title", e.target.value)}
                      maxLength={200}
                    />
                  </EditorField>
                  <EditorField
                    label="Slug"
                    htmlFor="article-slug"
                    required
                    error={fieldErrors.slug ?? (!slugValid ? "Slug may contain lowercase letters, numbers and hyphens only." : undefined)}
                    hint="Auto-generated from the title. Editable."
                  >
                    <Input
                      id="article-slug"
                      value={form.slug}
                      onChange={(e) => {
                        setSlugTouched(true);
                        updateField("slug", e.target.value.toLowerCase());
                      }}
                      className={cn(!slugValid && "border-[#FF3B30]/50 focus-visible:ring-[#FF3B30]/30")}
                    />
                  </EditorField>
                </div>

                <EditorField
                  label="Excerpt"
                  htmlFor="article-excerpt"
                  required
                  error={fieldErrors.excerpt}
                  counter={
                    <span className={cn(form.excerpt.length > 400 && "font-medium text-[#D93025]")}>
                      {form.excerpt.length}/400
                    </span>
                  }
                  hint="20–400 characters. Shown on listing pages and cards."
                >
                  <Textarea
                    id="article-excerpt"
                    value={form.excerpt}
                    onChange={(e) => updateField("excerpt", e.target.value)}
                    rows={2}
                    maxLength={400}
                  />
                </EditorField>

                <div className="grid gap-4 sm:grid-cols-3">
                  <EditorField label="Category" htmlFor="article-category" required error={fieldErrors.category}>
                    <Input
                      id="article-category"
                      value={form.category}
                      onChange={(e) => updateField("category", e.target.value)}
                      placeholder="AI Automation"
                      maxLength={80}
                    />
                  </EditorField>
                  <EditorField label="Tags" htmlFor="article-tags" error={fieldErrors.tags} hint="Comma-separated.">
                    <Input
                      id="article-tags"
                      value={form.tags}
                      onChange={(e) => updateField("tags", e.target.value)}
                      placeholder="ai, operations, smes"
                      maxLength={240}
                    />
                  </EditorField>
                  <EditorField label="Author" htmlFor="article-author" error={fieldErrors.author}>
                    <Input
                      id="article-author"
                      value={form.author}
                      onChange={(e) => updateField("author", e.target.value)}
                      maxLength={120}
                    />
                  </EditorField>
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <EditorField label="Read minutes" htmlFor="article-read" error={fieldErrors.readMinutes}>
                    <Input
                      id="article-read"
                      type="number"
                      min={1}
                      max={60}
                      value={form.readMinutes}
                      onChange={(e) => updateField("readMinutes", e.target.value)}
                    />
                  </EditorField>
                  <div className="flex items-end pb-1">
                    <div className="flex items-center gap-3">
                      <Switch
                        id="article-published"
                        checked={form.published}
                        onCheckedChange={(checked) => updateField("published", checked)}
                        aria-label="Published"
                      />
                      <Label htmlFor="article-published">{form.published ? "Published" : "Draft"}</Label>
                    </div>
                  </div>
                  <EditorField
                    label="Publish date & time"
                    htmlFor="article-published-at"
                    hint="Optional — defaults to now on first publish."
                  >
                    <Input
                      id="article-published-at"
                      type="datetime-local"
                      value={form.publishedAt}
                      onChange={(e) => updateField("publishedAt", e.target.value)}
                    />
                  </EditorField>
                </div>

                <Separator />

                <p className="text-xs font-medium tracking-wide text-neutral-500 uppercase">SEO</p>
                <div className="grid gap-4 sm:grid-cols-2">
                  <EditorField
                    label="SEO title"
                    htmlFor="article-seo-title"
                    error={fieldErrors.seoTitle}
                    counter={`${form.seoTitle.length}/200`}
                    hint="Falls back to the article title."
                  >
                    <Input
                      id="article-seo-title"
                      value={form.seoTitle}
                      onChange={(e) => updateField("seoTitle", e.target.value)}
                      maxLength={200}
                    />
                  </EditorField>
                  <EditorField
                    label="SEO description"
                    htmlFor="article-seo-description"
                    error={fieldErrors.seoDescription}
                    counter={
                      <span className={cn(form.seoDescription.length > 320 && "font-medium text-[#D93025]")}>
                        {form.seoDescription.length}/320
                      </span>
                    }
                    hint="Falls back to the excerpt."
                  >
                    <Input
                      id="article-seo-description"
                      value={form.seoDescription}
                      onChange={(e) => updateField("seoDescription", e.target.value)}
                      maxLength={320}
                    />
                  </EditorField>
                </div>

                <EditorField
                  label="Featured image"
                  htmlFor="article-image"
                  error={fieldErrors.featuredImage}
                  hint="Public image path e.g. /demo-assets/footwear/hero.jpg or absolute URL."
                >
                  <Input
                    id="article-image"
                    value={form.featuredImage}
                    onChange={(e) => updateField("featuredImage", e.target.value)}
                    placeholder="/demo-assets/…"
                    maxLength={400}
                  />
                </EditorField>

                <Separator />

                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <Label htmlFor="article-content">
                      Content (Markdown) <span className="text-neutral-400">— minimum 50 characters</span>
                    </Label>
                    <Tabs value={contentTab} onValueChange={(v) => setContentTab(v === "preview" ? "preview" : "write")}>
                      <TabsList className="h-8">
                        <TabsTrigger value="write" className="text-xs">
                          Write
                        </TabsTrigger>
                        <TabsTrigger value="preview" className="text-xs">
                          Preview
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {contentTab === "write" ? (
                    <Textarea
                      id="article-content"
                      value={form.content}
                      onChange={(e) => updateField("content", e.target.value)}
                      rows={14}
                      className="font-mono text-[13px] leading-relaxed"
                      aria-describedby="article-content-hint"
                    />
                  ) : (
                    <div
                      aria-live="polite"
                      className="min-h-[260px] rounded-md border border-neutral-200 bg-white p-4 text-sm leading-relaxed [&_a]:underline [&_blockquote]:border-l-2 [&_blockquote]:border-neutral-300 [&_blockquote]:pl-3 [&_blockquote]:text-neutral-600 [&_code]:rounded [&_code]:bg-neutral-100 [&_code]:px-1 [&_code]:py-0.5 [&_code]:text-xs [&_h1]:mt-4 [&_h1]:mb-2 [&_h1]:text-xl [&_h1]:font-semibold [&_h2]:mt-5 [&_h2]:mb-2 [&_h2]:text-lg [&_h2]:font-semibold [&_h3]:mt-4 [&_h3]:mb-1 [&_h3]:font-semibold [&_li]:ml-4 [&_ol]:my-2 [&_ol]:list-decimal [&_p]:my-2 [&_pre]:my-3 [&_pre]:overflow-x-auto [&_pre]:rounded-md [&_pre]:bg-neutral-100 [&_pre]:p-3 [&_pre]:text-xs [&_strong]:font-semibold [&_ul]:my-2 [&_ul]:list-disc"
                    >
                      <ReactMarkdown>{form.content || "_Nothing to preview yet._"}</ReactMarkdown>
                    </div>
                  )}
                  <p id="article-content-hint" className="text-xs text-neutral-400">
                    {"Markdown supported: # Heading, **bold**, - list, [link](url), `code`, > quote."}
                    {fieldErrors.content ? <span className="ml-2 font-medium text-[#D93025]">{fieldErrors.content}</span> : null}
                  </p>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setEditorOpen(false)} disabled={saving}>
                  Cancel
                </Button>
                <Button
                  onClick={() => void saveArticle()}
                  disabled={saving || !slugValid}
                  className="bg-neutral-900 text-white hover:bg-neutral-800"
                >
                  {saving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
                  {editing ? "Save changes" : "Create article"}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete article?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget ? `"${deleteTarget.title}" will be permanently removed from the CMS.` : ""} This cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void confirmDelete();
              }}
              disabled={deleting}
              className="bg-[#FF3B30] text-white hover:bg-[#E2322A]"
            >
              {deleting ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ---------------------------------------------------------------------------
 * Small presentational helpers
 * ------------------------------------------------------------------------- */

function ArticleStatusBadge({ status }: { status: string }) {
  const published = status === "PUBLISHED";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        published ? "border-emerald-200 bg-emerald-100 text-emerald-800" : "border-neutral-200 bg-neutral-100 text-neutral-600"
      )}
    >
      <span className={cn("size-1.5 rounded-full", published ? "bg-emerald-500" : "bg-neutral-400")} aria-hidden />
      {published ? "Published" : "Draft"}
    </span>
  );
}

function EditorField({
  label,
  htmlFor,
  required,
  error,
  hint,
  counter,
  children,
}: {
  label: string;
  htmlFor: string;
  required?: boolean;
  error?: string;
  hint?: string;
  counter?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <Label htmlFor={htmlFor}>
          {label}
          {required ? <span className="ml-0.5 text-[#FF3B30]" aria-hidden>*</span> : null}
        </Label>
        {counter ? <span className="text-[11px] text-neutral-400 tabular-nums">{counter}</span> : null}
      </div>
      {children}
      {error ? (
        <p role="alert" className="text-xs font-medium text-[#D93025]">
          {error}
        </p>
      ) : hint ? (
        <p className="text-xs text-neutral-400">{hint}</p>
      ) : null}
    </div>
  );
}
