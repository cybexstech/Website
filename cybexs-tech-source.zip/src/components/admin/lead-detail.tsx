"use client";

import * as React from "react";
import Link from "next/link";
import { format } from "date-fns";
import {
  ArrowLeft,
  CalendarIcon,
  CalendarClock,
  ExternalLink,
  Loader2,
  Send,
  UserRound,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  ApiError,
  CopyButton,
  EmailStatusBadge,
  STATUS_META,
  SourceBadge,
  apiFetch,
  formatDateTime,
  initials,
  timeAgo,
  useAdminUser,
  websiteHref,
} from "./shared";
import { LEAD_STATUSES, type LeadRecord, type LeadResponse, type LeadStatus, type LeadsResponse, type MeResponse, type NoteResponse, type ResendEmailResponse } from "./types";

/* ---------------------------------------------------------------------------
 * Lead detail — client view for /admin/leads/[id]
 * ------------------------------------------------------------------------- */

export function LeadDetail({ leadId }: { leadId: string }) {
  const { toast } = useToast();
  const user = useAdminUser();

  const [lead, setLead] = React.useState<LeadRecord | null>(null);
  const [owners, setOwners] = React.useState<string[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const [statusSaving, setStatusSaving] = React.useState(false);
  const [ownerInput, setOwnerInput] = React.useState("");
  const [ownerSaving, setOwnerSaving] = React.useState(false);
  const [followUpOpen, setFollowUpOpen] = React.useState(false);
  const [followUpSaving, setFollowUpSaving] = React.useState(false);
  const [noteInput, setNoteInput] = React.useState("");
  const [noteSaving, setNoteSaving] = React.useState(false);
  const [retrying, setRetrying] = React.useState(false);

  const loadLead = React.useCallback(async (): Promise<LeadRecord | null> => {
    try {
      const json = await apiFetch<LeadResponse>(`/api/admin/leads/${leadId}`);
      return json.lead;
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return null;
      setError(err instanceof Error ? err.message : "Failed to load lead.");
      return null;
    }
  }, [leadId]);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    async function boot() {
      const [leadResult, ownersResult] = await Promise.allSettled([
        loadLead(),
        apiFetch<LeadsResponse>("/api/admin/leads?pageSize=100"),
      ]);
      if (cancelled) return;
      if (leadResult.status === "fulfilled" && leadResult.value) {
        setLead(leadResult.value);
        setOwnerInput(leadResult.value.ownerName ?? "");
      } else if (leadResult.status === "rejected") {
        setError("Failed to load lead.");
      }
      if (ownersResult.status === "fulfilled") {
        setOwners(ownersResult.value.owners);
      }
      setLoading(false);
    }

    void boot();
    return () => {
      cancelled = true;
    };
  }, [loadLead]);

  async function changeStatus(next: LeadStatus) {
    if (!lead || lead.status === next || statusSaving) return;
    const previous = lead;
    setStatusSaving(true);
    setLead({ ...lead, status: next });
    try {
      await apiFetch<LeadResponse>(`/api/admin/leads/${leadId}`, {
        method: "PATCH",
        body: JSON.stringify({ status: next }),
      });
      toast({ title: "Status updated", description: STATUS_META[next].label });
      // Refetch so the system note created by the API shows up in the notes list.
      const fresh = await loadLead();
      if (fresh) setLead(fresh);
    } catch (err) {
      setLead(previous);
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not update status",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setStatusSaving(false);
    }
  }

  async function assignOwner(name: string | null) {
    if (!lead || ownerSaving) return;
    const previous = lead;
    setOwnerSaving(true);
    try {
      await apiFetch<LeadResponse>(`/api/admin/leads/${leadId}`, {
        method: "PATCH",
        body: JSON.stringify({ ownerName: name }),
      });
      setLead({ ...lead, ownerName: name });
      setOwnerInput(name ?? "");
      toast({ title: name ? "Owner assigned" : "Owner cleared", description: name ?? undefined });
    } catch (err) {
      setOwnerInput(previous.ownerName ?? "");
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not assign owner",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setOwnerSaving(false);
    }
  }

  async function saveFollowUp(date: Date | undefined) {
    if (!lead || followUpSaving) return;
    setFollowUpSaving(true);
    try {
      let iso: string | null = null;
      if (date) {
        // Local noon keeps the picked calendar date stable across timezones.
        const d = new Date(date);
        d.setHours(12, 0, 0, 0);
        iso = d.toISOString();
      }
      await apiFetch<LeadResponse>(`/api/admin/leads/${leadId}`, {
        method: "PATCH",
        body: JSON.stringify({ followUpDate: iso }),
      });
      setLead({ ...lead, followUpDate: iso });
      setFollowUpOpen(false);
      toast({ title: iso ? "Follow-up date set" : "Follow-up date cleared" });
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not save follow-up date",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setFollowUpSaving(false);
    }
  }

  async function addNote() {
    const body = noteInput.trim();
    if (!body || noteSaving) return;
    setNoteSaving(true);
    try {
      const json = await apiFetch<NoteResponse>(`/api/admin/leads/${leadId}/notes`, {
        method: "POST",
        body: JSON.stringify({ body }),
      });
      setLead((prev) => (prev ? { ...prev, notes: [json.note, ...(prev.notes ?? [])] } : prev));
      setNoteInput("");
      toast({ title: "Note added" });
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not add note",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setNoteSaving(false);
    }
  }

  async function retryEmail() {
    if (retrying) return;
    setRetrying(true);
    try {
      const json = await apiFetch<ResendEmailResponse>(`/api/admin/leads/${leadId}/resend-email`, {
        method: "POST",
      });
      if (json.result.status === "SENT") {
        toast({ title: "Notification resent", description: "The business notification was delivered." });
      } else {
        toast({
          title: "Retry attempted",
          description: json.result.error ?? `Provider returned status: ${json.result.status}`,
          variant: "destructive",
        });
      }
      const fresh = await loadLead();
      if (fresh) setLead(fresh);
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Retry failed",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setRetrying(false);
    }
  }

  /* ------------------------------- render ------------------------------- */

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-4 w-28" />
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-6">
            <Card className="p-6">
              <Skeleton className="h-8 w-52" />
              <Skeleton className="mt-2 h-4 w-40" />
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-4 w-full max-w-[180px]" />
                ))}
              </div>
            </Card>
            <Card className="p-6">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="mt-4 h-20 w-full" />
            </Card>
          </div>
          <Card className="p-6">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="mt-4 h-24 w-full" />
            <Skeleton className="mt-4 h-10 w-full" />
          </Card>
        </div>
      </div>
    );
  }

  if (error || !lead) {
    return (
      <Card className="p-6">
        <p className="text-sm font-medium text-neutral-900">{error ?? "Lead not found."}</p>
        <p className="mt-1 text-sm text-neutral-500">
          The lead may have been removed, or the link is out of date.
        </p>
        <Button variant="outline" size="sm" className="mt-4" asChild>
          <Link href="/admin/leads">
            <ArrowLeft className="size-4" aria-hidden />
            Back to leads
          </Link>
        </Button>
      </Card>
    );
  }

  const notes = lead.notes ?? [];
  const followUpDate = lead.followUpDate ? new Date(lead.followUpDate) : undefined;

  return (
    <div className="space-y-4">
      <Link
        href="/admin/leads"
        className="inline-flex items-center gap-1.5 text-sm text-neutral-500 transition-colors hover:text-neutral-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-300"
      >
        <ArrowLeft className="size-4" aria-hidden />
        Back to leads
      </Link>

      <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        {/* ------------------------------ Left column ------------------------------ */}
        <div className="space-y-6">
          {/* Contact */}
          <Card>
            <CardHeader>
              <div className="flex items-start gap-4">
                <span
                  aria-hidden
                  className="flex size-12 shrink-0 items-center justify-center rounded-full bg-neutral-100 font-display text-sm font-semibold text-neutral-700"
                >
                  {initials(lead.fullName) || "?"}
                </span>
                <div className="min-w-0">
                  <CardTitle className="font-display text-2xl font-semibold tracking-tight">
                    {lead.fullName}
                  </CardTitle>
                  <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-neutral-500">
                    <span>{lead.companyName}</span>
                    {lead.companyWebsite ? (
                      <>
                        <span aria-hidden>·</span>
                        <a
                          href={websiteHref(lead.companyWebsite)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-neutral-700 underline decoration-neutral-300 underline-offset-2 hover:decoration-neutral-600"
                        >
                          {lead.companyWebsite}
                          <ExternalLink className="size-3.5" aria-hidden />
                        </a>
                      </>
                    ) : null}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <dl className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                <DetailField label="Email">
                  <span className="flex items-center gap-1">
                    <span className="truncate">{lead.email}</span>
                    <CopyButton value={lead.email} label="email address" />
                  </span>
                </DetailField>
                <DetailField label="Source">
                  <SourceBadge source={lead.source} />
                </DetailField>
                <DetailField label="Service interest">
                  <span className="truncate">{lead.serviceInterest}</span>
                </DetailField>
                <DetailField label="Owner">
                  <span className="truncate">{lead.ownerName ?? "Unassigned"}</span>
                </DetailField>
                <DetailField label="Created">
                  <span className="whitespace-nowrap">
                    {formatDateTime(lead.createdAt)}{" "}
                    <span className="text-neutral-400">({timeAgo(lead.createdAt)})</span>
                  </span>
                </DetailField>
                <DetailField label="Last updated">
                  <span className="whitespace-nowrap">
                    {formatDateTime(lead.updatedAt)}{" "}
                    <span className="text-neutral-400">({timeAgo(lead.updatedAt)})</span>
                  </span>
                </DetailField>
              </dl>

              {lead.message ? (
                <div className="mt-6">
                  <p className="text-xs font-medium tracking-wide text-neutral-500 uppercase">Message</p>
                  <blockquote className="mt-2 rounded-r-md border-l-2 border-neutral-300 bg-neutral-50 py-3 pr-4 pl-4 text-sm leading-relaxed whitespace-pre-wrap text-neutral-700">
                    {lead.message}
                  </blockquote>
                </div>
              ) : null}
            </CardContent>
          </Card>

          {/* Pipeline */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Pipeline status</CardTitle>
              <CardDescription>Click a stage to move this lead. Changes are recorded as system notes.</CardDescription>
            </CardHeader>
            <CardContent>
              <div
                role="group"
                aria-label="Pipeline status"
                className="grid grid-cols-2 gap-1 rounded-lg bg-neutral-100 p-1 sm:grid-cols-3"
              >
                {LEAD_STATUSES.map((status) => {
                  const active = lead.status === status;
                  return (
                    <button
                      key={status}
                      type="button"
                      onClick={() => void changeStatus(status)}
                      aria-pressed={active}
                      disabled={statusSaving}
                      className={cn(
                        "rounded-md px-3 py-2.5 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400 disabled:cursor-wait",
                        active
                          ? "bg-white text-neutral-900 shadow-sm"
                          : "text-neutral-500 hover:bg-white/60 hover:text-neutral-900"
                      )}
                    >
                      {statusSaving && active ? (
                        <Loader2 className="mr-1 inline size-3 animate-spin" aria-hidden />
                      ) : active ? (
                        <span className="mr-1.5 inline size-1.5 rounded-full bg-[#FF3B30]" aria-hidden />
                      ) : null}
                      {STATUS_META[status].label}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Ownership + follow-up */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Ownership &amp; follow-up</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="lead-owner">Owner</Label>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Input
                    id="lead-owner"
                    list="admin-owner-options"
                    value={ownerInput}
                    onChange={(e) => setOwnerInput(e.target.value)}
                    placeholder="Owner name"
                    className="flex-1"
                    aria-describedby="lead-owner-hint"
                  />
                  <datalist id="admin-owner-options">
                    {owners.map((o) => (
                      <option key={o} value={o} />
                    ))}
                  </datalist>
                  <Button
                    variant="outline"
                    onClick={() => void assignOwner(ownerInput.trim() || null)}
                    disabled={ownerSaving}
                  >
                    {ownerSaving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <UserRound className="size-4" aria-hidden />}
                    Assign
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => void assignOwner(user?.name ?? null)}
                    disabled={ownerSaving || !user}
                  >
                    Assign to me
                  </Button>
                </div>
                <p id="lead-owner-hint" className="text-xs text-neutral-400">
                  Existing owners are suggested while typing.
                </p>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="lead-followup-trigger">Follow-up date</Label>
                <div className="flex flex-wrap items-center gap-2">
                  <Popover open={followUpOpen} onOpenChange={setFollowUpOpen}>
                    <PopoverTrigger asChild>
                      <Button id="lead-followup-trigger" variant="outline" className="justify-start font-normal">
                        <CalendarIcon className="size-4 text-neutral-400" aria-hidden />
                        {followUpDate ? format(followUpDate, "MMM d, yyyy") : "Set follow-up date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={followUpDate}
                        onSelect={(date) => void saveFollowUp(date)}
                        disabled={followUpSaving}
                      />
                      <div className="flex justify-between border-t border-neutral-100 p-3">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => void saveFollowUp(undefined)}
                          disabled={followUpSaving || !followUpDate}
                        >
                          Clear
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => setFollowUpOpen(false)}>
                          Done
                        </Button>
                      </div>
                    </PopoverContent>
                  </Popover>
                  {followUpSaving ? <Loader2 className="size-4 animate-spin text-neutral-400" aria-hidden /> : null}
                </div>
                <p className="text-xs text-neutral-400">Used by the follow-ups-due counter on the overview.</p>
              </div>
            </CardContent>
          </Card>

          {/* Booking + notification */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Booking</CardTitle>
            </CardHeader>
            <CardContent>
              {lead.bookingRef || lead.bookingDetails ? (
                <div className="space-y-2">
                  {lead.bookingRef ? <p className="font-mono text-sm text-neutral-900">{lead.bookingRef}</p> : null}
                  {lead.bookingDetails ? (
                    <p className="text-sm whitespace-pre-wrap text-neutral-600">{lead.bookingDetails}</p>
                  ) : null}
                </div>
              ) : (
                <p className="text-sm text-neutral-400">
                  No booking reference yet — bookings appear here once Cal.com is connected.
                </p>
              )}

              <Separator className="my-5" />

              <div className="flex flex-wrap items-center gap-3">
                <EmailStatusBadge status={lead.emailStatus} />
                <p className="text-sm text-neutral-600">
                  {lead.emailStatus === "SENT"
                    ? "Business notification delivered."
                    : lead.emailStatus === "FAILED"
                      ? "The notification could not be delivered."
                      : lead.emailStatus === "SKIPPED_NO_PROVIDER"
                        ? "Notification skipped — no email provider configured."
                        : "No notification record for this lead."}
                </p>
                {user?.role === "ADMIN" && lead.emailStatus === "FAILED" ? (
                  <Button variant="outline" size="sm" onClick={() => void retryEmail()} disabled={retrying}>
                    {retrying ? (
                      <Loader2 className="size-4 animate-spin" aria-hidden />
                    ) : (
                      <Send className="size-4" aria-hidden />
                    )}
                    Retry notification
                  </Button>
                ) : null}
              </div>
              {lead.emailStatus === "FAILED" && lead.emailError ? (
                <p className="mt-2 text-xs text-[#D93025]">{lead.emailError}</p>
              ) : null}
              {lead.emailStatus === "SKIPPED_NO_PROVIDER" ? (
                <p className="mt-2 text-xs text-amber-700">Configure RESEND_API_KEY to enable notifications.</p>
              ) : null}
            </CardContent>
          </Card>
        </div>

        {/* ------------------------------ Right column ------------------------------ */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Notes</CardTitle>
            <CardDescription>
              {notes.length} note{notes.length === 1 ? "" : "s"} · internal only, never shown to the lead.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {lead.source === "consultation" ? (
              <div className="flex gap-2.5 rounded-md border border-neutral-200 bg-neutral-50 p-3">
                <CalendarClock className="mt-0.5 size-4 shrink-0 text-neutral-500" aria-hidden />
                <div>
                  <p className="text-xs font-medium text-neutral-700">Consultation info</p>
                  <p className="mt-0.5 text-xs text-neutral-500">
                    This lead booked a free consultation slot. Review booking details above before reaching out.
                  </p>
                </div>
              </div>
            ) : null}

            <div className="space-y-2">
              <Label htmlFor="lead-note-input" className="sr-only">
                New note
              </Label>
              <Textarea
                id="lead-note-input"
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
                placeholder="Add an internal note…"
                rows={3}
                maxLength={4000}
              />
              <div className="flex justify-end">
                <Button size="sm" onClick={() => void addNote()} disabled={noteSaving || !noteInput.trim()}>
                  {noteSaving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
                  Add note
                </Button>
              </div>
            </div>

            <Separator />

            {notes.length === 0 ? (
              <p className="py-4 text-center text-sm text-neutral-400">No notes yet.</p>
            ) : (
              <ul className="scrollbar-slim max-h-[420px] space-y-4 overflow-y-auto pr-1">
                {notes.map((note) => (
                  <li key={note.id} className="space-y-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className="text-sm font-medium text-neutral-900">{note.author}</p>
                      <p className="shrink-0 text-xs text-neutral-400">{timeAgo(note.createdAt)}</p>
                    </div>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap text-neutral-600">{note.body}</p>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------------
 * Small presentational helper
 * ------------------------------------------------------------------------- */

function DetailField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs font-medium tracking-wide text-neutral-500 uppercase">{label}</dt>
      <dd className="mt-1 text-sm text-neutral-800">{children}</dd>
    </div>
  );
}
