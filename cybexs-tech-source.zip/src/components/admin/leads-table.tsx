"use client";

import * as React from "react";
import Link from "next/link";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight, Download, Search } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import {
  ApiError,
  CopyButton,
  STATUS_META,
  StatusBadge,
  SourceBadge,
  TableSkeletonRows,
  apiFetch,
  formatDate,
  timeAgo,
  useAdminUser,
} from "./shared";
import { LEAD_STATUSES, type LeadRecord, type LeadStatus, type LeadsResponse } from "./types";

const PAGE_SIZE = 25;

/* ---------------------------------------------------------------------------
 * Leads management table
 * ------------------------------------------------------------------------- */

export function LeadsTable() {
  const { toast } = useToast();
  const user = useAdminUser();

  const [queryInput, setQueryInput] = React.useState("");
  const [query, setQuery] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [source, setSource] = React.useState("all");
  const [owner, setOwner] = React.useState("all");
  const [page, setPage] = React.useState(1);

  const [data, setData] = React.useState<LeadsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [updatingId, setUpdatingId] = React.useState<string | null>(null);
  const [knownOwners, setKnownOwners] = React.useState<string[]>([]);
  const [reloadKey, setReloadKey] = React.useState(0);

  // Debounced search (300ms).
  React.useEffect(() => {
    const timer = window.setTimeout(() => {
      setQuery(queryInput.trim());
      setPage(1);
    }, 300);
    return () => window.clearTimeout(timer);
  }, [queryInput]);

  React.useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
    if (query) params.set("query", query);
    if (status !== "all") params.set("status", status);
    if (source !== "all") params.set("source", source);
    if (owner !== "all") params.set("owner", owner);

    setLoading(true);
    setError(null);

    apiFetch<LeadsResponse>(`/api/admin/leads?${params.toString()}`, { signal: controller.signal })
      .then((json) => {
        setData(json);
        if (json.owners.length > 0) {
          setKnownOwners((prev) => Array.from(new Set([...prev, ...json.owners])).sort());
        }
      })
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
        setError(err instanceof Error ? err.message : "Failed to load leads.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [query, status, source, owner, page, reloadKey]);

  function changeFilter(setter: (value: string) => void) {
    return (value: string) => {
      setter(value);
      setPage(1);
    };
  }

  async function quickStatus(id: string, next: LeadStatus) {
    if (updatingId) return;
    const snapshot = data;
    setUpdatingId(id);
    setData((prev) =>
      prev ? { ...prev, leads: prev.leads.map((l) => (l.id === id ? { ...l, status: next } : l)) } : prev
    );
    try {
      await apiFetch(`/api/admin/leads/${id}`, { method: "PATCH", body: JSON.stringify({ status: next }) });
      toast({ title: "Status updated", description: STATUS_META[next].label });
    } catch (err) {
      setData(snapshot);
      if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
      toast({
        title: "Could not update status",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setUpdatingId(null);
    }
  }

  const total = data?.total ?? 0;
  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;
  const rows = data?.leads ?? [];
  const showSkeleton = loading && !data;
  const hasActiveFilters = Boolean(query) || status !== "all" || source !== "all" || owner !== "all";

  return (
    <div className="space-y-4">
      {/* Header row: count + CSV export */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral-500" aria-live="polite">
          {data ? `${total} lead${total === 1 ? "" : "s"} total` : "Loading leads…"}
        </p>
        {user?.role === "ADMIN" ? (
          <Button variant="outline" size="sm" asChild className="self-start sm:self-auto">
            <a href="/api/admin/leads/export" title="Download all leads as CSV">
              <Download className="size-4" aria-hidden />
              Export CSV
            </a>
          </Button>
        ) : (
          <Tooltip>
            <TooltipTrigger asChild>
              <span
                tabIndex={0}
                role="button"
                aria-disabled="true"
                aria-label="Export CSV — administrator role required"
                className="inline-flex cursor-not-allowed self-start rounded-md sm:self-auto"
              >
                <Button variant="outline" size="sm" disabled>
                  <Download className="size-4" aria-hidden />
                  Export CSV
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent>Administrator role required</TooltipContent>
          </Tooltip>
        )}
      </div>

      {/* Controls row */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:flex-wrap">
        <div className="relative w-full lg:max-w-xs">
          <Search
            className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-neutral-400"
            aria-hidden
          />
          <Input
            value={queryInput}
            onChange={(e) => setQueryInput(e.target.value)}
            placeholder="Search name, email, company, service"
            aria-label="Search leads"
            className="pl-9"
          />
        </div>

        <Select value={status} onValueChange={changeFilter(setStatus)}>
          <SelectTrigger aria-label="Filter by status" className="w-full lg:w-[150px]">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {LEAD_STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {STATUS_META[s].label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={source} onValueChange={changeFilter(setSource)}>
          <SelectTrigger aria-label="Filter by source" className="w-full lg:w-[150px]">
            <SelectValue placeholder="All sources" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All sources</SelectItem>
            <SelectItem value="consultation">Consultation</SelectItem>
            <SelectItem value="contact">Contact</SelectItem>
          </SelectContent>
        </Select>

        <Select value={owner} onValueChange={changeFilter(setOwner)}>
          <SelectTrigger aria-label="Filter by owner" className="w-full lg:w-[160px]">
            <SelectValue placeholder="All owners" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All owners</SelectItem>
            {knownOwners.map((o) => (
              <SelectItem key={o} value={o}>
                {o}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card className={cn("overflow-hidden p-0", loading && data ? "opacity-60" : undefined)}>
        <Table>
          <TableHeader>
            <TableRow className="bg-neutral-50/80 hover:bg-transparent">
              <TableHead className="pl-4">Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Follow-up</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Quick status</TableHead>
              <TableHead className="pr-4 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {showSkeleton ? (
              <TableSkeletonRows rows={6} cols={9} />
            ) : error && rows.length === 0 ? (
              <TableRow className="hover:bg-transparent">
                <TableCell colSpan={9} className="py-12 text-center text-sm text-neutral-500">
                  {error}
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3 block mx-auto"
                    onClick={() => setReloadKey((k) => k + 1)}
                  >
                    Retry
                  </Button>
                </TableCell>
              </TableRow>
            ) : rows.length === 0 ? (
              <TableRow className="hover:bg-transparent">
                <TableCell colSpan={9} className="py-12 text-center">
                  <p className="text-sm text-neutral-500">No leads match your filters.</p>
                  {hasActiveFilters ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => {
                        setQueryInput("");
                        setQuery("");
                        setStatus("all");
                        setSource("all");
                        setOwner("all");
                        setPage(1);
                      }}
                    >
                      Clear filters
                    </Button>
                  ) : null}
                </TableCell>
              </TableRow>
            ) : (
              rows.map((lead: LeadRecord) => (
                <TableRow key={lead.id} aria-busy={updatingId === lead.id}>
                  <TableCell className="pl-4">
                    <Link
                      href={`/admin/leads/${lead.id}`}
                      className="group block max-w-[200px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-300"
                    >
                      <span className="block truncate text-sm font-medium text-neutral-900 group-hover:underline">
                        {lead.fullName}
                      </span>
                      <span className="block truncate text-xs text-neutral-500">{lead.companyName}</span>
                    </Link>
                  </TableCell>
                  <TableCell>
                    <span className="flex max-w-[210px] items-center gap-1">
                      <span className="truncate text-sm text-neutral-700" title={lead.email}>
                        {lead.email}
                      </span>
                      <CopyButton value={lead.email} label="email address" />
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="block max-w-[170px] truncate text-sm text-neutral-700" title={lead.serviceInterest}>
                      {lead.serviceInterest}
                    </span>
                  </TableCell>
                  <TableCell>
                    <SourceBadge source={lead.source} />
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={lead.status} />
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-neutral-600">
                      {lead.followUpDate ? formatDate(lead.followUpDate) : "—"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm whitespace-nowrap text-neutral-600">{timeAgo(lead.createdAt)}</span>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={lead.status}
                      onValueChange={(next) => {
                        if (next === lead.status) return;
                        void quickStatus(lead.id, next as LeadStatus);
                      }}
                      disabled={updatingId === lead.id}
                    >
                      <SelectTrigger
                        size="sm"
                        aria-label={`Change status for ${lead.fullName}`}
                        className="w-[132px] text-xs"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LEAD_STATUSES.map((s) => (
                          <SelectItem key={s} value={s} className="text-xs">
                            {STATUS_META[s].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="pr-4 text-right">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/admin/leads/${lead.id}`}>Open</Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Pagination */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral-500" aria-live="polite">
          {total > 0
            ? `Showing ${(page - 1) * PAGE_SIZE + 1}–${Math.min(page * PAGE_SIZE, total)} of ${total}`
            : "Showing 0 of 0"}
        </p>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={page <= 1 || loading}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            <ChevronLeft className="size-4" aria-hidden />
            Prev
          </Button>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= totalPages || loading}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
            <ChevronRight className="size-4" aria-hidden />
          </Button>
        </div>
      </div>
    </div>
  );
}


