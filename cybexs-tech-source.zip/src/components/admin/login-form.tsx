"use client";

import * as React from "react";
import { Loader2, ShieldCheck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

/**
 * Full-screen administrator sign-in. Rendered by the /admin layout instead of
 * children whenever there is no valid session. On success we do a full page
 * reload so the server layout picks up the new session cookie.
 */
export function AdminLogin() {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), password }),
      });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;

      if (res.ok && json?.ok) {
        window.location.assign("/admin");
        return;
      }

      if (res.status === 401) {
        setError("Invalid email or password.");
      } else if (res.status === 429) {
        setError(json?.error ?? "Too many attempts. Please wait a few minutes and try again.");
      } else {
        setError(json?.error ?? "Sign-in failed. Please try again.");
      }
      setPassword("");
    } catch {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen place-items-center bg-[#0A0A0A] px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="rounded-lg border border-neutral-200 bg-white p-8 shadow-2xl shadow-black/40">
          <p className="font-display text-xl font-semibold tracking-tight text-neutral-900">
            Cybexs Tech<span className="text-[#FF3B30]">.</span>
          </p>
          <h1 className="mt-6 font-display text-lg font-semibold tracking-tight text-neutral-900">
            Administrator sign in
          </h1>
          <p className="mt-1 text-sm text-neutral-500">Enter your credentials to access the dashboard.</p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="admin-email">Email</Label>
              <Input
                id="admin-email"
                type="email"
                autoComplete="email"
                autoFocus
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@cybexs.tech"
                disabled={loading}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-password">Password</Label>
              <Input
                id="admin-password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                disabled={loading}
              />
            </div>

            {error ? (
              <p role="alert" className="text-sm font-medium text-[#D93025]">
                {error}
              </p>
            ) : null}

            <Button
              type="submit"
              disabled={loading || !email.trim() || !password}
              className="w-full bg-neutral-900 text-white hover:bg-neutral-800"
            >
              {loading ? (
                <>
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                  Signing in…
                </>
              ) : (
                "Sign in"
              )}
            </Button>
          </form>
        </div>

        <p className="mt-6 flex items-center justify-center gap-1.5 text-center text-xs text-neutral-500">
          <ShieldCheck className="size-3.5 shrink-0" aria-hidden />
          Access is restricted to authorized Cybexs Tech team members.
        </p>
      </div>
    </div>
  );
}
