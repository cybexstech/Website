"use client";

import * as React from "react";
import Link from "next/link";
import { format } from "date-fns";
import {
  CalendarClock,
  ChevronRight,
  RefreshCcw,
  TrendingUp,
  Users,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { StatCard, StatCardSkeleton } from "./stat-cards";
import { ApiError, STATUS_META, StatusBadge, apiFetch, timeAgo } from "./shared";
import { LEAD_STATUSES, type StatsResponse } from "./types";

/* ---------------------------------------------------------------------------
 * 14-day trend bar chart — plain divs, no chart library.
 * ------------------------------------------------------------------------- */

function TrendChart({ trend }: { trend: { date: string; count: number }[] }) {
  const max = Math.max(1, ...trend.map((t) => t.count));
  const total = trend.reduce((acc, t) => acc + t.count, 0);

  return (
    <div>
      <div
        className="flex h-44 items-end gap-1 sm:gap-1.5"
        role="img"
        aria-label={`Leads per day over the last 14 days, ${total} total`}
      >
        {trend.map((t) => {
          const pct = Math.round((t.count / max) * 100);
          const day = new Date(`${t.date}T00:00:00`);
          return (
            <div
              key={t.date}
              title={`${format(day, "EEE, MMM d")} — ${t.count} lead${t.count === 1 ? "" : "s"}`}
              className="group flex h-full min-w-0 flex-1 items-end"
            >
              <div
                className={cn(
                  "w-full rounded-t-sm transition-colors",
                  t.count > 0 ? "bg-neutral-900 group-hover:bg-[#FF3B30]" : "bg-neutral-200"
                )}
                style={{ height: `${t.count > 0 ? Math.max(5, pct) : 3}%` }}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex gap-1 sm:gap-1.5" aria-hidden>
        {trend.map((t, i) => (
          <span key={t.date} className="min-w-0 flex-1 text-center text-[10px] text-neutral-400">
            {i % 2 === 0 ? format(new Date(`${t.date}T00:00:00`), "d") : ""}
          </span>
        ))}
      </div>
      <p className="mt-3 text-xs text-neutral-400">
        Last 14 days · {total} new lead{total === 1 ? "" : "s"}
      </p>
    </div>
  );
}

/* ---------------------------------------------------------------------------
 * Overview
 * ------------------------------------------------------------------------- */

export function OverviewClient() {
  const [stats, setStats] = React.useState<StatsResponse["stats"] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [reloadKey, setReloadKey] = React.useState(0);

  React.useEffect(() => {
    let cancelled = false;
    setError(null);
    apiFetch<StatsResponse>("/api/admin/stats")
      .then((json) => {
        if (!cancelled) setStats(json.stats);
      })
      .catch((err: unknown) => {
        if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load stats.");
      });
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  if (error) {
    return (
      <Card className="p-6">
        <p className="text-sm font-medium text-neutral-900">Could not load the dashboard.</p>
        <p className="mt-1 text-sm text-neutral-500">{error}</p>
        <Button
          variant="outline"
          size="sm"
          className="mt-4"
          onClick={() => setReloadKey((k) => k + 1)}
        >
          <RefreshCcw className="size-4" aria-hidden />
          Retry
        </Button>
      </Card>
    );
  }

  if (!stats) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <StatCardSkeleton key={i} />
          ))}
        </div>
        <div className="grid gap-6 lg:grid-cols-5">
          <Card className="p-6 lg:col-span-3">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="mt-6 h-44 w-full" />
          </Card>
          <Card className="p-6 lg:col-span-2">
            <Skeleton className="h-4 w-28" />
            <div className="mt-4 space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3">
                  <Skeleton className="h-9 w-9 rounded-full" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-3.5 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    );
  }

  const statusCount = (status: string): number => stats.byStatus[status] ?? 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Total leads" value={stats.total} hint="All sources, all time" icon={Users} />
        {LEAD_STATUSES.map((status) => (
          <StatCard
            key={status}
            label={STATUS_META[status].label}
            value={statusCount(status)}
            dotClassName={STATUS_META[status].dot}
          />
        ))}
        <StatCard
          label="Follow-ups due"
          value={stats.followUpsDue}
          hint="Due within 3 days, open pipeline"
          icon={CalendarClock}
          iconClassName={stats.followUpsDue > 0 ? "text-amber-500" : undefined}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="size-4 text-neutral-400" aria-hidden />
              Lead trend
            </CardTitle>
            <CardDescription>New inquiries per day, last 14 days.</CardDescription>
          </CardHeader>
          <CardContent>
            <TrendChart trend={stats.trend} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Recent leads</CardTitle>
            <CardDescription>Latest 8 inquiries across all sources.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <ul>
              {stats.recent.map((lead) => (
                <li key={lead.id} className="border-t border-neutral-100 first:border-t-0">
                  <Link
                    href={`/admin/leads/${lead.id}`}
                    className="flex items-center gap-3 px-6 py-3 transition-colors hover:bg-neutral-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-300"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-neutral-900">{lead.fullName}</p>
                      <p className="truncate text-xs text-neutral-500">
                        {lead.companyName} · {lead.serviceInterest}
                      </p>
                    </div>
                    <StatusBadge status={lead.status} className="hidden sm:inline-flex" />
                    <span className="shrink-0 text-xs text-neutral-400">{timeAgo(lead.createdAt)}</span>
                    <ChevronRight className="size-4 shrink-0 text-neutral-300" aria-hidden />
                  </Link>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
