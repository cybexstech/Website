"use client";

import * as React from "react";
import { format, formatDistanceToNow } from "date-fns";
import { Check, Copy } from "lucide-react";

import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  LEAD_STATUSES,
  type AdminUser,
  type LeadStatus,
  type MeResponse,
} from "./types";

/* ---------------------------------------------------------------------------
 * API client — same-origin fetch with unified 401 session-expiry handling.
 * ------------------------------------------------------------------------- */

export class ApiError extends Error {
  status: number;
  fieldErrors?: Record<string, string>;

  constructor(status: number, message: string, fieldErrors?: Record<string, string>) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

function isAbortError(err: unknown): boolean {
  return err instanceof DOMException && err.name === "AbortError";
}

/**
 * Fetch an /api/admin/* endpoint. Same-origin cookies are sent by default.
 * Throws ApiError on failure; a 401 triggers the session-expiry flow
 * ("Session expired — reloading…" toast + redirect to /admin).
 */
export async function apiFetch<T>(url: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: init?.body ? { "Content-Type": "application/json", ...(init?.headers ?? {}) } : init?.headers,
    });
  } catch (err) {
    if (isAbortError(err)) throw err;
    throw new ApiError(0, "Network error. Check your connection and try again.");
  }

  if (res.status === 401) {
    toast({ title: "Session expired — reloading…" });
    window.location.assign("/admin");
    throw new ApiError(401, "Session expired.");
  }

  const json = (await res.json().catch(() => null)) as
    | (T & { ok?: boolean; error?: string; fieldErrors?: Record<string, string> })
    | null;

  if (!res.ok || !json || json.ok === false) {
    throw new ApiError(res.status, json?.error ?? "Request failed. Please try again.", json?.fieldErrors);
  }

  return json;
}

/** Current admin user from GET /api/admin/me (null while loading or on failure). */
export function useAdminUser(): AdminUser | null {
  const [user, setUser] = React.useState<AdminUser | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    apiFetch<MeResponse>("/api/admin/me")
      .then((json) => {
        if (!cancelled) setUser(json.user);
      })
      .catch(() => {
        /* 401 handled globally; other failures leave user null */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return user;
}

/* ---------------------------------------------------------------------------
 * Formatting helpers
 * ------------------------------------------------------------------------- */

export function timeAgo(iso: string): string {
  try {
    return formatDistanceToNow(new Date(iso), { addSuffix: true });
  } catch {
    return "—";
  }
}

export function formatDate(iso: string): string {
  try {
    return format(new Date(iso), "MMM d, yyyy");
  } catch {
    return "—";
  }
}

export function formatDateTime(iso: string): string {
  try {
    return format(new Date(iso), "MMM d, yyyy · HH:mm");
  } catch {
    return "—";
  }
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export function websiteHref(website: string): string {
  return /^https?:\/\//i.test(website) ? website : `https://${website}`;
}

/* ---------------------------------------------------------------------------
 * Badges
 * ------------------------------------------------------------------------- */

export interface StatusMeta {
  label: string;
  badge: string;
  dot: string;
}

export const STATUS_META: Record<LeadStatus, StatusMeta> = {
  NEW: {
    label: "New",
    badge: "border-neutral-200 bg-neutral-100 text-neutral-700",
    dot: "bg-neutral-400",
  },
  CONTACTED: {
    label: "Contacted",
    badge: "border-amber-200 bg-amber-100 text-amber-800",
    dot: "bg-amber-500",
  },
  QUALIFIED: {
    label: "Qualified",
    badge: "border-violet-200 bg-violet-100 text-violet-800",
    dot: "bg-violet-500",
  },
  MEETING_BOOKED: {
    label: "Meeting Booked",
    badge: "border-[#FF3B30]/25 bg-[#FF3B30]/10 text-[#C62A21]",
    dot: "bg-[#FF3B30]",
  },
  WON: {
    label: "Won",
    badge: "border-emerald-200 bg-emerald-100 text-emerald-800",
    dot: "bg-emerald-500",
  },
  LOST: {
    label: "Lost",
    badge: "border-neutral-700 bg-neutral-800 text-neutral-100",
    dot: "bg-neutral-800",
  },
};

export function isLeadStatus(value: string): value is LeadStatus {
  return (LEAD_STATUSES as readonly string[]).includes(value);
}

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const meta = isLeadStatus(status) ? STATUS_META[status] : null;
  return (
    <Badge variant="outline" className={cn(meta?.badge ?? "border-neutral-200 bg-neutral-100 text-neutral-600", className)}>
      {meta?.label ?? status}
    </Badge>
  );
}

export function SourceBadge({ source, className }: { source: string; className?: string }) {
  const label = source === "consultation" ? "Consultation" : "Contact";
  return (
    <Badge
      variant="outline"
      className={cn(
        source === "consultation"
          ? "border-neutral-900 bg-neutral-900 text-white"
          : "border-neutral-200 bg-white text-neutral-600",
        className
      )}
    >
      {label}
    </Badge>
  );
}

export function EmailStatusBadge({ status, className }: { status: string | null; className?: string }) {
  if (status === "SENT") {
    return <Badge className={cn("border-transparent bg-emerald-600 text-white", className)}>Sent</Badge>;
  }
  if (status === "FAILED") {
    return <Badge className={cn("border-transparent bg-[#FF3B30] text-white", className)}>Failed</Badge>;
  }
  if (status === "SKIPPED_NO_PROVIDER") {
    return <Badge className={cn("border-amber-200 bg-amber-100 text-amber-800", className)}>Skipped</Badge>;
  }
  return <Badge variant="outline" className={cn("border-neutral-200 bg-neutral-100 text-neutral-500", className)}>No record</Badge>;
}

/* ---------------------------------------------------------------------------
 * Copy-to-clipboard button
 * ------------------------------------------------------------------------- */

export function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = React.useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      toast({ title: "Could not copy to clipboard", variant: "destructive" });
    }
  }

  return (
    <button
      type="button"
      onClick={copy}
      title={`Copy ${label}`}
      aria-label={`Copy ${label}`}
      className="inline-flex size-6 shrink-0 items-center justify-center rounded text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
    >
      {copied ? <Check className="size-3.5 text-emerald-600" aria-hidden /> : <Copy className="size-3.5" aria-hidden />}
    </button>
  );
}

/* ---------------------------------------------------------------------------
 * Loading / error states
 * ------------------------------------------------------------------------- */

export function TableSkeletonRows({ rows, cols }: { rows: number; cols: number }) {
  return (
    <>
      {Array.from({ length: rows }).map((_, r) => (
        <tr key={r} className="border-b transition-colors hover:bg-transparent">
          {Array.from({ length: cols }).map((__, c) => (
            <td key={c} className="p-2 align-middle whitespace-nowrap">
              <Skeleton className="h-4 w-full max-w-[130px]" />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}
