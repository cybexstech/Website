"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  FileText,
  LayoutDashboard,
  Loader2,
  LogOut,
  Menu,
  Shield,
  Users,
  type LucideIcon,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetDescription, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { initials } from "./shared";
import type { AdminUser } from "./types";

/* ---------------------------------------------------------------------------
 * Nav definition
 * ------------------------------------------------------------------------- */

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/admin", label: "Overview", icon: LayoutDashboard },
  { href: "/admin/leads", label: "Leads", icon: Users },
  { href: "/admin/content", label: "Content", icon: FileText },
  { href: "/admin/team", label: "Team", icon: Shield },
];

function pageTitleFor(pathname: string): string {
  if (pathname === "/admin" || pathname === "/admin/") return "Overview";
  if (pathname.startsWith("/admin/leads/")) return "Lead detail";
  if (pathname.startsWith("/admin/leads")) return "Leads";
  if (pathname.startsWith("/admin/content")) return "Content";
  if (pathname.startsWith("/admin/team")) return "Team";
  return "Admin";
}

function isNavActive(pathname: string, href: string): boolean {
  if (href === "/admin") return pathname === "/admin" || pathname === "/admin/";
  return pathname === href || pathname.startsWith(`${href}/`);
}

/* ---------------------------------------------------------------------------
 * Pieces
 * ------------------------------------------------------------------------- */

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("font-display text-lg font-semibold tracking-tight", className)}>
      Cybexs Tech<span className="text-[#FF3B30]">.</span>
    </span>
  );
}

function NavLinks({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <ul className="space-y-1">
      {NAV_ITEMS.map((item) => {
        const active = isNavActive(pathname, item.href);
        const Icon = item.icon;
        return (
          <li key={item.href}>
            <Link
              href={item.href}
              onClick={onNavigate}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/30",
                active ? "bg-white/10 text-white" : "text-neutral-400 hover:bg-white/5 hover:text-white"
              )}
            >
              <Icon className={cn("size-4 shrink-0", active && "text-[#FF3B30]")} aria-hidden />
              {item.label}
              {active ? <span className="ml-auto size-1.5 rounded-full bg-[#FF3B30]" aria-hidden /> : null}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

function UserCard({
  user,
  onSignOut,
  signingOut,
}: {
  user: AdminUser;
  onSignOut: () => void;
  signingOut: boolean;
}) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className="flex size-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-xs font-semibold text-white uppercase"
        >
          {initials(user.name) || "C"}
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-white">{user.name}</p>
          <p className="text-[11px] tracking-wider text-neutral-400 uppercase">{user.role}</p>
        </div>
      </div>
      <Button
        variant="outline"
        size="sm"
        className="w-full justify-start border-white/15 bg-transparent text-neutral-300 hover:bg-white/10 hover:text-white"
        onClick={onSignOut}
        disabled={signingOut}
      >
        {signingOut ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <LogOut className="size-4" aria-hidden />}
        Sign out
      </Button>
    </div>
  );
}

function SidebarBody({
  user,
  pathname,
  onSignOut,
  signingOut,
  onNavigate,
}: {
  user: AdminUser;
  pathname: string;
  onSignOut: () => void;
  signingOut: boolean;
  onNavigate?: () => void;
}) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-16 shrink-0 items-center border-b border-white/10 px-6">
        <Wordmark className="text-white" />
      </div>
      <nav aria-label="Admin sections" className="flex-1 overflow-y-auto px-3 py-6">
        <NavLinks pathname={pathname} onNavigate={onNavigate} />
      </nav>
      <div className="shrink-0 border-t border-white/10 p-4">
        <UserCard user={user} onSignOut={onSignOut} signingOut={signingOut} />
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------------
 * Shell — dark fixed sidebar (desktop), top bar + Sheet (mobile)
 * ------------------------------------------------------------------------- */

export function AdminShell({ user, children }: { user: AdminUser; children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [signingOut, setSigningOut] = React.useState(false);
  const title = pageTitleFor(pathname);

  async function signOut() {
    if (signingOut) return;
    setSigningOut(true);
    try {
      await fetch("/api/admin/logout", { method: "POST" });
    } catch {
      /* ignore network errors — navigating to /admin will show the login screen anyway */
    }
    window.location.assign("/admin");
  }

  return (
    <div className="min-h-screen bg-[#FAFAF9]">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 bg-[#0A0A0A] text-white lg:block">
        <SidebarBody user={user} pathname={pathname} onSignOut={signOut} signingOut={signingOut} />
      </aside>

      <div className="flex min-h-screen flex-col lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center gap-3 border-b border-neutral-200 bg-white/90 px-4 backdrop-blur sm:px-6 lg:px-8">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="lg:hidden"
                aria-label="Open navigation menu"
                aria-expanded={mobileOpen}
              >
                <Menu className="size-5" aria-hidden />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="left"
              className="w-72 border-white/10 bg-[#0A0A0A] p-0 text-white [&>button]:text-white"
            >
              <SheetTitle className="sr-only">Admin navigation</SheetTitle>
              <SheetDescription className="sr-only">Navigate between admin dashboard sections.</SheetDescription>
              <SidebarBody
                user={user}
                pathname={pathname}
                onSignOut={signOut}
                signingOut={signingOut}
                onNavigate={() => setMobileOpen(false)}
              />
            </SheetContent>
          </Sheet>

          <h1 className="font-display text-lg font-semibold tracking-tight text-neutral-900">{title}</h1>

          <div className="ml-auto hidden items-center gap-2 text-sm text-neutral-500 sm:flex">
            <span className="size-2 rounded-full bg-emerald-500" aria-hidden />
            <span>
              Signed in as <span className="font-medium text-neutral-700">{user.email}</span>
            </span>
          </div>
        </header>

        <main className="flex-1">
          <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 sm:py-8 lg:px-8">{children}</div>
        </main>
      </div>
    </div>
  );
}
