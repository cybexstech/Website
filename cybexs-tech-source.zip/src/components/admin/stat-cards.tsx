"use client";

import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface StatCardProps {
  label: string;
  value: number;
  hint?: string;
  icon?: LucideIcon;
  /** Small colored dot in front of the label (status colors). */
  dotClassName?: string;
  iconClassName?: string;
}

export function StatCard({ label, value, hint, icon: Icon, dotClassName, iconClassName }: StatCardProps) {
  return (
    <Card className="p-4 sm:p-5">
      <div className="flex items-center gap-2">
        {dotClassName ? (
          <span className={cn("size-2 shrink-0 rounded-full", dotClassName)} aria-hidden />
        ) : Icon ? (
          <Icon className={cn("size-4 shrink-0 text-neutral-400", iconClassName)} aria-hidden />
        ) : null}
        <p className="truncate text-xs font-medium tracking-wide text-neutral-500 uppercase">{label}</p>
      </div>
      <p className="mt-3 font-display text-3xl font-semibold tracking-tight text-neutral-900 tabular-nums">{value}</p>
      {hint ? <p className="mt-1 text-xs text-neutral-400">{hint}</p> : null}
    </Card>
  );
}

export function StatCardSkeleton() {
  return (
    <Card className="p-4 sm:p-5">
      <Skeleton className="h-3 w-20" />
      <Skeleton className="mt-4 h-8 w-16" />
      <Skeleton className="mt-2 h-3 w-24" />
    </Card>
  );
}
