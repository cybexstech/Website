"use client";

import * as React from "react";
import { Check, Clock, Send, X } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { ApiError, apiFetch, initials } from "./shared";
import type { AdminRole, MeResponse } from "./types";

/* ---------------------------------------------------------------------------
 * Team foundation page — honest capability model, no mocked functionality.
 * ------------------------------------------------------------------------- */

type CapabilityState = "yes" | "no" | "planned";

interface Capability {
  label: string;
  admin: CapabilityState;
  team: CapabilityState;
}

const CAPABILITIES: Capability[] = [
  { label: "View leads and pipeline", admin: "yes", team: "yes" },
  { label: "Update lead status", admin: "yes", team: "yes" },
  { label: "Add internal notes", admin: "yes", team: "yes" },
  { label: "Assign lead owners", admin: "yes", team: "yes" },
  { label: "Export leads as CSV", admin: "yes", team: "no" },
  { label: "Retry email notifications", admin: "yes", team: "no" },
  { label: "Create and edit content", admin: "yes", team: "no" },
  { label: "Invite team members", admin: "planned", team: "planned" },
];

function CapabilityCell({ state }: { state: CapabilityState }) {
  if (state === "yes") {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm text-neutral-700">
        <Check className="size-4 text-emerald-600" aria-hidden />
        <span className="sr-only">Included</span>
      </span>
    );
  }
  if (state === "planned") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-neutral-400 italic">
        <Clock className="size-3.5" aria-hidden />
        Planned
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-sm text-neutral-300">
      <X className="size-4" aria-hidden />
      <span className="sr-only">Not included</span>
    </span>
  );
}

export function TeamPanel() {
  const [user, setUser] = React.useState<MeResponse["user"] | null>(null);
  const [loadFailed, setLoadFailed] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    apiFetch<MeResponse>("/api/admin/me")
      .then((json) => {
        if (!cancelled) setUser(json.user);
      })
      .catch((err: unknown) => {
        if (err instanceof ApiError && (err.status === 401 || err.status === 0)) return;
        if (!cancelled) setLoadFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Current user */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Signed-in member</CardTitle>
          <CardDescription>Your account details for this dashboard session.</CardDescription>
        </CardHeader>
        <CardContent>
          {user ? (
            <div className="flex items-center gap-4">
              <span
                aria-hidden
                className="flex size-12 shrink-0 items-center justify-center rounded-full bg-neutral-900 font-display text-sm font-semibold text-white"
              >
                {initials(user.name) || "C"}
              </span>
              <div className="min-w-0">
                <p className="truncate font-display text-lg font-semibold tracking-tight text-neutral-900">{user.name}</p>
                <p className="truncate text-sm text-neutral-500">{user.email}</p>
              </div>
              <span
                className={cn(
                  "ml-auto rounded-md border px-2.5 py-1 text-xs font-medium tracking-wider uppercase",
                  user.role === "ADMIN"
                    ? "border-neutral-900 bg-neutral-900 text-white"
                    : "border-neutral-200 bg-neutral-100 text-neutral-600"
                )}
              >
                {user.role}
              </span>
            </div>
          ) : loadFailed ? (
            <p className="text-sm text-neutral-500">Could not load your account details. Reload the page to retry.</p>
          ) : (
            <div className="flex items-center gap-4">
              <Skeleton className="size-12 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-40" />
                <Skeleton className="h-3 w-56" />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Role model */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Role model</CardTitle>
          <CardDescription>
            What each role can do today. Access is enforced server-side on every API route.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-neutral-50/80 hover:bg-transparent">
                <TableHead className="pl-4">Capability</TableHead>
                <TableHead>Administrator</TableHead>
                <TableHead className="pr-4">Team member</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {CAPABILITIES.map((cap) => (
                <TableRow key={cap.label}>
                  <TableCell className="pl-4 text-sm text-neutral-800">{cap.label}</TableCell>
                  <TableCell>
                    <CapabilityCell state={cap.admin} />
                  </TableCell>
                  <TableCell className="pr-4">
                    <CapabilityCell state={cap.team} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Invitations — honest foundation */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Invite a member</CardTitle>
          <CardDescription>Grow the team once invitations are supported.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <Input
              disabled
              placeholder="teammate@cybexs.tech"
              aria-label="Team member email (disabled)"
              className="flex-1"
            />
            <Button disabled className="sm:w-auto">
              <Send className="size-4" aria-hidden />
              Send invite
            </Button>
          </div>
          <p className="mt-3 text-xs text-neutral-400">
            Team invitations ship with the production deployment — provisioning is done via ADMIN_EMAIL/ADMIN_PASSWORD
            env today (see README).
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
