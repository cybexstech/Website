/**
 * Shared client-side types for the admin dashboard.
 * Shapes mirror the JSON contracts returned by /api/admin/* routes exactly.
 */

export type AdminRole = "ADMIN" | "TEAM";

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: AdminRole;
}

export const LEAD_STATUSES = [
  "NEW",
  "CONTACTED",
  "QUALIFIED",
  "MEETING_BOOKED",
  "WON",
  "LOST",
] as const;

export type LeadStatus = (typeof LEAD_STATUSES)[number];

export interface NoteRecord {
  id: string;
  leadId: string;
  body: string;
  author: string;
  createdAt: string;
}

export interface LeadRecord {
  id: string;
  fullName: string;
  email: string;
  companyName: string;
  companyWebsite: string | null;
  serviceInterest: string;
  source: string;
  inquiryType: string | null;
  message: string | null;
  status: string;
  ownerName: string | null;
  bookingRef: string | null;
  bookingDetails: string | null;
  followUpDate: string | null;
  emailStatus: string | null;
  emailError: string | null;
  createdAt: string;
  updatedAt: string;
  notes?: NoteRecord[];
  lastNote?: string | null;
}

export interface LeadsResponse {
  ok: boolean;
  leads: LeadRecord[];
  total: number;
  page: number;
  pageSize: number;
  owners: string[];
}

export interface LeadResponse {
  ok: boolean;
  lead: LeadRecord;
}

export interface NoteResponse {
  ok: boolean;
  note: NoteRecord;
}

export interface MeResponse {
  ok: boolean;
  user: AdminUser;
}

export interface StatsResponse {
  ok: boolean;
  stats: {
    total: number;
    byStatus: Record<string, number>;
    followUpsDue: number;
    trend: { date: string; count: number }[];
    recent: {
      id: string;
      fullName: string;
      companyName: string;
      serviceInterest: string;
      status: string;
      createdAt: string;
      source: string;
    }[];
  };
}

export interface ArticleListItem {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  tags: string;
  status: string;
  author: string;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
  readMinutes: number;
}

export interface ArticleRecord extends ArticleListItem {
  content: string;
  seoTitle: string | null;
  seoDescription: string | null;
  featuredImage: string | null;
}

export interface ArticlesResponse {
  ok: boolean;
  articles: ArticleListItem[];
}

export interface ArticleResponse {
  ok: boolean;
  article: ArticleRecord;
}

export interface ResendEmailResponse {
  ok: boolean;
  result: { status: string; error?: string | null; messageId?: string | null };
}
