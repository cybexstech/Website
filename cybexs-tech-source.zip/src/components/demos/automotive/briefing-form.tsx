"use client";

import { useState } from "react";
import { Reveal } from "@/components/motion/reveal";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AURION_MODELS } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-aurion-display)]";

const inputClasses =
  "w-full border border-white/15 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-neutral-500 transition-colors focus-visible:border-[#C6FF3E] focus-visible:outline-none";

const labelClasses = "mb-2 block text-[11px] font-semibold uppercase tracking-[0.25em] text-neutral-400";

export function BriefingForm() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="scroll-mt-16 border-t border-white/10">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-start">
          <Reveal>
            <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#C6FF3E]">Contact</p>
            <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold uppercase leading-tight text-white sm:text-5xl")}>
              Request a private briefing.
            </h2>
            <p className="mt-4 max-w-md text-base leading-relaxed text-neutral-400">
              Name, email, model. In the real world this would reach a concierge team; here it reaches nowhere at all —
              which is exactly the point of a demo.
            </p>
          </Reveal>

          <Reveal delay={0.1}>
            <form
              onSubmit={(event) => {
                event.preventDefault();
                setSent(true);
              }}
              className="border border-white/10 bg-white/5 p-6 sm:p-8"
              noValidate={false}
            >
              <div className="space-y-5">
                <div>
                  <label htmlFor="briefing-name" className={labelClasses}>
                    Full name
                  </label>
                  <input
                    id="briefing-name"
                    name="name"
                    type="text"
                    required
                    autoComplete="name"
                    placeholder="Alex Voss"
                    className={inputClasses}
                  />
                </div>
                <div>
                  <label htmlFor="briefing-email" className={labelClasses}>
                    Email
                  </label>
                  <input
                    id="briefing-email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    placeholder="alex@example.com"
                    className={inputClasses}
                  />
                </div>
                <div>
                  <label htmlFor="briefing-model" className={labelClasses}>
                    Model of interest
                  </label>
                  <Select name="model" required defaultValue="gt">
                    <SelectTrigger
                      id="briefing-model"
                      className="w-full border-white/15 bg-white/5 text-white data-[placeholder]:text-neutral-500 focus-visible:border-[#C6FF3E] focus-visible:ring-1 focus-visible:ring-[#C6FF3E]"
                    >
                      <SelectValue placeholder="Select a model" />
                    </SelectTrigger>
                    <SelectContent className="border-white/15 bg-[#121412] text-white">
                      {AURION_MODELS.map((m) => (
                        <SelectItem key={m.id} value={m.id} className="focus:bg-white/10">
                          {m.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <button
                type="submit"
                className="mt-7 w-full bg-[#C6FF3E] py-4 text-xs font-bold uppercase tracking-[0.25em] text-[#0B0D0C] transition-colors hover:bg-[#D8FF6E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C6FF3E]"
              >
                Request briefing (demo)
              </button>

              <p aria-live="polite" className="mt-4 min-h-12 text-sm leading-relaxed text-[#C6FF3E]">
                {sent && "Demo form — no data is sent. Nothing left your browser."}
              </p>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
