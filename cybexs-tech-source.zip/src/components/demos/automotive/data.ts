// ---------------------------------------------------------------------------
// AURION — fictional electric hyper-GT marque (concept demo data)
// ---------------------------------------------------------------------------

export type AurionModel = {
  id: "gt" | "s" | "r";
  name: string;
  tagline: string;
  blurb: string;
  price: string;
  range: number; // km
  power: number; // kW
  sprint: string; // 0–100 km/h
  image: string;
  imageAlt: string;
};

export const AURION_MODELS: AurionModel[] = [
  {
    id: "gt",
    name: "AURION GT",
    tagline: "The flagship grand tourer",
    blurb:
      "A 745 kW dual-motor grand tourer with 920 km of claimed range — built to cross a continent at a whisper, then a scream.",
    price: "€268,000",
    range: 920,
    power: 745,
    sprint: "2.4 s",
    image: "/demo-assets/automotive/hero.jpg",
    imageAlt: "AURION GT concept car in a dark studio",
  },
  {
    id: "s",
    name: "AURION S",
    tagline: "The executive sedan",
    blurb:
      "Rear-biased comfort, 480 kW of silent thrust and the quietest cabin we — fictionally — ever engineered.",
    price: "€148,000",
    range: 640,
    power: 480,
    sprint: "3.1 s",
    image: "/demo-assets/automotive/m1.jpg",
    imageAlt: "AURION S sedan profile at dusk",
  },
  {
    id: "r",
    name: "AURION R",
    tagline: "The track weapon",
    blurb:
      "Fixed wing, carbon buckets, 620 kW delivered without a single pause for breath. Numbers are its entire vocabulary.",
    price: "€212,000",
    range: 705,
    power: 620,
    sprint: "2.7 s",
    image: "/demo-assets/automotive/m2.jpg",
    imageAlt: "Detail of the AURION R rear wing",
  },
];
