"use client";

import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Reveal } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { AURION_MODELS } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-aurion-display)]";

export function Lineup() {
  const [modelId, setModelId] = useState<string>("gt");
  const reduce = useReducedMotion();
  const model = AURION_MODELS.find((m) => m.id === modelId) ?? AURION_MODELS[0];

  return (
    <section id="models" className="scroll-mt-16 border-t border-white/10">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#C6FF3E]">The Line-Up</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold uppercase leading-tight text-white sm:text-5xl")}>
            Three characters. One current.
          </h2>
        </Reveal>

        <Tabs value={modelId} onValueChange={setModelId} className="mt-10">
          <TabsList className="h-auto w-full justify-start gap-1 overflow-x-auto rounded-none border-b border-white/10 bg-transparent p-0">
            {AURION_MODELS.map((m) => (
              <TabsTrigger
                key={m.id}
                value={m.id}
                className="rounded-none border-b-2 border-transparent px-4 py-3 text-[11px] uppercase tracking-[0.2em] text-neutral-400 transition-colors hover:text-white data-[state=active]:border-[#C6FF3E] data-[state=active]:bg-transparent data-[state=active]:text-white sm:px-6 sm:text-xs"
              >
                {m.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {AURION_MODELS.map((m) => (
            <TabsContent key={m.id} value={m.id} className="mt-10 focus-visible:outline-none">
              <motion.div
                initial={reduce ? false : { opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45, ease: [0.21, 0.65, 0.28, 0.99] }}
                className="grid gap-10 lg:grid-cols-2 lg:items-center"
              >
                <DemoImage
                  src={m.image}
                  alt={m.imageAlt}
                  sizes="(min-width: 1024px) 50vw, 100vw"
                  className="aspect-[16/10] w-full rounded-sm border border-white/10 bg-gradient-to-br from-[#151A15] via-[#20261D] to-[#0B0D0C]"
                  imgClassName="transition-transform duration-700 ease-out hover:scale-[1.03]"
                  fallbackLabel={m.name}
                />

                <div>
                  <p className="text-[11px] uppercase tracking-[0.3em] text-[#C6FF3E]">{m.tagline}</p>
                  <h3 className={cn(DISPLAY, "mt-3 text-3xl font-semibold uppercase text-white sm:text-4xl")}>
                    {m.name}
                  </h3>
                  <p className="mt-4 max-w-lg text-base leading-relaxed text-neutral-400">{m.blurb}</p>

                  <dl className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-sm border border-white/10 bg-white/10 sm:grid-cols-4">
                    {(
                      [
                        ["Price", m.price, "text-white"],
                        ["Range", `${m.range} km`, "text-white"],
                        ["Power", `${m.power} kW`, "text-[#C6FF3E]"],
                        ["0–100", m.sprint, "text-white"],
                      ] as const
                    ).map(([label, value, color]) => (
                      <div key={label} className="bg-[#0B0D0C] p-4 sm:p-5">
                        <dt className="text-[10px] uppercase tracking-[0.25em] text-neutral-500">{label}</dt>
                        <dd className={cn(DISPLAY, "mt-2 text-xl font-semibold sm:text-2xl", color)}>{value}</dd>
                      </div>
                    ))}
                  </dl>

                  <p className="mt-5 text-xs uppercase tracking-[0.2em] text-neutral-600">
                    Fictional specifications for a fictional marque.
                  </p>
                </div>
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
