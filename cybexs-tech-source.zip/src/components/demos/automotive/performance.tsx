"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Reveal } from "@/components/motion/reveal";
import { AURION_MODELS } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-aurion-display)]";

type Metric = { key: "range" | "power"; label: string; unit: string };

const METRICS: Metric[] = [
  { key: "range", label: "Range (WLTP)", unit: "km" },
  { key: "power", label: "Peak power", unit: "kW" },
];

export function Performance() {
  const reduce = useReducedMotion();

  return (
    <section id="performance" className="scroll-mt-16 border-t border-white/10 bg-[#0E100F]">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#C6FF3E]">Performance</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold uppercase leading-tight text-white sm:text-5xl")}>
            The numbers, drawn to scale.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-neutral-400">
            Range and power across the fictional line-up. The bars animate as they enter the viewport — unless your
            device prefers them still.
          </p>
        </Reveal>

        <div className="mt-12 space-y-12">
          {METRICS.map((metric) => {
            const max = Math.max(...AURION_MODELS.map((m) => m[metric.key]));
            const best = AURION_MODELS.find((m) => m[metric.key] === max)?.id;
            return (
              <Reveal key={metric.key}>
                <h3 className="text-[11px] font-semibold uppercase tracking-[0.3em] text-neutral-400">
                  {metric.label}
                </h3>
                <div className="mt-5 space-y-5">
                  {AURION_MODELS.map((m) => {
                    const value = m[metric.key];
                    const pct = Math.round((value / max) * 100);
                    const isBest = m.id === best;
                    return (
                      <div key={m.id} className="flex items-center gap-4 sm:gap-6">
                        <span className="w-24 shrink-0 text-[11px] uppercase tracking-[0.2em] text-neutral-500 sm:w-28">
                          {m.name}
                        </span>
                        <div
                          className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-white/8"
                          role="img"
                          aria-label={`${m.name}: ${value} ${metric.unit}`}
                        >
                          {reduce ? (
                            <div
                              className={cn("h-full rounded-full", isBest ? "bg-[#C6FF3E]" : "bg-white/35")}
                              style={{ width: `${pct}%` }}
                            />
                          ) : (
                            <motion.div
                              className={cn("h-full rounded-full", isBest ? "bg-[#C6FF3E]" : "bg-white/35")}
                              initial={{ width: 0 }}
                              whileInView={{ width: `${pct}%` }}
                              viewport={{ once: true, margin: "-40px" }}
                              transition={{ duration: 1.1, ease: [0.21, 0.65, 0.28, 0.99] }}
                            />
                          )}
                        </div>
                        <span className={cn(DISPLAY, "w-24 text-right text-sm font-semibold tabular-nums sm:w-28 sm:text-base", isBest ? "text-[#C6FF3E]" : "text-white")}>
                          {value} {metric.unit}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
