"use client";

import { useState } from "react";
import { Check } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-northbeam-display)]";

const STEPS = ["About you", "Your idea", "Review & submit"] as const;

type FormState = {
  name: string;
  email: string;
  ideaName: string;
  oneLiner: string;
  stage: string;
};

const EMPTY_FORM: FormState = { name: "", email: "", ideaName: "", oneLiner: "", stage: "" };

const fieldClasses = "w-full border-[#191919]/15 bg-white text-[#191919] focus-visible:ring-[#1E5C3F]";

export function ApplicationJourney() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const set = (key: keyof FormState) => (value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setError("");
  };

  const validateStep = (current: number): string => {
    if (current === 0) {
      if (!form.name.trim()) return "Please tell us your name.";
      if (!/\S+@\S+\.\S+/.test(form.email)) return "Please enter a valid email address.";
    }
    if (current === 1) {
      if (!form.ideaName.trim()) return "Give your idea a working name.";
      if (!form.oneLiner.trim()) return "One line is all we ask — but we do ask for it.";
      if (!form.stage) return "Select the stage your idea is at.";
    }
    return "";
  };

  const next = () => {
    const message = validateStep(step);
    if (message) {
      setError(message);
      return;
    }
    setError("");
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const submit = () => {
    setSubmitted(true);
  };

  const reset = () => {
    setForm(EMPTY_FORM);
    setStep(0);
    setError("");
    setSubmitted(false);
  };

  return (
    <section id="apply" className="scroll-mt-16 border-t border-[#191919]/10">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="mx-auto max-w-3xl">
          <div className="text-center">
            <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#1E5C3F]">Apply</p>
            <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold leading-tight text-[#191919] sm:text-5xl")}>
              The application journey.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-[#191919]/60">
              Three steps, roughly four minutes. This is a working interface demonstration — the last step explains
              exactly what happens to your answers (nothing).
            </p>
          </div>

          <div className="mt-10 border border-[#191919]/10 bg-[#FAF7F0] p-6 sm:p-10">
            {submitted ? (
              <div className="py-8 text-center" role="status">
                <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#1E5C3F] text-white">
                  <Check className="h-6 w-6" aria-hidden="true" />
                </span>
                <h3 className={cn(DISPLAY, "mt-6 text-2xl font-semibold text-[#191919]")}>
                  This is where the journey would begin.
                </h3>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-[#191919]/60">
                  Concept demo — applications are not collected. Nothing you entered was stored or sent anywhere; the
                  review step was the destination all along.
                </p>
                <button
                  type="button"
                  onClick={reset}
                  className="mt-7 inline-flex items-center border border-[#1E5C3F] px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-[#1E5C3F] transition-colors hover:bg-[#1E5C3F] hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E5C3F]"
                >
                  Start over
                </button>
              </div>
            ) : (
              <>
                {/* Progress indicator */}
                <ol className="flex items-start gap-2 sm:gap-3" aria-label="Application progress">
                  {STEPS.map((label, i) => {
                    const done = i < step;
                    const current = i === step;
                    return (
                      <li key={label} className="flex flex-1 flex-col items-center gap-2 text-center">
                        <span
                          aria-current={current ? "step" : undefined}
                          className={cn(
                            "grid h-8 w-8 place-items-center rounded-full border text-xs font-semibold transition-colors",
                            done && "border-transparent bg-[#1E5C3F] text-white",
                            current && "border-[#1E5C3F] bg-white text-[#1E5C3F]",
                            !done && !current && "border-[#191919]/20 text-[#191919]/40",
                          )}
                        >
                          {done ? <Check className="h-4 w-4" aria-hidden="true" /> : i + 1}
                        </span>
                        <span
                          className={cn(
                            "text-[10px] uppercase tracking-[0.15em] sm:text-[11px]",
                            current ? "font-semibold text-[#1E5C3F]" : "text-[#191919]/45",
                          )}
                        >
                          {label}
                        </span>
                      </li>
                    );
                  })}
                </ol>

                <div className="mt-8 border-t border-[#191919]/10 pt-8">
                  {step === 0 && (
                    <div className="grid gap-5 sm:grid-cols-2">
                      <div>
                        <Label htmlFor="apply-name" className="text-xs uppercase tracking-[0.15em] text-[#191919]/60">
                          Full name
                        </Label>
                        <Input
                          id="apply-name"
                          value={form.name}
                          onChange={(e) => set("name")(e.target.value)}
                          placeholder="Amara Okafor"
                          autoComplete="name"
                          className={cn(fieldClasses, "mt-2")}
                        />
                      </div>
                      <div>
                        <Label htmlFor="apply-email" className="text-xs uppercase tracking-[0.15em] text-[#191919]/60">
                          Email
                        </Label>
                        <Input
                          id="apply-email"
                          type="email"
                          value={form.email}
                          onChange={(e) => set("email")(e.target.value)}
                          placeholder="amara@example.com"
                          autoComplete="email"
                          className={cn(fieldClasses, "mt-2")}
                        />
                      </div>
                    </div>
                  )}

                  {step === 1 && (
                    <div className="grid gap-5">
                      <div>
                        <Label htmlFor="apply-idea" className="text-xs uppercase tracking-[0.15em] text-[#191919]/60">
                          Idea name
                        </Label>
                        <Input
                          id="apply-idea"
                          value={form.ideaName}
                          onChange={(e) => set("ideaName")(e.target.value)}
                          placeholder="Working title"
                          className={cn(fieldClasses, "mt-2")}
                        />
                      </div>
                      <div>
                        <Label htmlFor="apply-oneliner" className="text-xs uppercase tracking-[0.15em] text-[#191919]/60">
                          One-liner
                        </Label>
                        <Input
                          id="apply-oneliner"
                          value={form.oneLiner}
                          onChange={(e) => set("oneLiner")(e.target.value)}
                          placeholder="What it does, for whom, in one sentence."
                          className={cn(fieldClasses, "mt-2")}
                        />
                      </div>
                      <div>
                        <Label className="text-xs uppercase tracking-[0.15em] text-[#191919]/60">Stage</Label>
                        <Select value={form.stage} onValueChange={set("stage")}>
                          <SelectTrigger
                            aria-label="Stage"
                            className={cn(fieldClasses, "mt-2 w-full data-[placeholder]:text-[#191919]/40")}
                          >
                            <SelectValue placeholder="Select a stage" />
                          </SelectTrigger>
                          <SelectContent className="border-[#191919]/15 bg-white text-[#191919]">
                            {["Idea", "Prototype", "Early revenue"].map((stage) => (
                              <SelectItem key={stage} value={stage} className="focus:bg-[#1E5C3F]/10">
                                {stage}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div>
                      <dl className="grid gap-4 sm:grid-cols-2">
                        {(
                          [
                            ["Name", form.name],
                            ["Email", form.email],
                            ["Idea", form.ideaName],
                            ["Stage", form.stage],
                          ] as const
                        ).map(([label, value]) => (
                          <div key={label} className="border-b border-[#191919]/10 pb-3">
                            <dt className="text-[10px] uppercase tracking-[0.2em] text-[#191919]/45">{label}</dt>
                            <dd className="mt-1 text-sm font-medium text-[#191919]">{value || "—"}</dd>
                          </div>
                        ))}
                        <div className="border-b border-[#191919]/10 pb-3 sm:col-span-2">
                          <dt className="text-[10px] uppercase tracking-[0.2em] text-[#191919]/45">One-liner</dt>
                          <dd className="mt-1 text-sm font-medium text-[#191919]">{form.oneLiner || "—"}</dd>
                        </div>
                      </dl>
                      <p className="mt-5 text-xs italic text-[#191919]/45">
                        Review only — this screen is the end of the line in this demo.
                      </p>
                    </div>
                  )}

                  {error && (
                    <p role="alert" className="mt-5 text-sm font-medium text-[#C2410C]">
                      {error}
                    </p>
                  )}

                  <div className="mt-8 flex items-center justify-between gap-4">
                    {step > 0 ? (
                      <button
                        type="button"
                        onClick={() => {
                          setError("");
                          setStep((s) => s - 1);
                        }}
                        className="border border-[#191919]/20 px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-[#191919]/70 transition-colors hover:border-[#191919] hover:text-[#191919] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E5C3F]"
                      >
                        Back
                      </button>
                    ) : (
                      <span />
                    )}
                    {step < STEPS.length - 1 ? (
                      <button
                        type="button"
                        onClick={next}
                        className="bg-[#1E5C3F] px-7 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:bg-[#123B2A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E5C3F]"
                      >
                        Continue
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={submit}
                        className="bg-[#1E5C3F] px-7 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:bg-[#123B2A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E5C3F]"
                      >
                        Submit application (demo)
                      </button>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
