"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-northbeam-display)]";

type Track = "Pre-seed" | "Growth" | "Sector";

type Program = {
  id: string;
  name: string;
  track: Track;
  duration: string;
  cohort: string;
  description: string;
  details: string[];
  featured?: boolean;
};

const PROGRAMS: Program[] = [
  {
    id: "foundry",
    name: "Foundry",
    track: "Pre-seed",
    duration: "12 weeks",
    cohort: "Cohort of 10",
    description:
      "The flagship pre-seed accelerator: from napkin sketch to investable story, with weekly mentor sprints and a demo day in front of the (fictional) Northbeam network.",
    details: [
      "Weekly 1:1 mentor sprints with two dedicated leads",
      "Story, pricing and first-customer curriculum",
      "Demo day with the Northbeam mentor network",
    ],
    featured: true,
  },
  {
    id: "ignition",
    name: "Ignition Grant",
    track: "Pre-seed",
    duration: "8 weeks",
    cohort: "Rolling",
    description:
      "A non-dilutive grant plus workspace for idea-stage founders who need runway more than they need another pitch deck.",
    details: ["Small non-dilutive grant", "Desk space at the Northbeam house", "Light-touch monthly reviews"],
  },
  {
    id: "scale-lab",
    name: "Scale Lab",
    track: "Growth",
    duration: "16 weeks",
    cohort: "Cohort of 6",
    description:
      "Series-A readiness for teams with traction: metrics that hold up in diligence, a hire plan, and a raise narrative without the folklore.",
    details: ["Metrics and diligence warm-ups", "Org design and hiring plan", "Investor narrative workshops"],
  },
  {
    id: "revenue-runway",
    name: "Revenue Runway",
    track: "Growth",
    duration: "10 weeks",
    cohort: "Cohort of 8",
    description:
      "A go-to-market sprint for products that work but have not met their customers yet — positioning, pipeline and pricing under one roof.",
    details: ["Positioning and ICP clinics", "Pipeline playbooks", "Pricing experiments with real signals"],
  },
  {
    id: "climate-track",
    name: "Climate Track",
    track: "Sector",
    duration: "12 weeks",
    cohort: "Cohort of 8",
    description:
      "A vertical program for climate-tech founders: unit economics that survive a hard-nosed engineer, and pilots with fictional industrial partners.",
    details: ["Technical diligence mentoring", "Pilot design with industrial mentors", "Policy and market landscape briefings"],
  },
  {
    id: "health-frontier",
    name: "Health Frontier",
    track: "Sector",
    duration: "12 weeks",
    cohort: "Cohort of 6",
    description:
      "For digital-health teams navigating evidence, procurement and care pathways — the boring parts that decide whether patients ever benefit.",
    details: ["Evidence-generation planning", "Procurement and compliance clinics", "Care-pathway mapping sessions"],
  },
];

const FILTERS = ["All", "Pre-seed", "Growth", "Sector"] as const;

function ProgramCard({ program }: { program: Program }) {
  const [open, setOpen] = useState(false);

  return (
    <article
      className={cn(
        "flex h-full flex-col border p-6 transition-shadow hover:shadow-[0_20px_44px_-30px_rgba(25,25,25,0.4)] sm:p-7",
        program.featured ? "border-[#1E5C3F] bg-[#1E5C3F] text-white md:col-span-2" : "border-[#191919]/10 bg-white",
      )}
    >
      <div className="flex flex-wrap items-center gap-2.5">
        <span
          className={cn(
            "rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em]",
            program.featured
              ? "border-white/30 bg-white/10 text-white"
              : "border-[#1E5C3F]/20 bg-[#1E5C3F]/5 text-[#1E5C3F]",
          )}
        >
          {program.track}
        </span>
        <span className={cn("text-[10px] uppercase tracking-[0.18em]", program.featured ? "text-white/60" : "text-[#191919]/45")}>
          {program.duration} · {program.cohort}
        </span>
      </div>

      <h3 className={cn(DISPLAY, "mt-4 text-2xl font-semibold", program.featured ? "text-white" : "text-[#191919]")}>
        {program.name}
      </h3>
      <p className={cn("mt-3 flex-1 text-sm leading-relaxed", program.featured ? "text-white/75" : "text-[#191919]/65")}>
        {program.description}
      </p>

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls={`program-details-${program.id}`}
        className={cn(
          "mt-5 inline-flex w-fit items-center gap-1.5 text-sm font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E5C3F]",
          program.featured ? "text-white hover:text-white/80" : "text-[#1E5C3F] hover:text-[#123B2A]",
        )}
      >
        View program
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} aria-hidden="true" />
      </button>
      <div id={`program-details-${program.id}`} hidden={!open} className="mt-4">
        <ul className={cn("space-y-2 border-t pt-4 text-sm", program.featured ? "border-white/20 text-white/80" : "border-[#191919]/10 text-[#191919]/70")}>
          {program.details.map((detail) => (
            <li key={detail} className="flex gap-2.5">
              <span aria-hidden="true" className={program.featured ? "text-white/50" : "text-[#1E5C3F]"}>—</span>
              {detail}
            </li>
          ))}
        </ul>
      </div>
    </article>
  );
}

export function Programs() {
  const [filter, setFilter] = useState<string>("All");

  return (
    <section id="programs" className="scroll-mt-16">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#1E5C3F]">Programs</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold leading-tight text-[#191919] sm:text-5xl")}>
            Find the program that fits the stage, not the brochure.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#191919]/60">
            Six programs across three tracks. Filter by what your idea needs right now — every card expands to show
            what the weeks actually contain.
          </p>
        </Reveal>

        <Tabs value={filter} onValueChange={setFilter} className="mt-10">
          <TabsList className="h-auto w-fit rounded-full border border-[#191919]/10 bg-[#FAF7F0] p-1">
            {FILTERS.map((f) => (
              <TabsTrigger
                key={f}
                value={f}
                className="rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#191919]/60 transition-colors data-[state=active]:bg-[#1E5C3F] data-[state=active]:text-white sm:px-5"
              >
                {f}
              </TabsTrigger>
            ))}
          </TabsList>

          {FILTERS.map((f) => (
            <TabsContent key={f} value={f} className="mt-8 focus-visible:outline-none">
              <StaggerGroup className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {PROGRAMS.filter((p) => f === "All" || p.track === f).map((program) => (
                  <StaggerItem key={program.id} className={cn(program.featured && "md:col-span-2")}>
                    <ProgramCard program={program} />
                  </StaggerItem>
                ))}
              </StaggerGroup>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
