"use client";

import Image from "next/image";
import { useState, type CSSProperties } from "react";
import { cn } from "@/lib/utils";

/**
 * next/image wrapper used across the concept demos.
 * The parent container always carries a CSS gradient so that a missing
 * (still-generating) asset degrades into a tasteful color field with a
 * label — never a broken image.
 */
export function DemoImage({
  src,
  alt,
  className,
  imgClassName,
  sizes = "100vw",
  priority = false,
  fallbackLabel,
  style,
}: {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  sizes?: string;
  priority?: boolean;
  fallbackLabel?: string;
  style?: CSSProperties;
}) {
  const [failed, setFailed] = useState(false);

  return (
    <div className={cn("relative overflow-hidden", className)} style={style}>
      {!failed ? (
        <Image
          src={src}
          alt={alt}
          fill
          sizes={sizes}
          priority={priority}
          onError={() => setFailed(true)}
          className={cn("object-cover", imgClassName)}
        />
      ) : (
        fallbackLabel && (
          <span className="absolute inset-0 grid place-items-center px-6 text-center text-[11px] font-medium uppercase tracking-[0.3em] opacity-40">
            {fallbackLabel}
          </span>
        )
      )}
    </div>
  );
}
