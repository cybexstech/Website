"use client";

import { useState } from "react";
import { Drawer, DrawerContent, DrawerDescription, DrawerTitle } from "@/components/ui/drawer";
import { DemoImage } from "@/components/demos/demo-image";
import { useFootwearCart } from "./cart";
import { footwearProductById } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-solstice-display)]";

export function CartDrawer({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const cart = useFootwearCart();
  const [checkedOut, setCheckedOut] = useState(false);

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="bg-[#F4F1EA] text-[#141414]">
        <div className="mx-auto w-full max-w-md px-5 pb-8 pt-2">
          <DrawerTitle className={cn(DISPLAY, "text-2xl uppercase")}>Demo cart</DrawerTitle>
          <DrawerDescription className="mt-1 text-sm text-[#141414]/50">
            A working cart for things that do not exist.
          </DrawerDescription>

          {cart.lines.length === 0 ? (
            <p className="mt-6 border border-dashed border-[#141414]/20 p-6 text-center text-sm text-[#141414]/50">
              Your cart is empty — pick a size and add something.
            </p>
          ) : (
            <>
              <ul className="scrollbar-slim mt-5 max-h-[38vh] space-y-3 overflow-y-auto pr-1">
                {cart.lines.map((line) => {
                  const product = footwearProductById(line.productId);
                  if (!product) return null;
                  return (
                    <li
                      key={`${line.productId}-${line.size}`}
                      className="flex gap-3 border border-[#141414]/10 bg-white p-3"
                    >
                      <DemoImage
                        src={product.image}
                        alt={product.name}
                        sizes="80px"
                        className="h-20 w-16 shrink-0 bg-gradient-to-br from-[#E5DFD2] via-[#D3CBB8] to-[#B4AA92]"
                        fallbackLabel={product.name}
                      />
                      <div className="flex-1">
                        <p className="font-semibold">{product.name}</p>
                        <p className="mt-0.5 text-[11px] uppercase tracking-[0.15em] text-[#141414]/45">
                          EU {line.size} · {product.category}
                        </p>
                        <div className="mt-2 flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => cart.updateQty(line.productId, line.size, -1)}
                            disabled={line.qty <= 1}
                            aria-label={`Decrease quantity of ${product.name}, size EU ${line.size}`}
                            className="grid h-7 w-7 place-items-center rounded-full border border-[#141414]/20 text-sm font-bold transition-colors hover:border-[#141414] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF4D2E] disabled:opacity-30"
                          >
                            −
                          </button>
                          <span className="w-6 text-center text-sm font-semibold tabular-nums">{line.qty}</span>
                          <button
                            type="button"
                            onClick={() => cart.updateQty(line.productId, line.size, 1)}
                            aria-label={`Increase quantity of ${product.name}, size EU ${line.size}`}
                            className="grid h-7 w-7 place-items-center rounded-full border border-[#141414]/20 text-sm font-bold transition-colors hover:border-[#141414] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF4D2E]"
                          >
                            +
                          </button>
                        </div>
                      </div>
                      <div className="flex flex-col items-end justify-between">
                        <button
                          type="button"
                          onClick={() => cart.removeItem(line.productId, line.size)}
                          aria-label={`Remove ${product.name}, size EU ${line.size}, from cart`}
                          className="text-xs text-[#141414]/40 underline underline-offset-4 transition-colors hover:text-[#FF4D2E]"
                        >
                          Remove
                        </button>
                        <span className="font-semibold">€{product.price * line.qty}</span>
                      </div>
                    </li>
                  );
                })}
              </ul>

              <div className="mt-5 flex items-baseline justify-between border-t border-[#141414]/10 pt-4">
                <span className="text-sm font-semibold uppercase tracking-[0.15em]">Subtotal</span>
                <span className={cn(DISPLAY, "text-2xl")}>€{cart.subtotal}</span>
              </div>

              {checkedOut ? (
                <p
                  role="status"
                  className="mt-4 border border-[#FF4D2E]/30 bg-[#FF4D2E]/10 px-4 py-3.5 text-sm leading-relaxed text-[#C22D14]"
                >
                  Demo checkout — no real order. No payment was taken, because there is nothing to pay for.
                </p>
              ) : (
                <button
                  type="button"
                  onClick={() => setCheckedOut(true)}
                  className="mt-4 w-full bg-[#FF4D2E] py-3.5 text-sm font-bold uppercase tracking-[0.2em] text-white transition-colors hover:bg-[#E43E20] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#141414]"
                >
                  Checkout (demo)
                </button>
              )}
            </>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
