"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { footwearProductById } from "./data";

export type FootwearCartLine = { productId: string; size: number; qty: number };

type FootwearCartContextValue = {
  lines: FootwearCartLine[];
  count: number;
  subtotal: number;
  addItem: (productId: string, size: number) => void;
  updateQty: (productId: string, size: number, delta: number) => void;
  removeItem: (productId: string, size: number) => void;
};

const FootwearCartContext = createContext<FootwearCartContextValue | null>(null);

/** Demo-only cart. Purely in-memory React state — there is nothing to pay for. */
export function FootwearCartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<FootwearCartLine[]>([]);

  const addItem = useCallback((productId: string, size: number) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.productId === productId && l.size === size);
      if (existing) {
        return prev.map((l) =>
          l.productId === productId && l.size === size ? { ...l, qty: l.qty + 1 } : l,
        );
      }
      return [...prev, { productId, size, qty: 1 }];
    });
  }, []);

  const updateQty = useCallback((productId: string, size: number, delta: number) => {
    setLines((prev) =>
      prev.map((l) =>
        l.productId === productId && l.size === size
          ? { ...l, qty: Math.max(1, l.qty + delta) }
          : l,
      ),
    );
  }, []);

  const removeItem = useCallback((productId: string, size: number) => {
    setLines((prev) => prev.filter((l) => !(l.productId === productId && l.size === size)));
  }, []);

  const value = useMemo<FootwearCartContextValue>(() => {
    const count = lines.reduce((sum, l) => sum + l.qty, 0);
    const subtotal = lines.reduce(
      (sum, l) => sum + (footwearProductById(l.productId)?.price ?? 0) * l.qty,
      0,
    );
    return { lines, count, subtotal, addItem, updateQty, removeItem };
  }, [lines, addItem, updateQty, removeItem]);

  return <FootwearCartContext.Provider value={value}>{children}</FootwearCartContext.Provider>;
}

export function useFootwearCart(): FootwearCartContextValue {
  const ctx = useContext(FootwearCartContext);
  if (!ctx) throw new Error("useFootwearCart must be used within FootwearCartProvider");
  return ctx;
}
