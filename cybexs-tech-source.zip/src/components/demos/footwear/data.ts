// ---------------------------------------------------------------------------
// SOLSTICE — fictional footwear label (concept demo data)
// ---------------------------------------------------------------------------

export type FootwearCategory = "Low-tops" | "High-tops" | "Runners" | "Sandals";

export type FootwearProduct = {
  id: string;
  name: string;
  category: FootwearCategory;
  price: number;
  image: string;
  blurb: string;
};

export const SIZES = [39, 40, 41, 42, 43, 44, 45] as const;

export const FOOTWEAR_CATEGORIES = ["All", "Low-tops", "High-tops", "Runners", "Sandals"] as const;

export const FOOTWEAR_PRODUCTS: FootwearProduct[] = [
  {
    id: "court-01",
    name: "Court 01",
    category: "Low-tops",
    price: 110,
    image: "/demo-assets/footwear/s1.jpg",
    blurb: "A low-profile court classic with a gum sole and zero branding.",
  },
  {
    id: "rooftop-hi",
    name: "Rooftop Hi",
    category: "High-tops",
    price: 135,
    image: "/demo-assets/footwear/s2.jpg",
    blurb: "Padded collar, high ankle, built for late walks home.",
  },
  {
    id: "drift-runner",
    name: "Drift Runner",
    category: "Runners",
    price: 150,
    image: "/demo-assets/footwear/s3.jpg",
    blurb: "The everyday runner — foam midsole, reflective heel.",
  },
  {
    id: "dune-slide",
    name: "Dune Slide",
    category: "Sandals",
    price: 75,
    image: "/demo-assets/footwear/s4.jpg",
    blurb: "A sculpted foam slide for the days after the run.",
  },
];

export function footwearProductById(id: string): FootwearProduct | undefined {
  return FOOTWEAR_PRODUCTS.find((p) => p.id === id);
}
