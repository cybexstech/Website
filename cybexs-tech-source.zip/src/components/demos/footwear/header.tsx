"use client";

import { useState } from "react";
import { ShoppingBag } from "lucide-react";
import { useFootwearCart } from "./cart";
import { CartDrawer } from "./cart-drawer";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-solstice-display)]";

export function FootwearHeader() {
  const cart = useFootwearCart();
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <header className="border-b border-[#141414]/10 bg-[#F4F1EA]">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-4 sm:px-8">
        <a
          href="#top"
          className={cn(DISPLAY, "text-xl uppercase tracking-tight text-[#141414] sm:text-2xl")}
        >
          SOLSTICE<span className="text-[#FF4D2E]">.</span>
        </a>

        <nav aria-label="SOLSTICE" className="flex items-center gap-4 sm:gap-8">
          <a
            href="#shop"
            className="text-xs font-bold uppercase tracking-[0.18em] text-[#141414]/70 transition-colors hover:text-[#FF4D2E] sm:text-sm"
          >
            Shop
          </a>
          <a
            href="#about"
            className="text-xs font-bold uppercase tracking-[0.18em] text-[#141414]/70 transition-colors hover:text-[#FF4D2E] sm:text-sm"
          >
            About
          </a>
          <button
            type="button"
            onClick={() => setCartOpen(true)}
            aria-label={`Open demo cart, ${cart.count} ${cart.count === 1 ? "item" : "items"}`}
            className="relative inline-flex items-center gap-2 rounded-full bg-[#141414] px-4 py-2.5 text-xs font-bold uppercase tracking-[0.15em] text-white transition-colors hover:bg-[#FF4D2E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF4D2E]"
          >
            <ShoppingBag className="h-4 w-4" aria-hidden="true" />
            <span className="hidden sm:inline">Cart</span>
            {cart.count > 0 && (
              <span
                aria-hidden="true"
                className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-[#FF4D2E] px-1 text-[10px] font-bold text-white ring-2 ring-[#F4F1EA]"
              >
                {cart.count}
              </span>
            )}
          </button>
        </nav>
      </div>

      <CartDrawer open={cartOpen} onOpenChange={setCartOpen} />
    </header>
  );
}
