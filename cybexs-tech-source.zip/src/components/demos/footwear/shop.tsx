"use client";

import { useEffect, useRef, useState } from "react";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { useFootwearCart } from "./cart";
import { FOOTWEAR_CATEGORIES, FOOTWEAR_PRODUCTS, SIZES, type FootwearProduct } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-solstice-display)]";

function ProductCard({ product }: { product: FootwearProduct }) {
  const cart = useFootwearCart();
  const [size, setSize] = useState<number | null>(null);
  const [added, setAdded] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const handleAdd = () => {
    if (!size) return;
    cart.addItem(product.id, size);
    setAdded(true);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setAdded(false), 1600);
  };

  return (
    <article className="group flex h-full flex-col border border-[#141414]/10 bg-white">
      <div className="relative overflow-hidden">
        <DemoImage
          src={product.image}
          alt={`${product.name} — ${product.category.toLowerCase()} by the fictional SOLSTICE label`}
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
          className="aspect-[4/5] w-full bg-gradient-to-br from-[#E5DFD2] via-[#D3CBB8] to-[#B4AA92]"
          imgClassName="transition-transform duration-700 ease-out group-hover:scale-105"
          fallbackLabel={product.name}
        />
        <span className="absolute left-3 top-3 bg-[#141414] px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-white">
          {product.category}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-4 sm:p-5">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className={cn(DISPLAY, "text-lg uppercase leading-tight text-[#141414]")}>{product.name}</h3>
          <span className="font-semibold text-[#141414]">€{product.price}</span>
        </div>
        <p className="mt-1.5 text-sm leading-relaxed text-[#141414]/55">{product.blurb}</p>

        <div className="mt-4" role="radiogroup" aria-label={`Select size (EU) for ${product.name}`}>
          <div className="flex flex-wrap gap-1.5">
            {SIZES.map((s) => {
              const selected = size === s;
              return (
                <button
                  key={s}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setSize(s)}
                  className={cn(
                    "h-8 w-10 rounded-full border text-xs font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF4D2E]",
                    selected
                      ? "border-[#141414] bg-[#141414] text-white"
                      : "border-[#141414]/20 text-[#141414]/70 hover:border-[#141414] hover:text-[#141414]",
                  )}
                >
                  {s}
                </button>
              );
            })}
          </div>
        </div>
        <p aria-live="polite" className="mt-2 min-h-4 text-[11px] uppercase tracking-[0.15em] text-[#141414]/40">
          {size ? `EU ${size} selected` : "Select size"}
        </p>

        <button
          type="button"
          disabled={!size}
          onClick={handleAdd}
          className={cn(
            "mt-3 w-full py-3 text-sm font-bold uppercase tracking-[0.15em] text-white transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF4D2E] disabled:cursor-not-allowed disabled:opacity-40",
            added ? "bg-[#1E7A3C]" : "bg-[#141414] hover:bg-[#FF4D2E]",
          )}
        >
          {added ? "Added ✓" : "Add to cart"}
        </button>
      </div>
    </article>
  );
}

export function FootwearShop() {
  const [category, setCategory] = useState<string>("All");
  const visible = FOOTWEAR_PRODUCTS.filter((p) => category === "All" || p.category === category);
  const showPromoTile = category === "All";

  return (
    <section id="shop" className="scroll-mt-16">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-xl">
            <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-[#FF4D2E]">The Line</p>
            <h2 className={cn(DISPLAY, "mt-4 text-4xl uppercase leading-[1.02] text-[#141414] sm:text-5xl")}>
              Four silhouettes. Nothing else.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-[#141414]/60">
              Choose a category, pick your size, watch the demo cart do its thing. Every interaction works; none of it
              leads anywhere real.
            </p>
          </div>
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter products by category">
            {FOOTWEAR_CATEGORIES.map((c) => {
              const active = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setCategory(c)}
                  className={cn(
                    "rounded-full border px-4 py-2 text-[11px] font-bold uppercase tracking-[0.15em] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF4D2E]",
                    active
                      ? "border-[#141414] bg-[#141414] text-white"
                      : "border-[#141414]/20 bg-transparent text-[#141414]/60 hover:border-[#141414] hover:text-[#141414]",
                  )}
                >
                  {c}
                </button>
              );
            })}
          </div>
        </Reveal>

        <StaggerGroup className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {visible.map((product) => (
            <StaggerItem key={product.id} className="h-full">
              <ProductCard product={product} />
            </StaggerItem>
          ))}

          {showPromoTile && (
            <StaggerItem className="h-full">
              <div className="flex h-full flex-col justify-between bg-[#141414] p-6 text-[#F4F1EA] sm:p-7">
                <p className={cn(DISPLAY, "text-2xl uppercase leading-[1.05]")}>
                  New drops<br />every<br />
                  <span className="text-[#FF4D2E]">Friday.</span>
                </p>
                <p className="mt-6 text-xs uppercase tracking-[0.2em] text-[#F4F1EA]/50">
                  Demo catalog — nothing here is for sale.
                </p>
              </div>
            </StaggerItem>
          )}
        </StaggerGroup>
      </div>
    </section>
  );
}
