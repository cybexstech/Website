// ---------------------------------------------------------------------------
// Garam Theory — fictional spice house (concept demo data)
// ---------------------------------------------------------------------------

export type Blend = {
  id: string;
  name: string;
  kind: string;
  heat: number; // 1–5
  price: number;
  image: string;
  notes: string;
  blurb: string;
};

export const HEAT_STEPS: { level: number; label: string }[] = [
  { level: 1, label: "Mild" },
  { level: 2, label: "Warm" },
  { level: 3, label: "Medium" },
  { level: 4, label: "Hot" },
  { level: 5, label: "Fiery" },
];

export const BLENDS: Blend[] = [
  {
    id: "golden-hour",
    name: "Golden Hour",
    kind: "Turmeric blend",
    heat: 1,
    price: 14,
    image: "/demo-assets/masala/m1.jpg",
    notes: "Turmeric · Black lime · Warm florals",
    blurb: "The gentle opener — earthy, floral, quietly golden. Built for butter, eggs and slow mornings.",
  },
  {
    id: "ember",
    name: "Ember",
    kind: "Chili blend",
    heat: 4,
    price: 16,
    image: "/demo-assets/masala/m2.jpg",
    notes: "Kashmiri chili · Smoked paprika · Garlic",
    blurb: "Color first, then the slow burn. Roast potatoes fear it; roast chicken dreams of it.",
  },
  {
    id: "masala-7",
    name: "Masala No. 7",
    kind: "Garam masala",
    heat: 2,
    price: 18,
    image: "/demo-assets/masala/m3.jpg",
    notes: "Cardamom · Cinnamon · Clove · Black pepper",
    blurb: "The house chord — seven spices, toasted and ground weekly. Warmth without the fire.",
  },
];

export type Recipe = {
  id: string;
  name: string;
  description: string;
  steps: string[];
  blendId: string;
};

export const RECIPES: Recipe[] = [
  {
    id: "eggs",
    name: "Turmeric Morning Eggs",
    description: "A five-minute breakfast that tastes like it took twenty.",
    steps: [
      "Melt a knob of butter over low heat — never let it brown.",
      "Bloom 1 tsp Golden Hour in the butter until the kitchen smells earthy and sweet.",
      "Add beaten eggs and keep the pan moving; pull them off just before they look done.",
      "Finish with black pepper and a squeeze of lime — acid lifts the turmeric.",
    ],
    blendId: "golden-hour",
  },
  {
    id: "potatoes",
    name: "Ember Roast Potatoes",
    description: "The crunchiest thing on any table, with a slow red heat underneath.",
    steps: [
      "Parboil quartered potatoes for 8 minutes, then steam-dry with the lid off.",
      "Toss in oil with 2 tsp Ember until every face is coated.",
      "Roast at 220°C for 35 minutes, turning once, and do not crowd the tray.",
      "Salt hard, finish with lemon zest while they scream.",
    ],
    blendId: "ember",
  },
  {
    id: "dal",
    name: "Sunday Dal, No. 7",
    description: "The pot that simmers while the week negotiates with itself.",
    steps: [
      "Simmer red lentils with turmeric and water until they surrender, about 25 minutes.",
      "In a separate pan, heat ghee and bloom 1 tbsp Masala No. 7 for thirty seconds.",
      "Pour the sizzling ghee over the dal and stir — listen to it change.",
      "Season, then let it sit ten minutes off the heat. It is better for the waiting.",
    ],
    blendId: "masala-7",
  },
];

export function blendById(id: string): Blend | undefined {
  return BLENDS.find((b) => b.id === id);
}
