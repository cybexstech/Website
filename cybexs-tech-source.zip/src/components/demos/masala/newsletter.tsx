"use client";

import { useState } from "react";
import { Reveal } from "@/components/motion/reveal";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-garam-display)]";

export function Newsletter() {
  const [sent, setSent] = useState(false);

  return (
    <section className="bg-[#C2410C] text-[#FBF3E4]">
      <div className="mx-auto grid max-w-7xl items-center gap-8 px-5 py-16 sm:px-8 lg:grid-cols-2">
        <Reveal>
          <h2 className={cn(DISPLAY, "text-3xl font-semibold leading-tight sm:text-4xl")}>
            Letters from the lab.
          </h2>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-[#FBF3E4]/75 sm:text-base">
            One note a month on what is blooming, toasting or burning in the (fictional) test kitchen.
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              setSent(true);
            }}
            className="flex flex-col gap-3 sm:flex-row"
          >
            <div className="flex-1">
              <label htmlFor="garam-email" className="sr-only">
                Email address
              </label>
              <input
                id="garam-email"
                name="email"
                type="email"
                required
                autoComplete="email"
                placeholder="you@example.com"
                className="w-full border border-[#FBF3E4]/40 bg-transparent px-4 py-3.5 text-sm text-[#FBF3E4] placeholder:text-[#FBF3E4]/50 focus-visible:border-[#FBF3E4] focus-visible:outline-none"
              />
            </div>
            <button
              type="submit"
              className="bg-[#FBF3E4] px-7 py-3.5 text-xs font-bold uppercase tracking-[0.2em] text-[#1A0F08] transition-colors hover:bg-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FBF3E4]"
            >
              Subscribe (demo)
            </button>
          </form>
          <p aria-live="polite" className="mt-3 min-h-5 text-sm text-[#FBF3E4]/85">
            {sent && "Demo — not subscribed anywhere. Your address never left this page."}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
