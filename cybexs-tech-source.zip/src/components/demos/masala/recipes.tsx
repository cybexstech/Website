"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Reveal } from "@/components/motion/reveal";
import { RECIPES, blendById } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-garam-display)]";

export function Recipes() {
  return (
    <section id="learn" className="scroll-mt-16 bg-[#1A0F08] text-[#FBF3E4]">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-[#E8A020]">In the kitchen</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold leading-tight sm:text-5xl")}>
            Three ways to use the shelf.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#FBF3E4]/60">
            Short methods, honest steps, and exactly which tin to reach for. Fictional recipes for a fictional
            spice house — the technique is real.
          </p>
        </Reveal>

        <Tabs defaultValue={RECIPES[0].id} className="mt-10">
          <TabsList className="h-auto w-full flex-wrap justify-start gap-1 rounded-full border border-white/10 bg-white/5 p-1 sm:w-fit">
            {RECIPES.map((recipe) => (
              <TabsTrigger
                key={recipe.id}
                value={recipe.id}
                className="rounded-full px-4 py-2.5 text-xs font-bold uppercase tracking-[0.15em] text-[#FBF3E4]/60 transition-colors hover:text-[#FBF3E4] data-[state=active]:bg-[#E8A020] data-[state=active]:text-[#1A0F08] sm:px-5"
              >
                {recipe.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {RECIPES.map((recipe) => {
            const blend = blendById(recipe.blendId);
            return (
              <TabsContent key={recipe.id} value={recipe.id} className="mt-8 focus-visible:outline-none">
                <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-start">
                  <div>
                    <p className="text-sm italic text-[#FBF3E4]/55">{recipe.description}</p>
                    <ol className="mt-6">
                      {recipe.steps.map((step, i) => (
                        <li
                          key={step}
                          className="flex gap-4 border-b border-white/10 py-4 text-sm leading-relaxed text-[#FBF3E4]/80 sm:text-base"
                        >
                          <span className={cn(DISPLAY, "shrink-0 text-2xl font-semibold text-[#E8A020]")}>
                            {String(i + 1).padStart(2, "0")}
                          </span>
                          {step}
                        </li>
                      ))}
                    </ol>
                  </div>

                  <aside className="border border-[#E8A020]/30 bg-white/5 p-6 sm:p-7">
                    <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-[#E8A020]">Pairs with</p>
                    {blend && (
                      <>
                        <h3 className={cn(DISPLAY, "mt-3 text-2xl font-semibold")}>{blend.name}</h3>
                        <p className="mt-2 text-sm text-[#FBF3E4]/60">{blend.notes}</p>
                        <div className="mt-4 inline-flex items-center gap-1" aria-hidden="true">
                          {Array.from({ length: 5 }, (_, i) => (
                            <span
                              key={i}
                              className={cn("h-1.5 w-5 rounded-full", i < blend.heat ? "bg-[#C2410C]" : "bg-white/15")}
                            />
                          ))}
                          <span className="ml-2 text-[11px] uppercase tracking-[0.18em] text-[#FBF3E4]/50">
                            Heat {blend.heat}/5
                          </span>
                        </div>
                        <p className="mt-5 border-t border-white/10 pt-4 text-sm text-[#FBF3E4]/55">
                          In the tin: <span className="font-semibold text-[#FBF3E4]">€{blend.price}</span> — demo only,
                          nothing is sold.
                        </p>
                      </>
                    )}
                  </aside>
                </div>
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </section>
  );
}
