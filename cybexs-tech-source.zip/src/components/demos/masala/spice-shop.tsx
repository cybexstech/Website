"use client";

import { useState } from "react";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { BLENDS, HEAT_STEPS, type Blend } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-garam-display)]";

function HeatDots({ level, className }: { level: number; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1", className)} aria-hidden="true">
      {Array.from({ length: 5 }, (_, i) => (
        <span
          key={i}
          className={cn("h-1.5 w-5 rounded-full", i < level ? "bg-[#C2410C]" : "bg-[#1A0F08]/15")}
        />
      ))}
    </span>
  );
}

function BlendCard({ blend }: { blend: Blend }) {
  const [added, setAdded] = useState(false);

  return (
    <article className="flex h-full flex-col border border-[#1A0F08]/10 bg-white">
      <div className="group relative overflow-hidden">
        <DemoImage
          src={blend.image}
          alt={`${blend.name} — ${blend.kind.toLowerCase()} by the fictional Garam Theory spice house`}
          sizes="(min-width: 768px) 33vw, 100vw"
          className="aspect-[4/3] w-full bg-gradient-to-br from-[#F0DFC0] via-[#E8A020]/60 to-[#C2410C]/50"
          imgClassName="transition-transform duration-700 ease-out group-hover:scale-105"
          fallbackLabel={blend.name}
        />
      </div>
      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-[#E8A020]">{blend.kind}</p>
        <h3 className={cn(DISPLAY, "mt-2 text-2xl font-semibold text-[#1A0F08]")}>{blend.name}</h3>
        <div className="mt-3 flex items-center gap-3">
          <HeatDots level={blend.heat} />
          <span className="text-[11px] uppercase tracking-[0.18em] text-[#1A0F08]/50">Heat {blend.heat}/5</span>
        </div>
        <p className="mt-3 text-sm text-[#1A0F08]/70">{blend.notes}</p>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-[#1A0F08]/55">{blend.blurb}</p>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-[#1A0F08]/10 pt-4">
          <span className="text-lg font-semibold text-[#1A0F08]">€{blend.price}</span>
          <button
            type="button"
            onClick={() => setAdded(true)}
            className={cn(
              "px-4 py-2.5 text-[11px] font-bold uppercase tracking-[0.18em] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C2410C]",
              added ? "bg-[#1E7A3C] text-white" : "bg-[#1A0F08] text-[#FBF3E4] hover:bg-[#C2410C]",
            )}
          >
            {added ? "In your tin ✓" : "Add to tin (demo)"}
          </button>
        </div>
        <p aria-live="polite" className="mt-2 min-h-4 text-xs italic text-[#C2410C]">
          {added && "Added to your tin — demo only."}
        </p>
      </div>
    </article>
  );
}

export function SpiceShop() {
  const [heat, setHeat] = useState(3);
  const [showAll, setShowAll] = useState(false);

  const currentLabel = HEAT_STEPS.find((s) => s.level === heat)?.label ?? "Medium";
  const withinHeat = BLENDS.filter((b) => b.heat <= heat);
  const hiddenCount = BLENDS.length - withinHeat.length;
  const visible = (showAll ? BLENDS : withinHeat)
    .slice()
    .sort((a, b) => Math.abs(a.heat - heat) - Math.abs(b.heat - heat));

  return (
    <section id="shop" className="scroll-mt-16 bg-[#FBF3E4]">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-[#C2410C]">The Blends</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-semibold leading-tight text-[#1A0F08] sm:text-5xl")}>
            Find your heat.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#1A0F08]/60">
            Three blends, three temperatures. Set your tolerance and the shelf rearranges itself around you —
            closest match first.
          </p>
        </Reveal>

        {/* Heat selector */}
        <Reveal delay={0.05} className="mt-10">
          <div className="border border-[#1A0F08]/10 bg-white p-5 sm:p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#1A0F08]/50">Your heat tolerance</p>
            <div
              className="mt-4 flex flex-col gap-1 rounded-full border border-[#1A0F08]/15 bg-[#FBF3E4] p-1 sm:flex-row"
              role="group"
              aria-label="Heat tolerance"
            >
              {HEAT_STEPS.map((step) => {
                const active = heat === step.level;
                return (
                  <button
                    key={step.level}
                    type="button"
                    aria-pressed={active}
                    onClick={() => {
                      setHeat(step.level);
                      setShowAll(false);
                    }}
                    className={cn(
                      "flex-1 whitespace-nowrap rounded-full px-4 py-2.5 text-xs font-bold uppercase tracking-[0.18em] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C2410C]",
                      active
                        ? "bg-[#C2410C] text-white shadow-[0_10px_22px_-12px_rgba(194,65,12,0.9)]"
                        : "text-[#1A0F08]/60 hover:bg-[#1A0F08]/5 hover:text-[#1A0F08]",
                    )}
                  >
                    {step.label}
                  </button>
                );
              })}
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2">
              <p aria-live="polite" className="text-sm text-[#1A0F08]/65">
                {showAll
                  ? `Showing all 3 blends, sorted closest to “${currentLabel}”.`
                  : `Showing ${visible.length} of 3 blends at “${currentLabel}” heat.`}
                {hiddenCount > 0 && !showAll && ` ${hiddenCount} blend${hiddenCount > 1 ? "s" : ""} hidden above your heat.`}
              </p>
              {hiddenCount > 0 && (
                <button
                  type="button"
                  onClick={() => setShowAll(true)}
                  className="text-xs font-bold uppercase tracking-[0.15em] text-[#C2410C] underline underline-offset-4 transition-colors hover:text-[#1A0F08]"
                >
                  Show everything
                </button>
              )}
              {showAll && hiddenCount > 0 && (
                <button
                  type="button"
                  onClick={() => setShowAll(false)}
                  className="text-xs font-bold uppercase tracking-[0.15em] text-[#C2410C] underline underline-offset-4 transition-colors hover:text-[#1A0F08]"
                >
                  Filter by heat again
                </button>
              )}
            </div>
          </div>
        </Reveal>

        <StaggerGroup className="mt-10 grid gap-6 md:grid-cols-3">
          {visible.map((blend) => (
            <StaggerItem key={blend.id} className="h-full">
              <BlendCard blend={blend} />
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
