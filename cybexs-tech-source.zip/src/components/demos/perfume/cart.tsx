"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";

type PerfumeCartContextValue = {
  ids: string[];
  count: number;
  has: (id: string) => boolean;
  add: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
};

const PerfumeCartContext = createContext<PerfumeCartContextValue | null>(null);

/** Demo-only discovery set. Purely in-memory React state — nothing is sent anywhere. */
export function PerfumeCartProvider({ children }: { children: ReactNode }) {
  const [ids, setIds] = useState<string[]>([]);

  const add = useCallback((id: string) => {
    setIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  }, []);
  const remove = useCallback((id: string) => {
    setIds((prev) => prev.filter((x) => x !== id));
  }, []);
  const clear = useCallback(() => setIds([]), []);

  const value = useMemo<PerfumeCartContextValue>(
    () => ({
      ids,
      count: ids.length,
      has: (id) => ids.includes(id),
      add,
      remove,
      clear,
    }),
    [ids, add, remove, clear],
  );

  return <PerfumeCartContext.Provider value={value}>{children}</PerfumeCartContext.Provider>;
}

export function usePerfumeCart(): PerfumeCartContextValue {
  const ctx = useContext(PerfumeCartContext);
  if (!ctx) throw new Error("usePerfumeCart must be used within PerfumeCartProvider");
  return ctx;
}
