"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { StaggerGroup, StaggerItem } from "@/components/motion/reveal";
import { DemoImage } from "@/components/demos/demo-image";
import { usePerfumeCart } from "./cart";
import { PERFUME_PRODUCTS, perfumeNotesOf, type PerfumeProduct } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-elore-display)]";

function keyNotes(product: PerfumeProduct) {
  return [...product.heart.slice(0, 2), ...product.base.slice(0, 1)].join(" · ");
}

function ProductDialog({ product }: { product: PerfumeProduct }) {
  const cart = usePerfumeCart();
  const [justAdded, setJustAdded] = useState(false);
  const inSet = cart.has(product.id);

  return (
    <DialogContent
      className="gap-0 overflow-hidden border-[#1C1917]/15 bg-[#F7F3EC] p-0 sm:max-w-3xl"
      showCloseButton
    >
      <div className="grid sm:grid-cols-[2fr_3fr]">
        <div className="relative min-h-[280px]">
          <DemoImage
            src={product.image}
            alt={`${product.reference} — ${product.name} flacon`}
            sizes="(min-width: 640px) 40vw, 100vw"
            className="absolute inset-0 bg-gradient-to-br from-[#E7DBC4] via-[#D9C7A4] to-[#B49B6C]"
            fallbackLabel={product.name}
          />
        </div>

        <div className="flex flex-col p-6 sm:p-8">
          <p className="text-[10px] uppercase tracking-[0.3em] text-[#B49B6C]">{product.family}</p>
          <DialogTitle className={cn(DISPLAY, "mt-2 text-3xl font-medium leading-tight text-[#1C1917]")}>
            {product.reference} — {product.name}
          </DialogTitle>
          <DialogDescription className="mt-3 text-sm leading-relaxed text-[#1C1917]/70">
            {product.description}
          </DialogDescription>

          <dl className="mt-6 space-y-3 border-t border-[#1C1917]/10 pt-5 text-sm">
            {(
              [
                ["Top", product.top],
                ["Heart", product.heart],
                ["Base", product.base],
              ] as const
            ).map(([label, notes]) => (
              <div key={label} className="flex items-baseline gap-4">
                <dt className="w-12 shrink-0 text-[10px] uppercase tracking-[0.25em] text-[#1C1917]/50">{label}</dt>
                <dd className="flex flex-wrap gap-1.5">
                  {notes.map((note) => (
                    <span
                      key={note}
                      className="rounded-full border border-[#1C1917]/15 bg-white/60 px-2.5 py-0.5 text-[11px] tracking-wide text-[#1C1917]/80"
                    >
                      {note}
                    </span>
                  ))}
                </dd>
              </div>
            ))}
          </dl>

          <div className="mt-auto pt-7">
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#1C1917]/10 pt-5">
              <span className={cn(DISPLAY, "text-2xl text-[#1C1917]")}>€{product.price}</span>
              <button
                type="button"
                onClick={() => {
                  if (!cart.has(product.id)) {
                    cart.add(product.id);
                    setJustAdded(true);
                  }
                }}
                disabled={inSet}
                className="inline-flex items-center bg-[#1C1917] px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#F7F3EC] transition-colors hover:bg-[#3B342E] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1C1917] disabled:cursor-default disabled:opacity-60"
              >
                {inSet ? "In your discovery set" : "Add to Discovery Set (demo)"}
              </button>
            </div>
            <p aria-live="polite" className="mt-3 min-h-4 text-xs text-[#6B5B3E]">
              {(justAdded || inSet) && "Demo — no real submission. The discovery set lives only on this page."}
            </p>
          </div>
        </div>
      </div>
    </DialogContent>
  );
}

export function PerfumeCollection() {
  return (
    <section id="collection" className="scroll-mt-16 border-t border-[#1C1917]/10">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <div className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#B49B6C]">The Collection</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-light leading-tight text-[#1C1917] sm:text-5xl")}>
            Three hours, bottled.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#1C1917]/60">
            Each composition marks a moment of the day. Open a flacon to read its full architecture — top, heart and
            base — then keep what you like in the discovery set.
          </p>
        </div>

        <StaggerGroup className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PERFUME_PRODUCTS.map((product) => (
            <StaggerItem key={product.id}>
              <article className="flex h-full flex-col border border-[#1C1917]/10 bg-[#FDFBF6]">
                <Dialog>
                  <DialogTrigger asChild>
                    <button
                      type="button"
                      aria-label={`View ${product.reference} — ${product.name}`}
                      className="group relative block w-full text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B49B6C]"
                    >
                      <DemoImage
                        src={product.image}
                        alt=""
                        sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                        className="aspect-[3/4] w-full bg-gradient-to-br from-[#E7DBC4] via-[#D9C7A4] to-[#B49B6C]"
                        imgClassName="transition-transform duration-700 ease-out group-hover:scale-105"
                        fallbackLabel={product.name}
                      />
                      <span
                        aria-hidden="true"
                        className="pointer-events-none absolute inset-0 flex items-end justify-center bg-gradient-to-t from-[#1C1917]/50 via-transparent to-transparent p-6 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-within:opacity-100"
                      >
                        <span className="border border-white/70 px-5 py-2 text-[10px] uppercase tracking-[0.3em] text-white">
                          View
                        </span>
                      </span>
                    </button>
                  </DialogTrigger>
                  <ProductDialog product={product} />
                </Dialog>

                <div className="flex flex-1 flex-col p-5">
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="text-[10px] uppercase tracking-[0.28em] text-[#1C1917]/45">{product.family}</p>
                    <p className={cn(DISPLAY, "text-lg text-[#1C1917]")}>€{product.price}</p>
                  </div>
                  <h3 className={cn(DISPLAY, "mt-2 text-2xl font-medium leading-snug text-[#1C1917]")}>
                    {product.reference} — {product.name}
                  </h3>
                  <p className="mt-2 text-sm text-[#1C1917]/55">{keyNotes(product)}</p>
                </div>
              </article>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
