// ---------------------------------------------------------------------------
// Maison Élore — fictional fragrance house (concept demo data)
// ---------------------------------------------------------------------------

export type PerfumeProduct = {
  id: string;
  reference: string; // "Élore 07"
  name: string; // "Ambre Nocturne"
  family: string;
  price: number;
  image: string;
  description: string;
  top: string[];
  heart: string[];
  base: string[];
};

export const PERFUME_NOTES = ["Bergamot", "Iris", "Amber", "Cedar", "Vanilla", "Smoke"] as const;

export const PERFUME_PRODUCTS: PerfumeProduct[] = [
  {
    id: "elore-07",
    reference: "Élore 07",
    name: "Ambre Nocturne",
    family: "Amber · Smoky",
    price: 185,
    image: "/demo-assets/perfume/p1.jpg",
    description:
      "The house's after-dark signature: labdanum amber warmed over cedar embers, opened by a cold breath of bergamot. Worn like velvet in low light.",
    top: ["Bergamot", "Black Pepper"],
    heart: ["Amber", "Iris"],
    base: ["Cedar", "Smoke"],
  },
  {
    id: "elore-12",
    reference: "Élore 12",
    name: "Iris Vellum",
    family: "Floral · Powdery",
    price: 170,
    image: "/demo-assets/perfume/p2.jpg",
    description:
      "Orris butter pressed between the pages of an old book — powdery iris over soft vanilla musk, with neroli lifting the first hour.",
    top: ["Bergamot", "Neroli"],
    heart: ["Iris", "Violet"],
    base: ["Vanilla", "White Musk"],
  },
  {
    id: "elore-23",
    reference: "Élore 23",
    name: "Cèdre Sauvage",
    family: "Woody · Dry",
    price: 195,
    image: "/demo-assets/perfume/p3.jpg",
    description:
      "A forest at midnight: dry cedar and patchouli sharpened with elemi, finishing in sweet woodsmoke and warm amber resin.",
    top: ["Juniper", "Elemi"],
    heart: ["Cedar", "Patchouli"],
    base: ["Smoke", "Amber"],
  },
];

export function perfumeNotesOf(product: PerfumeProduct): string[] {
  return [...product.top, ...product.heart, ...product.base];
}

export function fragrancesWithNote(note: string): PerfumeProduct[] {
  return PERFUME_PRODUCTS.filter((p) => perfumeNotesOf(p).includes(note));
}
