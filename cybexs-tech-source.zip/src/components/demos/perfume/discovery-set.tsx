"use client";

import { useState } from "react";
import { Reveal } from "@/components/motion/reveal";
import { usePerfumeCart } from "./cart";
import { PERFUME_PRODUCTS } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-elore-display)]";

export function DiscoverySet() {
  const cart = usePerfumeCart();
  const [checkedOut, setCheckedOut] = useState(false);

  const items = cart.ids
    .map((id) => PERFUME_PRODUCTS.find((p) => p.id === id))
    .filter((p): p is (typeof PERFUME_PRODUCTS)[number] => Boolean(p));
  const total = items.reduce((sum, p) => sum + p.price, 0);

  return (
    <section id="discovery" className="scroll-mt-16 bg-[#1C1917] text-[#F7F3EC]">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#B49B6C]">The Discovery Set</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-light leading-tight sm:text-5xl")}>
            Try all three before you commit to one.
          </h2>
          <p className="mt-5 max-w-md text-base leading-relaxed text-[#F7F3EC]/65">
            A set of 2&nbsp;ml vials, presented in a paper case as quiet as the juice inside. In the fictional world of
            Maison Élore, its cost is credited against any full bottle.
          </p>
          <ul className="mt-7 space-y-2.5 text-sm text-[#F7F3EC]/70">
            <li className="flex gap-3"><span className="text-[#B49B6C]" aria-hidden="true">—</span>3 × 2 ml spray vials, one per composition</li>
            <li className="flex gap-3"><span className="text-[#B49B6C]" aria-hidden="true">—</span>Complimentary fictional shipping, in two to five imaginary days</li>
            <li className="flex gap-3"><span className="text-[#B49B6C]" aria-hidden="true">—</span>Set price credited against any full flacon</li>
          </ul>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="border border-white/10 bg-white/5 p-6 sm:p-8">
            <div className="flex items-baseline justify-between gap-4">
              <h3 className={cn(DISPLAY, "text-2xl")}>Your set</h3>
              <p className="text-xs uppercase tracking-[0.25em] text-[#F7F3EC]/50">
                {cart.count} {cart.count === 1 ? "item" : "items"}
              </p>
            </div>

            {items.length === 0 ? (
              <p className="mt-6 border border-dashed border-white/15 p-6 text-center text-sm text-[#F7F3EC]/50">
                Your set is empty — add a fragrance from the collection above.
              </p>
            ) : (
              <ul className="scrollbar-slim mt-6 max-h-56 space-y-3 overflow-y-auto pr-1">
                {items.map((product) => (
                  <li
                    key={product.id}
                    className="flex items-center justify-between gap-4 border-b border-white/10 pb-3 text-sm"
                  >
                    <div>
                      <p className="font-medium">{product.reference} — {product.name}</p>
                      <p className="mt-0.5 text-xs text-[#F7F3EC]/45">{product.family}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span>€{product.price}</span>
                      <button
                        type="button"
                        onClick={() => cart.remove(product.id)}
                        aria-label={`Remove ${product.reference} from the discovery set`}
                        className="text-xs uppercase tracking-[0.15em] text-[#F7F3EC]/40 underline underline-offset-4 transition-colors hover:text-[#F7F3EC]"
                      >
                        Remove
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            <div className="mt-6 flex items-baseline justify-between border-t border-white/10 pt-5">
              <span className="text-xs uppercase tracking-[0.25em] text-[#F7F3EC]/50">Total</span>
              <span className={cn(DISPLAY, "text-3xl")}>€{total}</span>
            </div>

            <button
              type="button"
              disabled={items.length === 0}
              onClick={() => setCheckedOut(true)}
              className="mt-6 w-full bg-[#B49B6C] py-4 text-xs font-semibold uppercase tracking-[0.25em] text-[#1C1917] transition-colors hover:bg-[#C9B183] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B49B6C] disabled:cursor-default disabled:opacity-40"
            >
              Checkout (demo)
            </button>

            <p aria-live="polite" className="mt-4 min-h-10 text-sm text-[#D8C29A]">
              {checkedOut && "Demo checkout — no real order is placed. Nothing was charged, because there is nothing to charge."}
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
