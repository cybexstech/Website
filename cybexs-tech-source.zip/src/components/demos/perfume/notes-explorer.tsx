"use client";

import { useState } from "react";
import { Reveal } from "@/components/motion/reveal";
import { PERFUME_NOTES, PERFUME_PRODUCTS, fragrancesWithNote, perfumeNotesOf } from "./data";
import { cn } from "@/lib/utils";

const DISPLAY = "font-[family-name:var(--font-elore-display)]";

export function NotesExplorer() {
  const [activeNote, setActiveNote] = useState<string | null>(null);

  const matches = activeNote ? fragrancesWithNote(activeNote) : [];

  return (
    <section id="notes" className="scroll-mt-16 border-t border-[#1C1917]/10 bg-[#F2EBDD]">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-[#B49B6C]">Notes explorer</p>
          <h2 className={cn(DISPLAY, "mt-4 text-4xl font-light leading-tight text-[#1C1917] sm:text-5xl")}>
            Follow one thread.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#1C1917]/60">
            Every fragrance is built from the same small palette. Pick a note and watch the collection rearrange itself
            around it.
          </p>
        </Reveal>

        <div className="mt-10 flex flex-wrap gap-2.5" role="group" aria-label="Filter fragrances by note">
          {PERFUME_NOTES.map((note) => {
            const isActive = activeNote === note;
            return (
              <button
                key={note}
                type="button"
                aria-pressed={isActive}
                onClick={() => setActiveNote(isActive ? null : note)}
                className={cn(
                  "rounded-full border px-5 py-2.5 text-xs font-medium uppercase tracking-[0.18em] transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B49B6C]",
                  isActive
                    ? "border-[#B49B6C] bg-[#B49B6C] text-white shadow-[0_10px_24px_-12px_rgba(180,155,108,0.8)]"
                    : "border-[#1C1917]/20 bg-white/60 text-[#1C1917]/70 hover:border-[#B49B6C] hover:text-[#1C1917]",
                )}
              >
                {note}
              </button>
            );
          })}
          {activeNote && (
            <button
              type="button"
              onClick={() => setActiveNote(null)}
              className="px-3 py-2.5 text-xs uppercase tracking-[0.18em] text-[#1C1917]/45 underline underline-offset-4 transition-colors hover:text-[#1C1917]"
            >
              Clear
            </button>
          )}
        </div>

        <p aria-live="polite" className="mt-4 min-h-5 text-sm italic text-[#1C1917]/55">
          {activeNote
            ? `${activeNote} appears in ${matches.length} of ${PERFUME_PRODUCTS.length} compositions.`
            : "Select a note to see which compositions carry it."}
        </p>

        <Reveal className="mt-6">
          <ul className="space-y-3">
            {PERFUME_PRODUCTS.map((product) => {
              const notes = perfumeNotesOf(product);
              const contains = activeNote !== null && notes.includes(activeNote);
              const dimmed = activeNote !== null && !contains;
              return (
                <li
                  key={product.id}
                  className={cn(
                    "flex flex-col gap-4 border p-5 transition-all duration-300 sm:flex-row sm:items-center sm:justify-between sm:p-6",
                    contains
                      ? "border-[#B49B6C] bg-white shadow-[0_18px_40px_-28px_rgba(180,155,108,0.9)]"
                      : "border-[#1C1917]/12 bg-white/50",
                    dimmed && "opacity-40",
                  )}
                >
                  <div>
                    <h3 className={cn(DISPLAY, "text-xl font-medium text-[#1C1917] sm:text-2xl")}>
                      {product.reference} — {product.name}
                    </h3>
                    <p className="mt-1 text-[10px] uppercase tracking-[0.28em] text-[#1C1917]/45">{product.family}</p>
                  </div>
                  <div className="flex flex-wrap gap-1.5" aria-hidden="true">
                    {notes.map((note) => (
                      <span
                        key={note}
                        className={cn(
                          "rounded-full border px-2.5 py-1 text-[10px] uppercase tracking-[0.15em] transition-colors",
                          activeNote === note
                            ? "border-[#B49B6C] bg-[#B49B6C]/20 font-semibold text-[#1C1917]"
                            : "border-[#1C1917]/15 text-[#1C1917]/55",
                        )}
                      >
                        {note}
                      </span>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
