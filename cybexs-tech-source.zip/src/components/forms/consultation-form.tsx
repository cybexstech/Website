"use client";

import { useEffect, useRef, useState } from "react";
import { useForm, Controller, type FieldPath } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowRight, CalendarCheck, Check, Loader2, Mail } from "lucide-react";
import { useReducedMotion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { consultationLeadSchema, SERVICE_INTEREST_VALUES } from "@/lib/validations";
import { trackEvent } from "@/lib/analytics";
import { siteConfig } from "@/lib/site";

/** Read at module level — NEXT_PUBLIC_ vars are inlined at build time. */
const CALCOM_BOOKING_URL = process.env.NEXT_PUBLIC_CALCOM_BOOKING_URL;
const CALCOM_EMBED_SRC = CALCOM_BOOKING_URL
  ? `${CALCOM_BOOKING_URL}${CALCOM_BOOKING_URL.includes("?") ? "&" : "?"}embed=true`
  : null;

/**
 * Consultation form. Client-side validation mirrors the server schema
 * (consultationLeadSchema) with a friendlier message on the service selector.
 */
const consultationFormSchema = z.object({
  fullName: consultationLeadSchema.shape.fullName,
  email: consultationLeadSchema.shape.email,
  companyName: consultationLeadSchema.shape.companyName,
  companyWebsite: consultationLeadSchema.shape.companyWebsite,
  serviceInterest: z.enum(SERVICE_INTEREST_VALUES, {
    message: "Please select what you're interested in — or pick 'Not sure yet'.",
  }),
});

type ConsultationFormInput = z.input<typeof consultationFormSchema>;
type ConsultationFormOutput = z.output<typeof consultationFormSchema>;

type ConsultationApiResponse = {
  ok: boolean;
  leadId?: string;
  existing?: boolean;
  error?: string;
  fieldErrors?: Record<string, string>;
};

export function ConsultationForm() {
  const [step, setStep] = useState<1 | 2>(1);
  const [existing, setExisting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [showNextInfo, setShowNextInfo] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  const {
    register,
    handleSubmit,
    control,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<ConsultationFormInput, unknown, ConsultationFormOutput>({
    resolver: zodResolver(consultationFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      companyName: "",
      companyWebsite: "",
      serviceInterest: undefined,
    },
  });

  useEffect(() => {
    if (step === 2) {
      trackEvent("scheduling_opened", { method: CALCOM_EMBED_SRC ? "calcom" : "manual" });
      panelRef.current?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
    }
  }, [step, reduce]);

  async function onSubmit(values: ConsultationFormOutput) {
    setServerError(null);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      let data: ConsultationApiResponse | null = null;
      try {
        data = (await res.json()) as ConsultationApiResponse;
      } catch {
        data = null;
      }

      if (res.ok && data?.ok) {
        trackEvent("consultation_form_submitted", { existing: data.existing === true });
        setExisting(data.existing === true);
        setStep(2);
        return;
      }

      if (data?.fieldErrors) {
        let applied = false;
        for (const [field, message] of Object.entries(data.fieldErrors)) {
          if (field in consultationFormSchema.shape) {
            setError(field as FieldPath<ConsultationFormInput>, { type: "server", message });
            applied = true;
          }
        }
        if (applied) return;
      }

      setServerError(
        data?.error ?? "We could not save your request. Please try again, or email us directly."
      );
    } catch {
      setServerError(
        "A network error occurred. Please check your connection and try again, or email us directly."
      );
    }
  }

  return (
    <div ref={panelRef} className="scroll-mt-28">
      {/* Step indicator */}
      <ol className="flex items-center gap-4" aria-label="Booking progress">
        <li aria-current={step === 1 ? "step" : undefined} className="flex items-center gap-2.5">
          <span
            className={`flex h-7 w-7 items-center justify-center rounded-full border text-xs font-semibold ${
              step >= 1 ? "border-[var(--ink)] bg-[var(--ink)] text-white" : "border-neutral-300 text-neutral-500"
            }`}
            aria-hidden="true"
          >
            {step > 1 ? <Check className="h-3.5 w-3.5" /> : "1"}
          </span>
          <span
            className={`text-sm font-semibold ${step >= 1 ? "text-[var(--ink)]" : "text-neutral-500"}`}
          >
            Details
          </span>
        </li>
        <span className="h-px w-8 bg-neutral-300" aria-hidden="true" />
        <li aria-current={step === 2 ? "step" : undefined} className="flex items-center gap-2.5">
          <span
            className={`flex h-7 w-7 items-center justify-center rounded-full border text-xs font-semibold ${
              step >= 2 ? "border-[var(--ink)] bg-[var(--ink)] text-white" : "border-neutral-300 text-neutral-500"
            }`}
            aria-hidden="true"
          >
            2
          </span>
          <span
            className={`text-sm font-semibold ${step >= 2 ? "text-[var(--ink)]" : "text-neutral-500"}`}
          >
            Schedule
          </span>
        </li>
      </ol>

      {/* Step 1 — details */}
      <div className={step === 1 ? "mt-8" : "hidden"} aria-hidden={step !== 1}>
        <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
          {serverError && (
            <div
              role="alert"
              className="flex flex-wrap items-center justify-between gap-3 border border-destructive/30 bg-destructive/5 px-4 py-3"
            >
              <p className="text-sm text-destructive">{serverError}</p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleSubmit(onSubmit)()}
              >
                Try again
              </Button>
            </div>
          )}

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="book-fullName">Full name</Label>
              <Input
                id="book-fullName"
                autoComplete="name"
                placeholder="Jane Doe"
                aria-invalid={!!errors.fullName}
                aria-describedby={errors.fullName ? "book-fullName-error" : undefined}
                {...register("fullName")}
              />
              {errors.fullName && (
                <p id="book-fullName-error" role="alert" className="text-sm text-destructive">
                  {errors.fullName.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="book-email">Work email</Label>
              <Input
                id="book-email"
                type="email"
                autoComplete="email"
                placeholder="jane@company.com"
                aria-invalid={!!errors.email}
                aria-describedby={errors.email ? "book-email-error" : undefined}
                {...register("email")}
              />
              {errors.email && (
                <p id="book-email-error" role="alert" className="text-sm text-destructive">
                  {errors.email.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="book-companyName">Company name</Label>
              <Input
                id="book-companyName"
                autoComplete="organization"
                placeholder="Company Ltd."
                aria-invalid={!!errors.companyName}
                aria-describedby={errors.companyName ? "book-companyName-error" : undefined}
                {...register("companyName")}
              />
              {errors.companyName && (
                <p id="book-companyName-error" role="alert" className="text-sm text-destructive">
                  {errors.companyName.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="book-companyWebsite">
                Company website <span className="font-normal text-neutral-400">(optional)</span>
              </Label>
              <Input
                id="book-companyWebsite"
                type="text"
                inputMode="url"
                autoComplete="url"
                placeholder="company.com"
                aria-invalid={!!errors.companyWebsite}
                aria-describedby={errors.companyWebsite ? "book-companyWebsite-error" : undefined}
                {...register("companyWebsite")}
              />
              {errors.companyWebsite && (
                <p id="book-companyWebsite-error" role="alert" className="text-sm text-destructive">
                  {errors.companyWebsite.message}
                </p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="book-serviceInterest">What would you like to improve?</Label>
            <Controller
              control={control}
              name="serviceInterest"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger
                    id="book-serviceInterest"
                    aria-invalid={!!errors.serviceInterest}
                    aria-describedby={errors.serviceInterest ? "book-serviceInterest-error" : undefined}
                    className="w-full"
                  >
                    <SelectValue placeholder="Select a service — or 'Not sure yet'" />
                  </SelectTrigger>
                  <SelectContent>
                    {SERVICE_INTEREST_VALUES.map((value) => (
                      <SelectItem key={value} value={value}>
                        {value}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
            {errors.serviceInterest && (
              <p id="book-serviceInterest-error" role="alert" className="text-sm text-destructive">
                {errors.serviceInterest.message}
              </p>
            )}
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="h-12 w-full rounded-full text-sm font-semibold sm:w-auto sm:px-10"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                Saving…
              </>
            ) : (
              <>
                Continue to scheduling
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </>
            )}
          </Button>
          <p className="text-xs leading-relaxed text-neutral-500">
            Free, 30 minutes, no obligation. We use your details only to prepare for and follow up on the
            consultation.
          </p>
        </form>
      </div>

      {/* Step 2 — scheduling */}
      {step === 2 && (
        <div className="mt-8">
          {existing && (
            <p className="mb-6 border-l-2 border-[var(--coral)] pl-4 text-sm font-medium text-neutral-700">
              We already have your request — pick a time below.
            </p>
          )}

          {CALCOM_EMBED_SRC ? (
            <div>
              <h2 className="font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
                Pick a time
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-neutral-600">
                Choose any open slot that suits you. The calendar shows availability in your local time zone.
              </p>
              <iframe
                src={CALCOM_EMBED_SRC}
                style={{ width: "100%", height: 720, border: 0 }}
                title="Schedule your consultation"
                loading="lazy"
                className="mt-6"
              />
              <p className="mt-4 text-xs leading-relaxed text-neutral-500">
                Your appointment is confirmed only when the scheduling provider confirms it.
              </p>

              {!showNextInfo ? (
                <Button
                  type="button"
                  onClick={() => {
                    trackEvent("booking_confirmed");
                    setShowNextInfo(true);
                  }}
                  className="mt-6 h-12 rounded-full px-8 text-sm font-semibold"
                >
                  I&rsquo;ve booked — what&rsquo;s next?
                </Button>
              ) : (
                <div role="status" className="mt-6 border border-neutral-200 bg-[#FAFAF8] p-6">
                  <p className="flex items-center gap-2 text-sm font-semibold text-[var(--ink)]">
                    <Check className="h-4 w-4 text-[var(--coral)]" aria-hidden="true" />
                    You&rsquo;re set. Here&rsquo;s what happens next:
                  </p>
                  <ul className="mt-4 space-y-2.5 text-sm leading-relaxed text-neutral-600">
                    <li>A confirmation from the scheduling provider lands in your inbox.</li>
                    <li>
                      We follow up within one business day with a short agenda so the 30 minutes is spent on
                      your situation, not on introductions.
                    </li>
                    <li>
                      Need to reschedule? Use the link in the confirmation email or write to{" "}
                      <a
                        href={`mailto:${siteConfig.contactEmail}`}
                        className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
                      >
                        {siteConfig.contactEmail}
                      </a>
                      .
                    </li>
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="border border-neutral-200 bg-[#FAFAF8] p-8 sm:p-10" role="status">
              <p className="flex h-11 w-11 items-center justify-center border border-neutral-300 bg-white">
                <CalendarCheck className="h-5 w-5 text-[var(--ink)]" aria-hidden="true" />
              </p>
              <h2 className="mt-6 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
                Online scheduling is being connected
              </h2>
              <p className="mt-3 max-w-lg text-base leading-relaxed text-neutral-600">
                We&rsquo;re finishing the connection to our online scheduling provider. In the meantime, our
                team schedules consultations directly — at a time that suits you.
              </p>
              <a href={`mailto:${siteConfig.contactEmail}`} className="btn-dark mt-8">
                <Mail className="h-4 w-4" aria-hidden="true" />
                Email us instead: {siteConfig.contactEmail}
              </a>
              <p className="mt-6 border-l-2 border-[var(--coral)] pl-4 text-sm leading-relaxed text-neutral-700">
                Your request is already saved — our team will reach out to schedule directly.
              </p>
            </div>
          )}

          <Button
            type="button"
            variant="ghost"
            onClick={() => setStep(1)}
            className="mt-8 text-sm font-semibold text-neutral-600 hover:text-[var(--ink)]"
          >
            Back to details
          </Button>
        </div>
      )}
    </div>
  );
}
