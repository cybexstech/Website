"use client";

import { useState } from "react";
import { useForm, Controller, type FieldPath } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowRight, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { contactLeadSchema, SERVICE_INTEREST_VALUES } from "@/lib/validations";
import { trackEvent } from "@/lib/analytics";
import { siteConfig } from "@/lib/site";

/**
 * Contact form. Client-side validation mirrors the server schema
 * (contactLeadSchema) with a friendlier message on the service selector.
 */
const contactFormSchema = z.object({
  fullName: contactLeadSchema.shape.fullName,
  email: contactLeadSchema.shape.email,
  companyName: contactLeadSchema.shape.companyName,
  companyWebsite: contactLeadSchema.shape.companyWebsite,
  serviceInterest: z.enum(SERVICE_INTEREST_VALUES, {
    message: "Please select the service you're interested in.",
  }),
  message: contactLeadSchema.shape.message,
});

type ContactFormInput = z.input<typeof contactFormSchema>;
type ContactFormOutput = z.output<typeof contactFormSchema>;

type ContactApiResponse = {
  ok: boolean;
  leadId?: string;
  error?: string;
  fieldErrors?: Record<string, string>;
};

export function ContactForm() {
  const [serverError, setServerError] = useState<string | null>(null);
  const [successLeadId, setSuccessLeadId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    control,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<ContactFormInput, unknown, ContactFormOutput>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      companyName: "",
      companyWebsite: "",
      message: "",
      serviceInterest: undefined,
    },
  });

  async function onSubmit(values: ContactFormOutput) {
    setServerError(null);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      let data: ContactApiResponse | null = null;
      try {
        data = (await res.json()) as ContactApiResponse;
      } catch {
        data = null;
      }

      if (res.ok && data?.ok && data.leadId) {
        trackEvent("contact_form_submitted", { source: "contact_page" });
        setSuccessLeadId(data.leadId);
        return;
      }

      if (data?.fieldErrors) {
        let applied = false;
        for (const [field, message] of Object.entries(data.fieldErrors)) {
          if (field in contactFormSchema.shape) {
            setError(field as FieldPath<ContactFormInput>, { type: "server", message });
            applied = true;
          }
        }
        if (applied) return;
      }

      setServerError(
        data?.error ?? "We could not send your message. Please try again, or email us directly."
      );
    } catch {
      setServerError(
        "A network error occurred. Please check your connection and try again, or email us directly."
      );
    }
  }

  if (successLeadId) {
    return (
      <div className="border border-neutral-200 bg-white p-8 sm:p-10" role="status">
        <p className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--coral)]/10">
          <Check className="h-5 w-5 text-[var(--coral)]" aria-hidden="true" />
        </p>
        <h3 className="mt-6 font-display text-2xl font-semibold tracking-tight text-[var(--ink)]">
          Thank you — we received your inquiry.
        </h3>
        <p className="mt-3 text-base leading-relaxed text-neutral-600">
          We reply within one business day.
        </p>
        <p className="mt-6 text-sm text-neutral-500">
          Reference: <span className="font-mono text-[var(--ink)]">{successLeadId}</span>
        </p>
        <p className="mt-6 text-sm leading-relaxed text-neutral-500">
          Anything urgent in the meantime? Email{" "}
          <a
            href={`mailto:${siteConfig.contactEmail}`}
            className="font-semibold text-[var(--ink)] underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
          >
            {siteConfig.contactEmail}
          </a>
          .
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      {serverError && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 border border-destructive/30 bg-destructive/5 px-4 py-3"
        >
          <p className="text-sm text-destructive">{serverError}</p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => handleSubmit(onSubmit)()}
          >
            Try again
          </Button>
        </div>
      )}

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="contact-fullName">Full name</Label>
          <Input
            id="contact-fullName"
            autoComplete="name"
            placeholder="Jane Doe"
            aria-invalid={!!errors.fullName}
            aria-describedby={errors.fullName ? "contact-fullName-error" : undefined}
            {...register("fullName")}
          />
          {errors.fullName && (
            <p id="contact-fullName-error" role="alert" className="text-sm text-destructive">
              {errors.fullName.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="contact-email">Work email</Label>
          <Input
            id="contact-email"
            type="email"
            autoComplete="email"
            placeholder="jane@company.com"
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? "contact-email-error" : undefined}
            {...register("email")}
          />
          {errors.email && (
            <p id="contact-email-error" role="alert" className="text-sm text-destructive">
              {errors.email.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="contact-companyName">Company name</Label>
          <Input
            id="contact-companyName"
            autoComplete="organization"
            placeholder="Company Ltd."
            aria-invalid={!!errors.companyName}
            aria-describedby={errors.companyName ? "contact-companyName-error" : undefined}
            {...register("companyName")}
          />
          {errors.companyName && (
            <p id="contact-companyName-error" role="alert" className="text-sm text-destructive">
              {errors.companyName.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="contact-companyWebsite">
            Company website <span className="font-normal text-neutral-400">(optional)</span>
          </Label>
          <Input
            id="contact-companyWebsite"
            type="text"
            inputMode="url"
            autoComplete="url"
            placeholder="company.com"
            aria-invalid={!!errors.companyWebsite}
            aria-describedby={errors.companyWebsite ? "contact-companyWebsite-error" : undefined}
            {...register("companyWebsite")}
          />
          {errors.companyWebsite && (
            <p id="contact-companyWebsite-error" role="alert" className="text-sm text-destructive">
              {errors.companyWebsite.message}
            </p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="contact-serviceInterest">What are you interested in?</Label>
        <Controller
          control={control}
          name="serviceInterest"
          render={({ field }) => (
            <Select value={field.value} onValueChange={field.onChange}>
              <SelectTrigger
                id="contact-serviceInterest"
                aria-invalid={!!errors.serviceInterest}
                aria-describedby={errors.serviceInterest ? "contact-serviceInterest-error" : undefined}
                className="w-full"
              >
                <SelectValue placeholder="Select a service" />
              </SelectTrigger>
              <SelectContent>
                {SERVICE_INTEREST_VALUES.map((value) => (
                  <SelectItem key={value} value={value}>
                    {value}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        />
        {errors.serviceInterest && (
          <p id="contact-serviceInterest-error" role="alert" className="text-sm text-destructive">
            {errors.serviceInterest.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="contact-message">How can we help?</Label>
        <Textarea
          id="contact-message"
          rows={6}
          placeholder="Briefly describe what's slowing you down — processes, tools, goals. The more context, the better our first reply."
          aria-invalid={!!errors.message}
          aria-describedby={errors.message ? "contact-message-error" : undefined}
          {...register("message")}
        />
        {errors.message && (
          <p id="contact-message-error" role="alert" className="text-sm text-destructive">
            {errors.message.message}
          </p>
        )}
      </div>

      <Button
        type="submit"
        disabled={isSubmitting}
        className="h-12 w-full rounded-full text-sm font-semibold sm:w-auto sm:px-10"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            Sending…
          </>
        ) : (
          <>
            Send message
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </>
        )}
      </Button>
    </form>
  );
}
