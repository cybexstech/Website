"use client";

import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Infinite marquee row. Duplicate children for a seamless loop;
 * pauses on hover, disabled with reduced motion.
 */
export function Marquee({
  children,
  className,
  speed = 30,
  reverse = false,
}: {
  children: React.ReactNode;
  className?: string;
  speed?: number; // seconds per loop
  reverse?: boolean;
}) {
  const reduce = useReducedMotion();
  if (reduce) {
    return <div className={cn("overflow-hidden", className)}>{children}</div>;
  }
  return (
    <div className={cn("group relative overflow-hidden", className)}>
      <motion.div
        className="flex w-max items-center gap-0"
        animate={{ x: reverse ? ["-50%", "0%"] : ["0%", "-50%"] }}
        transition={{ duration: speed, ease: "linear", repeat: Infinity }}
      >
        <div className="flex min-w-max items-center">{children}</div>
        <div className="flex min-w-max items-center" aria-hidden="true">
          {children}
        </div>
      </motion.div>
    </div>
  );
}
