"use client";

// Client component: it attaches an onClick handler via trackEventClient(), which
// can only be invoked from client code (calling it during server render throws).
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { trackEventClient } from "@/components/site/track-client";

/** Final conversion section — "Book Free Consultation". */
export function CtaSection({
  title = "Ready to remove the busywork?",
  description = "Book a free consultation. We'll look at your current processes and tools, and show you the two or three improvements with the best effort-to-impact ratio — no obligation.",
}: {
  title?: string;
  description?: string;
}) {
  return (
    <section className="noise-overlay relative overflow-hidden bg-[var(--ink)] text-white">
      <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
      <div
        className="absolute -right-32 -top-32 h-96 w-96 rounded-full opacity-20 blur-[120px]"
        style={{ background: "radial-gradient(circle, #FF3B30 0%, transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="container-site section relative">
        <Reveal className="max-w-3xl">
          <p className="eyebrow !text-neutral-400">Free consultation</p>
          <h2 className="display-2 mt-4">{title}</h2>
          <p className="lede mt-5 !text-neutral-400">{description}</p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <Link
              href="/book"
              onClick={trackEventClient("consultation_cta_clicked", { location: "cta_section" })}
              className="btn-accent"
            >
              Book Free Consultation
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/services" className="btn-outline-light">
              Explore services
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
