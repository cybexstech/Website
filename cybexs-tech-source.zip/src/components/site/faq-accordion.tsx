"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export type FaqItem = { question: string; answer: string };

export function FaqAccordion({ items, className }: { items: FaqItem[]; className?: string }) {
  return (
    <Accordion type="single" collapsible className={className}>
      {items.map((item, i) => (
        <AccordionItem key={i} value={`item-${i}`} className="border-neutral-200">
          <AccordionTrigger className="text-left text-base font-semibold text-[var(--ink)] hover:no-underline hover:text-[var(--coral)] sm:text-lg">
            {item.question}
          </AccordionTrigger>
          <AccordionContent className="text-base leading-relaxed text-neutral-600">
            {item.answer}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
