import Link from "next/link";
import { Logo } from "@/components/site/logo";
import { SERVICES } from "@/data/services";
import { INDUSTRIES } from "@/data/industries";
import { siteConfig } from "@/lib/site";

const RESOURCES = [
  { href: "/work", label: "Selected Work" },
  { href: "/insights", label: "Insights" },
  { href: "/faqs", label: "FAQs" },
  { href: "/book", label: "Book Free Consultation" },
];

const COMPANY = [
  { href: "/about", label: "About Us" },
  { href: "/contact", label: "Contact" },
  { href: "/privacy", label: "Privacy Policy" },
  { href: "/terms", label: "Terms of Service" },
];

export function SiteFooter() {
  return (
    <footer className="mt-auto bg-[var(--ink)] text-neutral-300">
      <div className="container-site py-16 sm:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div>
            <Link href="/" aria-label="Cybexs Tech home">
              <Logo variant="white" />
            </Link>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-neutral-400">
              Practical AI automation, technical solutions and human-powered business services — helping companies
              streamline operations, improve sales processes and build better digital experiences.
            </p>
            <a
              href={`mailto:${siteConfig.contactEmail}`}
              className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-white underline decoration-[var(--coral)] decoration-2 underline-offset-4 hover:text-[var(--coral)]"
            >
              {siteConfig.contactEmail}
            </a>
            {siteConfig.linkedinUrl && (
              <a
                href={siteConfig.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 block text-sm font-semibold text-white hover:text-[var(--coral)]"
              >
                LinkedIn ↗
              </a>
            )}
          </div>

          <nav aria-label="Services">
            <h2 className="text-xs font-semibold uppercase tracking-[0.2em] text-neutral-500">Services</h2>
            <ul className="mt-5 space-y-2.5">
              {SERVICES.map((s) => (
                <li key={s.slug}>
                  <Link href={`/services/${s.slug}`} className="text-sm text-neutral-400 transition-colors hover:text-white">
                    {s.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Industries">
            <h2 className="text-xs font-semibold uppercase tracking-[0.2em] text-neutral-500">Industries</h2>
            <ul className="mt-5 space-y-2.5">
              {INDUSTRIES.slice(0, 6).map((i) => (
                <li key={i.slug}>
                  <Link href={`/industries/${i.slug}`} className="text-sm text-neutral-400 transition-colors hover:text-white">
                    {i.name}
                  </Link>
                </li>
              ))}
              <li>
                <Link href="/industries" className="text-sm font-semibold text-white transition-colors hover:text-[var(--coral)]">
                  All industries →
                </Link>
              </li>
            </ul>
          </nav>

          <nav aria-label="Company">
            <h2 className="text-xs font-semibold uppercase tracking-[0.2em] text-neutral-500">Company</h2>
            <ul className="mt-5 space-y-2.5">
              {COMPANY.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-neutral-400 transition-colors hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
            <h2 className="mt-8 text-xs font-semibold uppercase tracking-[0.2em] text-neutral-500">Resources</h2>
            <ul className="mt-5 space-y-2.5">
              {RESOURCES.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-neutral-400 transition-colors hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-white/10 pt-8 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-neutral-500">
            © {new Date().getFullYear()} {siteConfig.legalName}. All rights reserved.
          </p>
          <p className="text-xs text-neutral-500">
            Portfolio projects are concept demonstrations with fictional brands — never presented as clients.
          </p>
        </div>
      </div>
    </footer>
  );
}
