"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { HeroEntrance } from "@/components/motion/reveal";
import { Marquee } from "@/components/motion/marquee";
import { SERVICES } from "@/data/services";
import { trackEventClient } from "@/components/site/track-client";

/**
 * Cinematic full-viewport homepage hero.
 * Dark ink surface, faint grid, one coral glow, choreographed entrance,
 * service marquee along the bottom edge.
 */
export function HomeHero() {
  const reduce = useReducedMotion();

  return (
    <section
      className="noise-overlay relative flex min-h-svh flex-col overflow-hidden bg-[var(--ink)] text-white"
      aria-label="Introduction"
    >
      {/* Backdrop: grid + single coral glow */}
      <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
      <div
        className="absolute -top-48 right-[-12%] h-[520px] w-[520px] rounded-full opacity-25 blur-[140px]"
        style={{ background: "radial-gradient(circle, #FF3B30 0%, transparent 70%)" }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-[-10%] left-[-15%] h-[380px] w-[380px] rounded-full opacity-10 blur-[120px]"
        style={{ background: "radial-gradient(circle, #FF3B30 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      {/* Copy */}
      <div className="container-site relative flex flex-1 flex-col justify-center pb-14 pt-36 sm:pt-40">
        <HeroEntrance>
          <p className="eyebrow !text-neutral-400">AI Automation · Business Services · Digital Experiences</p>
        </HeroEntrance>

        <HeroEntrance delay={0.12} className="mt-7">
          <h1 className="display-1 max-w-5xl">
            <span className="block">
              Automate the <span className="text-stroke">busywork.</span>
            </span>
            <span className="block">Grow the business.</span>
            <span className="block">Delight the customer.</span>
          </h1>
        </HeroEntrance>

        <HeroEntrance delay={0.24}>
          <p className="lede mt-7 max-w-2xl !text-neutral-400">
            Cybexs Tech helps businesses streamline operations, improve sales processes and build better
            digital experiences — through practical AI automation, technical solutions and human-powered
            services.
          </p>
        </HeroEntrance>

        <HeroEntrance delay={0.36}>
          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Link
              href="/book"
              onClick={trackEventClient("consultation_cta_clicked", { location: "home_hero" })}
              className="btn-accent"
            >
              Book Free Consultation
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
            <Link href="/services" className="btn-outline-light">
              Explore services
            </Link>
          </div>
        </HeroEntrance>

        {/* Scroll indicator */}
        <HeroEntrance delay={0.55} className="mt-16 hidden sm:block">
          <div className="flex items-center gap-4" aria-hidden="true">
            <motion.span
              className="text-[11px] font-medium uppercase tracking-[0.3em] text-neutral-500"
              animate={reduce ? undefined : { opacity: [0.45, 1, 0.45] }}
              transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
            >
              Scroll to explore
            </motion.span>
            <span className="relative h-px w-16 overflow-hidden bg-white/15">
              <motion.span
                className="absolute inset-y-0 left-0 w-8 bg-[var(--coral)]"
                animate={reduce ? undefined : { x: [-32, 64] }}
                transition={{ duration: 1.9, repeat: Infinity, ease: "easeInOut" }}
              />
            </span>
          </div>
        </HeroEntrance>
      </div>

      {/* Service marquee */}
      <div className="relative border-t border-white/10">
        <Marquee speed={38} className="py-5">
          <div className="flex items-center">
            {SERVICES.map((service) => (
              <span key={service.slug} className="flex items-center">
                <span className="px-7 text-sm font-medium tracking-wide text-neutral-500">{service.name}</span>
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--coral)] opacity-80" aria-hidden="true" />
              </span>
            ))}
          </div>
        </Marquee>
      </div>
    </section>
  );
}
