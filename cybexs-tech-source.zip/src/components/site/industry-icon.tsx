import {
  Building2,
  Factory,
  Rocket,
  ShoppingCart,
  Stethoscope,
  Target,
  Users,
  Wrench,
  type LucideIcon,
} from "lucide-react";

/** Maps the lucide icon keys used in src/data/industries.ts. */
const ICONS: Record<string, LucideIcon> = {
  Building2,
  Rocket,
  Factory,
  Stethoscope,
  ShoppingCart,
  Users,
  Wrench,
  Target,
};

export function IndustryIcon({ icon, className }: { icon: string; className?: string }) {
  const Icon = ICONS[icon] ?? Building2;
  return <Icon className={className} aria-hidden="true" />;
}
