import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { Reveal } from "@/components/motion/reveal";

/** Minimal shape both pages pass around (matches the Prisma Article columns used). */
export type InsightTeaser = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  readMinutes: number;
  publishedAt: Date | null;
};

export function formatInsightDate(date: Date | null): string | null {
  return date ? format(date, "MMMM d, yyyy") : null;
}

export function CategoryPill({ category, className = "" }: { category: string; className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-neutral-200 bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-neutral-600 ${className}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-[var(--coral)]" aria-hidden="true" />
      {category}
    </span>
  );
}

function MetaRow({ article, dark = false }: { article: InsightTeaser; dark?: boolean }) {
  const date = formatInsightDate(article.publishedAt);
  return (
    <div className={`flex flex-wrap items-center gap-x-2 gap-y-1 text-sm ${dark ? "text-neutral-400" : "text-neutral-500"}`}>
      {date && (
        <time dateTime={article.publishedAt?.toISOString()} className="font-medium">
          {date}
        </time>
      )}
      {date && <span aria-hidden="true">·</span>}
      <span>{article.category}</span>
      <span aria-hidden="true">·</span>
      <span>{article.readMinutes} min read</span>
    </div>
  );
}

/** Large editorial card — used for the most recent article on /insights and related reading. */
export function InsightCard({ article, priority = false }: { article: InsightTeaser; priority?: boolean }) {
  return (
    <article
      className={`card-hover group relative flex h-full flex-col rounded-3xl border border-neutral-200 bg-white p-8 sm:p-10 ${
        priority ? "shadow-[0_24px_70px_-40px_rgba(10,10,10,0.35)]" : ""
      }`}
    >
      <CategoryPill category={article.category} />
      <h3
        className={`mt-5 font-display font-semibold tracking-[-0.02em] text-[var(--ink)] ${
          priority ? "text-3xl leading-[1.08] sm:text-4xl" : "text-xl leading-snug sm:text-2xl"
        }`}
      >
        <Link
          href={`/insights/${article.slug}`}
          className="transition-colors after:absolute after:inset-0 after:rounded-3xl after:content-[''] hover:text-[var(--coral)]"
        >
          {article.title}
        </Link>
      </h3>
      <p className={`mt-4 text-neutral-600 ${priority ? "text-lg leading-relaxed" : "leading-relaxed"}`}>
        {article.excerpt}
      </p>
      <div className="mt-6 flex items-center justify-between gap-4 pt-2">
        <MetaRow article={article} />
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-neutral-200 text-[var(--ink)] transition-all group-hover:border-[var(--coral)] group-hover:bg-[var(--coral)] group-hover:text-white">
          <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </span>
      </div>
    </article>
  );
}

/** Compact list row — used for all articles after the featured one. */
export function InsightRow({ article, index = 0 }: { article: InsightTeaser; index?: number }) {
  const date = formatInsightDate(article.publishedAt);
  return (
    <li>
      <Reveal delay={Math.min(index * 0.04, 0.3)}>
        <Link
          href={`/insights/${article.slug}`}
          className="group grid items-start gap-3 py-8 transition-colors sm:grid-cols-[190px_1fr_44px] sm:gap-8"
        >
          <div className="text-sm text-neutral-500">
            {date && (
              <time dateTime={article.publishedAt?.toISOString()} className="font-medium">
                {date}
              </time>
            )}
            <p className="mt-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-neutral-400">
              {article.category}
            </p>
          </div>
          <div>
            <h3 className="font-display text-xl font-semibold tracking-[-0.01em] text-[var(--ink)] transition-colors group-hover:text-[var(--coral)] sm:text-2xl">
              {article.title}
            </h3>
            <p className="mt-2 line-clamp-2 leading-relaxed text-neutral-600">{article.excerpt}</p>
            <p className="mt-3 text-sm text-neutral-500">{article.readMinutes} min read</p>
          </div>
          <span className="hidden h-10 w-10 items-center justify-center rounded-full border border-neutral-200 text-[var(--ink)] transition-all group-hover:border-[var(--coral)] group-hover:bg-[var(--coral)] group-hover:text-white sm:flex">
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </span>
        </Link>
      </Reveal>
    </li>
  );
}
