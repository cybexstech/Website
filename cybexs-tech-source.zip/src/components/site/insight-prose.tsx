import ReactMarkdown, { type Components } from "react-markdown";
import Link from "next/link";

/**
 * Editorial typography for article markdown, styled manually (no typography
 * plugin). Only the markdown subset used by our editorial team is mapped:
 * paragraphs, ## / ### headings, lists, bold, links, blockquotes, dividers.
 */
const components: Components = {
  a({ href, children }) {
    const url = href ?? "#";
    if (/^https?:\/\//i.test(url)) {
      return (
        <a href={url} target="_blank" rel="noopener noreferrer" className="link-underline">
          {children}
        </a>
      );
    }
    return (
      <Link href={url} className="link-underline">
        {children}
      </Link>
    );
  },
  h2({ children }) {
    return (
      <h2 className="mb-4 mt-12 font-display text-2xl font-semibold leading-tight tracking-[-0.02em] text-[var(--ink)] first:mt-0 sm:text-3xl">
        {children}
      </h2>
    );
  },
  h3({ children }) {
    return (
      <h3 className="mb-3 mt-10 font-display text-xl font-semibold leading-snug tracking-[-0.01em] text-[var(--ink)] sm:text-2xl">
        {children}
      </h3>
    );
  },
  p({ children }) {
    return <p className="mb-6 leading-relaxed text-neutral-700">{children}</p>;
  },
  strong({ children }) {
    return <strong className="font-semibold text-[var(--ink)]">{children}</strong>;
  },
  ul({ children }) {
    return <ul className="mb-6 list-disc space-y-2 pl-6 marker:text-[var(--coral)]">{children}</ul>;
  },
  ol({ children }) {
    return <ol className="mb-6 list-decimal space-y-2 pl-6 marker:font-semibold marker:text-[var(--coral)]">{children}</ol>;
  },
  li({ children }) {
    return <li className="pl-1 leading-relaxed text-neutral-700">{children}</li>;
  },
  blockquote({ children }) {
    return (
      <blockquote className="mb-8 border-l-2 border-[var(--coral)] pl-5 text-lg italic leading-relaxed text-neutral-700 [&>p]:mb-0">
        {children}
      </blockquote>
    );
  },
  hr() {
    return <hr className="my-10 border-neutral-200" />;
  },
};

/** Wraps raw article markdown in the editorial typography wrapper. */
export function InsightProse({ content }: { content: string }) {
  return (
    <div className="mx-auto max-w-3xl text-lg">
      <ReactMarkdown components={components}>{content}</ReactMarkdown>
    </div>
  );
}
