import Image from "next/image";
import { cn } from "@/lib/utils";

/**
 * Brand logo. Uses the actual Cybexs Tech wordmark assets.
 * - light: black wordmark + coral dot on transparent (light surfaces)
 * - white: white wordmark + coral dot on transparent (dark surfaces)
 */
export function Logo({
  variant = "light",
  className,
  priority = false,
}: {
  variant?: "light" | "white";
  className?: string;
  priority?: boolean;
}) {
  return (
    <span className={cn("relative inline-flex items-center", className)}>
      <Image
        src={variant === "white" ? "/brand/logo-white.png" : "/brand/logo-transparent.png"}
        alt="Cybexs Tech"
        width={302}
        height={49}
        priority={priority}
        className="h-[26px] w-auto sm:h-[30px] object-contain"
      />
    </span>
  );
}
