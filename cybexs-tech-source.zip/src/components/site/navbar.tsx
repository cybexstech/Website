"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Menu, X, ArrowRight } from "lucide-react";
import { Logo } from "@/components/site/logo";
import { ServiceIcon } from "@/components/site/service-icon";
import { SERVICES } from "@/data/services";
import { INDUSTRIES } from "@/data/industries";
import { cn } from "@/lib/utils";
import { trackEvent } from "@/lib/analytics";

const NAV_LINKS = [
  { href: "/about", label: "About" },
  { href: "/work", label: "Work" },
  { href: "/insights", label: "Insights" },
  { href: "/contact", label: "Contact" },
];

export function SiteNavbar() {
  const [scrolled, setScrolled] = React.useState(false);
  const [openMenu, setOpenMenu] = React.useState<"services" | "industries" | null>(null);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const pathname = usePathname();
  const closeTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  React.useEffect(() => {
    setMobileOpen(false);
    setOpenMenu(null);
  }, [pathname]);

  // Lock body scroll when the mobile menu is open.
  React.useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  const scheduleClose = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpenMenu(null), 140);
  };
  const cancelClose = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled || openMenu || mobileOpen
          ? "border-b border-neutral-200/80 bg-white/90 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <nav className="container-site flex h-[68px] items-center justify-between gap-4" aria-label="Main navigation">
        <Link href="/" className="flex items-center gap-2" aria-label="Cybexs Tech home">
          <Logo priority />
        </Link>

        {/* Desktop nav */}
        <div className="hidden items-center gap-1 lg:flex">
          <div className="relative" onMouseEnter={() => { cancelClose(); setOpenMenu("services"); }} onMouseLeave={scheduleClose}>
            <button
              type="button"
              className={cn(
                "flex items-center gap-1 rounded-full px-4 py-2 text-sm font-medium text-neutral-700 transition-colors hover:bg-neutral-100 hover:text-neutral-950",
                openMenu === "services" && "bg-neutral-100 text-neutral-950"
              )}
              aria-expanded={openMenu === "services"}
              aria-haspopup="true"
              onClick={() => setOpenMenu(openMenu === "services" ? null : "services")}
            >
              Services
              <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", openMenu === "services" && "rotate-180")} />
            </button>
            <AnimatePresence>
              {openMenu === "services" && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  transition={{ duration: 0.18 }}
                  className="absolute left-1/2 top-full z-50 w-[640px] -translate-x-1/2 pt-3"
                >
                  <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-[0_24px_60px_-20px_rgba(10,10,10,0.25)]">
                    <div className="grid grid-cols-2 gap-1 p-3">
                      {SERVICES.map((s) => (
                        <Link
                          key={s.slug}
                          href={`/services/${s.slug}`}
                          className="group flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-neutral-50"
                        >
                          <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-neutral-200 bg-white text-neutral-900 transition-colors group-hover:border-[var(--coral)] group-hover:text-[var(--coral)]">
                            <ServiceIcon icon={s.icon} className="h-4 w-4" />
                          </span>
                          <span>
                            <span className="block text-sm font-semibold text-neutral-900">{s.name}</span>
                            <span className="mt-0.5 block text-xs leading-relaxed text-neutral-500">{s.tagline}</span>
                          </span>
                        </Link>
                      ))}
                      <Link
                        href="/services"
                        className="col-span-2 mt-1 flex items-center justify-between rounded-xl bg-neutral-950 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-neutral-800"
                      >
                        All services overview
                        <ArrowRight className="h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="relative" onMouseEnter={() => { cancelClose(); setOpenMenu("industries"); }} onMouseLeave={scheduleClose}>
            <button
              type="button"
              className={cn(
                "flex items-center gap-1 rounded-full px-4 py-2 text-sm font-medium text-neutral-700 transition-colors hover:bg-neutral-100 hover:text-neutral-950",
                openMenu === "industries" && "bg-neutral-100 text-neutral-950"
              )}
              aria-expanded={openMenu === "industries"}
              aria-haspopup="true"
              onClick={() => setOpenMenu(openMenu === "industries" ? null : "industries")}
            >
              Industries
              <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", openMenu === "industries" && "rotate-180")} />
            </button>
            <AnimatePresence>
              {openMenu === "industries" && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  transition={{ duration: 0.18 }}
                  className="absolute left-1/2 top-full z-50 w-[420px] -translate-x-1/2 pt-3"
                >
                  <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white p-2 shadow-[0_24px_60px_-20px_rgba(10,10,10,0.25)]">
                    {INDUSTRIES.map((i) => (
                      <Link
                        key={i.slug}
                        href={`/industries/${i.slug}`}
                        className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-neutral-800 transition-colors hover:bg-neutral-50"
                      >
                        <ServiceIcon icon={i.icon} className="h-4 w-4 text-neutral-400" />
                        {i.name}
                      </Link>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {NAV_LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-medium transition-colors hover:bg-neutral-100 hover:text-neutral-950",
                pathname.startsWith(l.href) ? "text-neutral-950" : "text-neutral-700"
              )}
            >
              {l.label}
            </Link>
          ))}
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            href="/book"
            onClick={() => trackEvent("consultation_cta_clicked", { location: "navbar" })}
            className="inline-flex h-10 items-center rounded-full bg-[var(--ink)] px-5 text-sm font-semibold text-white transition-all hover:bg-[var(--coral)]"
          >
            Book Free Consultation
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          type="button"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-neutral-200 bg-white/80 text-neutral-900 lg:hidden"
          onClick={() => setMobileOpen((v) => !v)}
          aria-expanded={mobileOpen}
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden border-t border-neutral-200 bg-white lg:hidden"
          >
            <div className="container-site max-h-[calc(100dvh-68px)] space-y-1 overflow-y-auto py-5 scrollbar-slim">
              <MobileSection title="Services" defaultOpen>
                <Link href="/services" className="block rounded-lg px-3 py-2 text-sm font-semibold text-[var(--coral)]">
                  All services overview
                </Link>
                {SERVICES.map((s) => (
                  <Link key={s.slug} href={`/services/${s.slug}`} className="block rounded-lg px-3 py-2 text-sm text-neutral-800">
                    {s.name}
                  </Link>
                ))}
              </MobileSection>
              <MobileSection title="Industries">
                {INDUSTRIES.map((i) => (
                  <Link key={i.slug} href={`/industries/${i.slug}`} className="block rounded-lg px-3 py-2 text-sm text-neutral-800">
                    {i.name}
                  </Link>
                ))}
              </MobileSection>
              <div className="pt-2">
                {NAV_LINKS.map((l) => (
                  <Link key={l.href} href={l.href} className="block rounded-lg px-3 py-2.5 text-base font-semibold text-neutral-900">
                    {l.label}
                  </Link>
                ))}
              </div>
              <Link
                href="/book"
                onClick={() => trackEvent("consultation_cta_clicked", { location: "mobile_menu" })}
                className="btn-accent mt-4 w-full"
              >
                Book Free Consultation
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function MobileSection({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div className="rounded-xl border border-neutral-200">
      <button
        type="button"
        className="flex w-full items-center justify-between px-3 py-2.5 text-sm font-semibold uppercase tracking-wider text-neutral-500"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        {title}
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
      </button>
      {open && <div className="space-y-0.5 px-1 pb-2">{children}</div>}
    </div>
  );
}
