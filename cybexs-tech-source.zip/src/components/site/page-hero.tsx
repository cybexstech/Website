import { Reveal } from "@/components/motion/reveal";
import { Breadcrumbs, type Crumb } from "@/components/site/breadcrumbs";
import { cn } from "@/lib/utils";

/** Shared inner-page hero: dark editorial band with breadcrumbs. */
export function PageHero({
  eyebrow,
  title,
  description,
  crumbs,
  children,
  className,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  crumbs: Crumb[];
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("noise-overlay relative overflow-hidden bg-[var(--ink)] pb-16 pt-32 text-white sm:pb-20 sm:pt-40", className)}>
      <div className="grid-lines-dark absolute inset-0" aria-hidden="true" />
      <div
        className="absolute -left-24 top-24 h-72 w-72 rounded-full opacity-15 blur-[110px]"
        style={{ background: "radial-gradient(circle, #FF3B30 0%, transparent 70%)" }}
        aria-hidden="true"
      />
      <div className="container-site relative">
        <Reveal>
          <Breadcrumbs items={crumbs} dark />
          <p className="eyebrow mt-8 !text-neutral-400">{eyebrow}</p>
          <h1 className="display-1 mt-4 max-w-4xl">{title}</h1>
          {description && <p className="lede mt-6 max-w-2xl !text-neutral-400">{description}</p>}
        </Reveal>
        {children && <div className="mt-10">{children}</div>}
      </div>
    </section>
  );
}
