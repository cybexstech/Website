import { Reveal } from "@/components/motion/reveal";
import { cn } from "@/lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  dark = false,
  className,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  dark?: boolean;
  className?: string;
}) {
  return (
    <Reveal className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      <p className={cn("eyebrow", dark && "!text-neutral-400", align === "center" && "justify-center")}>{eyebrow}</p>
      <h2 className={cn("display-2 mt-4", dark ? "text-white" : "text-[var(--ink)]")}>{title}</h2>
      {description && <p className={cn("lede mt-5", dark && "!text-neutral-400")}>{description}</p>}
    </Reveal>
  );
}
