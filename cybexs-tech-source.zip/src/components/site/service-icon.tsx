import {
  Bot,
  PhoneCall,
  History,
  TrendingUp,
  Headset,
  PlugZap,
  MonitorSmartphone,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  Bot,
  PhoneCall,
  History,
  TrendingUp,
  Headset,
  PlugZap,
  MonitorSmartphone,
};

export function ServiceIcon({ icon, className }: { icon: string; className?: string }) {
  const Icon = ICONS[icon] ?? Bot;
  return <Icon className={className} aria-hidden="true" />;
}
