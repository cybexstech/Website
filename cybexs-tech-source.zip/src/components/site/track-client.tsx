"use client";

import { trackEvent, type AnalyticsEvent } from "@/lib/analytics";

/**
 * Small client bridge so Server Components can attach click tracking to links
 * without turning the whole server tree into client components.
 */
export function trackEventClient(event: AnalyticsEvent, props?: Record<string, string | number | boolean>) {
  return () => trackEvent(event, props);
}
