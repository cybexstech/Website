"use client";

import Link from "next/link";
import { trackEvent, type AnalyticsEvent } from "@/lib/analytics";
import type { ReactNode } from "react";

/**
 * Client Link wrapper so Server Components can attach analytics to
 * navigation events without turning their whole tree into client components.
 */
export function TrackedLink({
  href,
  event,
  props,
  className,
  children,
  ariaLabel,
}: {
  href: string;
  event: AnalyticsEvent;
  props?: Record<string, string | number | boolean>;
  className?: string;
  children: ReactNode;
  ariaLabel?: string;
}) {
  return (
    <Link
      href={href}
      className={className}
      aria-label={ariaLabel}
      onClick={() => trackEvent(event, props)}
    >
      {children}
    </Link>
  );
}
