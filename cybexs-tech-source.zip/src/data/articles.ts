// ---------------------------------------------------------------------------
// Seed data for the Insights blog. Task 2-e owns the CONTENT of this file.
// Publication policy: hybrid launch — the strongest articles are PUBLISHED,
// the rest stay DRAFT for future release. Drafts never appear publicly.
//
// Content rules (master spec):
// - Original, useful, addresses a specific reader problem for business owners.
// - No fabricated statistics, studies, named companies, quotations or client
//   results. Reasoning and examples are framed as scenarios.
// - 2-4 contextual internal links per article to real service, industry or
//   booking pages (verified against src/data/services.ts / industries.ts).
// - seoTitle <= 60 chars, seoDescription <= 155 chars (published articles).
// ---------------------------------------------------------------------------

export type ArticleSeed = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  tags: string;
  status: "DRAFT" | "PUBLISHED";
  seoTitle?: string;
  seoDescription?: string;
  author?: string;
  readMinutes?: number;
  /** Markdown. Use ## / ### headings, paragraphs, lists. Include 2-4 contextual internal links. */
  content: string;
  /** ISO date; only used for PUBLISHED articles. */
  publishedAt?: string;
};

export const ARTICLES_SEED: ArticleSeed[] = [
  // ------------------------------------------------------------------
  // AI AUTOMATION
  // ------------------------------------------------------------------
  {
    slug: "which-business-processes-to-automate-first",
    title: "Which business processes should you automate first? A practical framework",
    excerpt:
      "Most automation projects fail because they start with the tool, not the process. This framework scores your workflows by volume, rules and pain — so the first automation you build is one that pays back.",
    category: "AI Automation",
    tags: "automation strategy, business processes, operations",
    status: "PUBLISHED",
    seoTitle: "Which Business Processes to Automate First",
    seoDescription:
      "A practical framework for choosing what to automate first: volume, rule clarity, stability, data readiness and pain — with a worked example.",
    readMinutes: 7,
    publishedAt: "2025-12-16T09:00:00.000Z",
    content: `## The expensive way to choose

Most automation initiatives start the same way: someone sees a tool demo, gets excited, and then goes hunting for a process to justify the purchase. The result is predictable — a fragile integration nobody wants to maintain, attached to a process that was never worth automating in the first place.

The order matters. Choose the process first, using criteria you can defend to your team and your accountant, and only then pick the tool. Here is the framework we use when scoping automation work with business owners.

## Step 1: Inventory what actually happens

You cannot prioritize what you have not written down. Spend one week listing the recurring work in your business: every task that happens weekly or more often, who performs it, roughly how long it takes, and which systems it touches.

Aim for honest, not perfect. The owner of a clinic knows the front desk re-confirms appointments by hand every afternoon. The founder of an agency knows every proposal is reassembled from an old document. Write down what is true, not what the org chart implies.

### Ask better questions

The people doing the work tend to under-report their own busywork, because it feels like admitting inefficiency. Instead of asking what is repetitive, ask:

- "If this task disappeared tomorrow, what would you do with the time?"
- "Which part of your week do you dread?"
- "Where do things fall through the cracks?"

Those answers surface the real candidates.

## Step 2: Score each process on five dimensions

For every candidate, score from 1 to 5 on five dimensions:

- **Volume.** How often does it happen? A task that runs thirty times a week beats a task that runs monthly, even if the monthly one feels more important.
- **Rule clarity.** Could a trained intern do it from written instructions? Processes with clear rules and recognizable exceptions are far easier to automate than ones requiring taste or negotiation.
- **Stability.** Has the process worked roughly the same way for six months or more? Automating something that is about to change means rebuilding it immediately.
- **Data readiness.** Is the information it needs already digital and structured — in a CRM, a form, an inbox — or does it live in phone calls, paper and someone's memory?
- **Pain.** What breaks when it is done late or wrong? Work with direct customer or cash impact deserves a higher weight than internal convenience.

Add up the scores. You now have a ranked list that is not based on whoever spoke loudest in the meeting.

## Step 3: Sort into three lists

The scoring produces three natural groups, and only the first should be automated now:

1. **Automate.** High volume, clear rules, stable, decent data. Typical first projects: quote preparation, appointment confirmations, invoice intake, lead routing, routine reporting.
2. **Assist.** Valuable but judgment-heavy. Here AI drafts and a human approves — draft replies, research summaries, prepared documents. Removing most of the typing while keeping all of the deciding is often the best return in the whole program.
3. **Leave alone.** Low volume, shifting rules, or high stakes with no pattern yet. Revisit in six months; processes change.

> The most common mistake at this step is automating a process that should simply be deleted. If nobody would miss it, remove it — automation is not a recycling bin for dead work.

## A worked scenario

Consider a 20-person distribution business. The inventory turns up three candidates: sales reps copy web-form leads into the CRM by hand, an office manager converts email quote requests into quotations, and the dispatcher re-types delivery notes into the tracking system.

Scored honestly, the quote workflow wins. It runs daily, follows clear rules, has not changed in a year, starts from structured emails, and every hour of delay costs orders. Lead entry scores well too. The delivery notes matter, but they depend on phone calls and handwriting — poor data readiness — so that one goes on the assist list until intake is cleaned up.

That is the shape of a good first project: [one workflow rebuilt end to end](/services/ai-automation/business-process-automation) and measured against the hours it used to consume — not a company-wide platform migration nobody finishes.

## Your first 30 days

- **Week 1:** build the inventory with your team.
- **Week 2:** score it, sort the three lists, and pick one project — not five.
- **Weeks 3 and 4:** document the chosen process precisely, define what done-right looks like, and design the workflow with exception handling: what happens when the system is unsure.

One well-chosen process, automated properly, does more for your operations than a shelf of tools — and it builds the internal trust that makes the second, third and fourth automation easier to land.

If you want a second opinion on your ranked list before investing, that is exactly where [our AI automation service](/services/ai-automation) starts. You can [book a free consultation](/book) and walk through your inventory with us.`,
  },
  {
    slug: "human-in-the-loop-ai-automation-trust",
    title: "Human-in-the-loop: designing AI automation people actually trust",
    excerpt:
      "The best AI automations are not the ones that run unattended — they are the ones your team trusts enough to leave alone. How to design checkpoints, escalation and audit trails that build that trust.",
    category: "AI Automation",
    tags: "human-in-the-loop, AI adoption, change management",
    status: "DRAFT",
    readMinutes: 6,
    content: `## Why good automations get switched off

Every operator has seen it: a clever automation goes live, and three weeks later the team is quietly maintaining a parallel spreadsheet. Nothing was technically wrong with the automation. The team simply did not trust it — and trust is not a launch-announcement problem. It is a design problem.

People ignore automated systems for rational reasons. They cannot predict what it will do next. They cannot see why it made a decision. And they cannot correct it when it is wrong without derailing their day. Design for those three failures and adoption follows.

## Keep humans at the consequential points

Not every decision deserves a human, and not every decision can survive without one. Sort the steps in your workflow by consequence:

- **Low impact, easily reversible** — tagging, sorting, drafting internal notes — can run unattended.
- **Consequential actions** — sending a price, cancelling an order, issuing a refund — should pause for one-click approval. The system prepares; a person decides.
- **Sensitive situations** — a complaint from a longtime customer, anything medical or legal — should notify a human immediately, with full context attached.

The point is not to slow work down. It is to put the scarce resource — human attention — exactly where judgment actually changes the outcome.

## Replace all-or-nothing with confidence thresholds

AI systems are strongest at knowing what they know. Use that. Route work by confidence: high-confidence items act automatically, medium-confidence items queue for review, low-confidence items go straight to a person with the reason flagged.

That review queue is not a defect of the design — it is the product. Watch it weekly. If the same question keeps landing there, the answer is not more tolerance for mistakes; it is improving the workflow for that case.

## Make every action explainable

For each automated step, log what came in, what the system did, what it produced, and who approved it. An audit trail converts "I don't trust this thing" into "I can see exactly why it did that."

Then close the loop with a short, blameless weekly review. Twenty minutes over the exception list: what did we correct, and what should the workflow learn? Corrections become configuration, not complaints.

## Make the off-switch easy

Counterintuitive but consistent: teams trust automation more when stopping it is trivial. Give the workflow a clear kill switch and per-step pause. An automation that is easy to turn off is also easy to turn back on after a fix — which means problems get reported early instead of worked around silently.

## Roll out in three modes

1. **Shadow mode.** The system suggests, does not act. Compare its output with what humans actually did.
2. **Assisted mode.** It drafts, humans approve. Accuracy data accumulates.
3. **Narrow autonomy.** It acts alone only where it has been demonstrably reliable, with checkpoints everywhere else.

Involve the people whose work is being redesigned from day one. The goal you are selling internally is leverage, not replacement: fewer copy-paste hours, more customer hours.

## A worked example: invoice intake

Consider an accounts team that processes supplier invoices by hand: download the attachment, check it against the purchase order, type the amounts into the ledger, file it. The trust-first automation of this process looks unremarkable — and that is the point. Extraction and matching run automatically. Invoices that match their purchase order exactly post straight through. Mismatched amounts, new suppliers and anything unreadable queue for a person, pre-filled with what the system managed to read.

In the first weeks the review queue is busy while validation rules learn the supplier base. As the rules mature, the queue shrinks — and because every decision was logged, the team can see exactly why. Nobody wonders what the system did while they were out.

## What trust looks like six months later

Exceptions trend down. The review queue shrinks. And the strongest signal appears when the team starts asking for the next automation instead of resisting the current one.

That is the standard we design against in [our AI automation work](/services/ai-automation) — multi-step workflows with explicit human checkpoints are the core of [our AI workflow orchestration approach](/services/ai-automation/ai-workflow-orchestration). If your last automation died of distrust, [book a free consultation](/book) and we will show you what a trust-first design looks like for your process.`,
  },

  // ------------------------------------------------------------------
  // VOICE AI
  // ------------------------------------------------------------------
  {
    slug: "ai-voice-agent-small-business-phone",
    title: "What an AI voice agent can (and can't) do for a small business phone line",
    excerpt:
      "An AI voice agent can answer every call at midnight and book appointments while you work. Here is an honest breakdown of where it excels, where it should hand off, and how to set one up without annoying your callers.",
    category: "Voice AI",
    tags: "voice AI, phone answering, customer experience",
    status: "PUBLISHED",
    seoTitle: "AI Voice Agents for Small Business Phone Lines",
    seoDescription:
      "An honest look at what an AI voice agent handles well on a small business phone line, where it should hand off to a human, and how to measure it.",
    readMinutes: 6,
    publishedAt: "2025-12-02T09:00:00.000Z",
    content: `## The phone problem nobody staffs for

A small business misses calls for boring reasons: everyone is on another line, on a job site, at lunch, or it is 7pm. Each missed call is a customer who may or may not try again. Hiring someone to cover every gap is not realistic — and yet an unanswered phone quietly caps how big the business can get.

AI voice agents promise to fix this. Some of that promise is real. Some of it is marketing. Here is an honest breakdown for a typical small business phone line.

## What a voice agent genuinely handles well

- **Instant answers, any hour.** Every call is picked up on the first ring, at midnight or during a rush, with no hold music.
- **Routine questions.** Hours, address, service area, booking rules, price ranges — the questions your team answers ten times a day, drawn from your actual written content.
- **Bookings against your real calendar.** A caller can check availability and [book or move an appointment](/services/ai-voice-agents/appointment-scheduling-calls) without waiting for a callback.
- **Structured message taking.** Name, number, reason, urgency — captured consistently and sent to you, instead of a sticky note.
- **Overflow coverage.** When your front desk is busy, the agent answers instead of the voicemail void.

Picture the after-hours call for a heating company in the first cold week of winter: a caller with no heat, an address, and a description of the problem. The agent captures all of it accurately, books the earliest slot, and the crew starts the morning with a structured list instead of a full voicemail inbox. Nothing dramatic — just coverage that did not exist before.

For a clinic front desk that juggles walk-ins and calls, this combination alone removes most of the daily interruption load. That is exactly the scenario we describe on our [AI receptionist](/services/ai-voice-agents/ai-receptionist) page.

## Where it should not pretend to be human

An agent that bluffs is worse than a voicemail. Good deployments are honest about boundaries:

- **Judgment calls.** Insurance disputes, custom pricing negotiations, legal or medical questions beyond scheduling — these need a person. The agent should say so and route.
- **Emotional moments.** A distressed caller should reach empathy, not a script. A warm transfer, or an accurate promise that someone will call back within the hour, beats an awkward attempt to carry on.
- **Anything not in its knowledge.** A confident wrong answer is the failure mode to design against. Scope the agent to what it knows and hand off the rest.

That handoff design — when to transfer, what to promise, how to summarize the call for your team — matters more than voice quality. We treat it as the core of [our AI voice agent service](/services/ai-voice-agents).

## The setup that makes or breaks it

Voice agents fail for unglamorous reasons, and all of them are fixable before launch:

1. **Thin knowledge.** If your services, policies and FAQs are not written down somewhere the agent can read, it will guess. Write them first.
2. **Unclear scope.** Define the three or four call types the agent owns, and the exact sentence it uses to hand off everything else.
3. **No disclosure.** Tell callers they are speaking with an assistant. Most people adapt instantly when they know what it is.
4. **No rehearsal.** Test with real questions from real customers, including the weird ones, before the number goes live.

## How to tell whether it is working

Baseline before you launch, then watch four numbers: the share of calls answered at all, bookings completed by the agent without human help, handoff accuracy (did the right calls reach a human), and follow-through on the callbacks it promised. Two weeks of reviewing transcripts will teach you more than any vendor demo.

## The honest bottom line

A voice agent will not replace your best people, and it should not try to. What it does well is remove the unanswered-call problem and the repetitive-question load, so the humans on your team spend their attention where it matters. For appointment-driven businesses — clinics, service companies, agencies — that is a meaningful shift.

If you want an outside assessment of your call flow, [book a free consultation](/book) and we will tell you plainly whether a voice agent fits.`,
  },

  // ------------------------------------------------------------------
  // LEAD REACTIVATION
  // ------------------------------------------------------------------
  {
    slug: "reactivate-dormant-leads-compliantly",
    title: "Your dormant lead list is an asset: how to reactivate it compliantly",
    excerpt:
      "Leads that went quiet are cheaper to revive than new ones are to find — if you work the list honestly. How to audit, segment and re-engage a dormant pipeline without spamming anyone.",
    category: "Lead Generation",
    tags: "lead reactivation, CRM hygiene, compliance",
    status: "PUBLISHED",
    seoTitle: "Reactivate Dormant Leads — Compliantly",
    seoDescription:
      "Dormant leads cost you once already. How to audit, segment and re-engage an old pipeline with honest messaging and the right permissions.",
    readMinutes: 7,
    publishedAt: "2025-11-25T09:00:00.000Z",
    content: `## The list you already paid for

Somewhere in your CRM sits the cheapest growth you own: people who raised a hand and then went quiet. Quote requests that never closed, trials that expired, past customers who drifted, inquiries from two years ago. You already paid to acquire every one of them — in ads, in sales time, in reputation.

Reactivating even a small share is usually cheaper per conversation than generating brand-new leads. But dormant-list work has a hard rule: do it respectfully and within the permissions you actually have, or you convert an asset into a spam complaint.

## Step 1: Audit before you message anyone

Export the list and look at it properly before writing a single message:

- **Dedupe and validate.** The same contact often appears three times with three spellings. Fix the records first — that cleanup is the foundation of [reliable reactivation workflows](/services/lead-reactivation/crm-reactivation-workflows).
- **Suppress immediately.** Unsubscribes, hard bounces, anyone who complained. They stay suppressed permanently, not just this quarter.
- **Note the source and date.** A contact met at a trade fair last spring and a newsletter signup from 2022 are different relationships with different permissions.

## Step 2: Segment by relationship, not by age

Age alone tells you little. Sort by the relationship you had:

1. **Quoted, never closed.** They evaluated you once. A relevant update — a new capability, revised pricing, a changed process — is a natural reason to reconnect.
2. **Past customers gone quiet.** The warmest list you have. A note that says it has been a while, here is what is new, is X still a priority — that is honest and usually welcome.
3. **Inquiries that stalled early.** Worth one respectful touch, not a campaign.
4. **Passive subscribers.** Newsletter-only contacts belong in nurture, not a sales sequence.

Each segment gets its own message, its own ask, and its own expectations.

## Step 3: Get the permission question right

This is not legal advice — rules differ by country and channel, and for anything regulated you should confirm with counsel for your jurisdiction. But three principles hold up almost everywhere:

- **Reasonable expectation.** Message people about the thing they originally asked you about. A follow-up to a quote is expected; a cross-sell blast is not.
- **Clear identity and easy exit.** Say who you are and why you are reaching out, and make opting out a one-click affair that you honor instantly.
- **Channel discipline.** Email, SMS and phone each carry different consent rules and different tolerance. When in doubt, use the channel they used to contact you, and stay conservative with frequency.

## Step 4: Lead with value, not guilt

The weakest reactivation message ever written is the one that starts with noticing silence. Nobody enjoys being scolded for a non-purchase. Lead with something true and useful instead:

- Our pricing changed recently — here is the updated sheet for the configuration you asked about.
- We now handle in-house the thing that made you pause last year.
- Two slots opened in your area next week; want one held?

One message, one clear ask, written like a person.

## Step 5: Sequence with an exit

Keep the segments as saved views in your CRM, not as one-off spreadsheets — reactivation is a cycle you will run again, and stable segments make results comparable. Send from a person who plausibly owns the relationship, with a reply address a human reads; a no-reply sender contradicts everything else in the message.

Three to four touches over roughly three weeks is plenty: an email, a different-angle follow-up, then a phone call for the segments where calling is expected. Stop the moment someone replies, opts out, or clearly signals no. Interested replies go to a human the same day — speed matters more here than in almost any other sales motion.

After the sequence, move non-responders into slow, genuinely useful nurture — a quarterly note at most. The list stays warm without being worked to death.

## What success actually looks like

Reactivation replies are conversations, not conversions; judge the campaign by booked calls and restarted deals, per segment, not by open-rate vanity. Treat the first run as a baseline: the second pass, better segmented, always behaves differently from the first.

This is the core of [our dormant lead follow-up work](/services/lead-reactivation/dormant-lead-follow-up) inside [our lead reactivation service](/services/lead-reactivation). If you would like help auditing your list and designing the first compliant sequence, [book a free consultation](/book).`,
  },
  {
    slug: "reminder-sequences-missed-appointments",
    title: "Reminder sequences that recover missed appointments without nagging",
    excerpt:
      "No-shows are rarely malice — they are forgetting, ambiguity and friction. A reminder sequence that confirms, reschedules and rebooks politely can recover much of that lost time.",
    category: "Lead Generation",
    tags: "appointments, reminders, no-shows",
    status: "DRAFT",
    readMinutes: 5,
    content: `## Why people actually miss appointments

Almost nobody no-shows out of spite. Appointments are missed because the week got noisy, the confirmation was never really read, the date lived in the wrong calendar, rescheduling felt like a chore, or the value of the meeting had quietly faded. A good reminder sequence treats each of those causes separately instead of sending the same message louder.

## Design the timing ladder first

Different moments deserve different messages:

1. **72 hours before — confirm.** One short message: date, time, provider, location. Ask for a one-word reply to confirm, and make rescheduling a link, not a phone call.
2. **24 hours before — prepare.** What to bring, what will happen, how long it takes, parking or the video link. Preparation reduces day-of panic cancellations.
3. **2 hours before — reduce friction.** Travel prompt, directions, the meeting link. At this point you are saving the appointment, not selling it.
4. **15 minutes after a miss — soften.** A note that assumes good faith and offers another slot keeps the relationship intact.
5. **Next day — rebook.** One message with two concrete alternative times. Concrete options convert; let-us-know-when-suits-you does not.

The right ladder depends on the business. A clinic reminder and a B2B sales call are different relationships; adapt the tone, not the structure. For appointment-heavy operations, this is the logic behind our [appointment rebooking workflows](/services/lead-reactivation/appointment-rebooking).

## Choose channels deliberately

- **SMS** for time-sensitive prompts — it is read, but it is also personal; keep it short and infrequent.
- **Email** for details and links — the confirmation trail people search for later.
- **A phone call** for high-value appointments, or after two unanswered reminders — a two-minute call recovers what text cannot.

Respect quiet hours, honor channel preferences, and treat opt-outs as permanent. Consent basics belong in the design, not the fine print: only message people who booked with you, on the channels they used with you, and check how consent rules apply in your region before automating SMS at scale. For clinics and other sensitive contexts, share only what is needed — the appointment time, never clinical detail.

## Write like a person, offer one action

Every reminder should pass three checks: could a stranger tell exactly which appointment this is; is there exactly one obvious action; and does it fit in one glance? Confirmations should be answerable with a single word. Rescheduling should never require calling between nine and five — that friction alone creates no-shows. When a template fails one of the three checks, shorten it rather than explaining more; confusion, not lack of detail, is what reminders exist to remove.

> If your reminder needs marketing copy to feel important, it is doing a different job. Reminders are logistics; keep them that way.

## Make rescheduling easier than cancelling

The single most effective pattern: every reminder carries a reschedule link showing real availability, ideally with same-week alternatives pre-filtered. When calling is warranted, the caller offers two specific slots rather than asking an open question. For teams that handle this by phone, the [AI-assisted appointment scheduling calls](/services/ai-voice-agents/appointment-scheduling-calls) we build can run that recovery motion consistently, every time.

## Set stop rules

Cap touches per appointment — five across the full ladder is generous. Suppress anyone who asked once to be left alone, and never let two sequences overlap on the same person. Over-messaging is how recovery programs turn into unsubscribes.

## Where teams go wrong

Three patterns account for most failed reminder programs: sending every message at the same urgency, so nothing stands out when it matters; burying the one action under policies and marketing; and having no stop rules, so a person who missed once receives follow-ups forever. All three are fixed in design, not in effort.

## Measure recovery, not sending

Track the show-up rate before and after the change, the share of missed appointments that rebook within seven days, and — as a guardrail — complaint and opt-out rates. Sending volume is not a KPI; recovered hours are.

Done well, reminder work is quiet: fewer awkward phone calls, fuller calendars, and customers who feel looked after rather than chased. That is the standard we build to in [our lead reactivation service](/services/lead-reactivation). If missed appointments are bleeding your week, [book a free consultation](/book) and we will map your reminder ladder with you.`,
  },

  // ------------------------------------------------------------------
  // SALES & LEAD GENERATION
  // ------------------------------------------------------------------
  {
    slug: "outbound-pipeline-consistency",
    title: "The outbound math: why pipeline consistency beats bursts",
    excerpt:
      "Three weeks of focused outbound followed by silence produces a pipeline that arrives in bursts and dies quietly. Why steady weekly volume compounds — and how to build a rhythm that survives busy season.",
    category: "Lead Generation",
    tags: "outbound sales, pipeline, sales operations",
    status: "PUBLISHED",
    seoTitle: "Outbound Sales: Consistency Beats Bursts",
    seoDescription:
      "Why three quiet weeks of outbound beat three frantic ones: the arithmetic of pipeline flow and the weekly rhythm that keeps it alive.",
    readMinutes: 6,
    publishedAt: "2025-11-11T09:00:00.000Z",
    content: `## The feast-and-famine cycle

Most sales teams know this rhythm: delivery gets busy, prospecting stops, the pipeline drains quietly for six weeks, then panic — a burst of outreach, a scramble, and a return to delivery as soon as meetings are booked. The cycle repeats, and everyone inside it is exhausted.

The problem is not effort. Teams in this pattern work hard in bursts. The problem is that pipeline does not reward bursts; it rewards flow.

## The arithmetic of flow

Picture a simple, illustrative funnel — the exact numbers belong to your business, but the shape is universal. Say that to create one qualified conversation you need ten honest touches; that three conversations tend to produce one opportunity; and that one in three opportunities closes. In that world:

- 90 touches become 9 conversations become 3 opportunities become 1 customer.

What matters is the shape: stages multiply. A 20% shortfall in weekly touches is not a 20% shortfall in customers three months out — compounded through the funnel, it quietly removes entire deals from next quarter. Bursts cannot make the arithmetic up later, because conversion has memory: replies beget follow-ups, follow-ups beget calls, and a week of silence resets the momentum of every thread you started.

Think of pipeline as a reservoir. Constant inflow, steady outflow through closed deals. Bursts create waves — a drowned team one month, a starving one the next.

## Why bursts underperform beyond the math

- **Learning compounds weekly.** Outbound improves through iteration — first sentences, follow-up timing, objection handling. A weekly rhythm gives you fifty-two learning cycles a year. Four bursts give you four.
- **Prospects experience the gap.** Three touches, then silence, then a fresh sequence months later reads as abandonment. Consistency reads as a company that keeps its word.
- **Team muscle atrophies.** Research, drafting and follow-up are skills. In burst mode, every cycle starts rusty.

## Build a rhythm that survives busy season

1. **Protect a fixed prospecting block.** Two mornings a week, calendar-owned, non-negotiable — the same way delivery deadlines are.
2. **A daily follow-up slot.** Pipeline is not built by first touches; it is built by the second and third. Give follow-ups their own protected time.
3. **A volume floor.** Define the minimum weekly touches that keep the reservoir level — and hold it in December, in delivery crunches, in summer.
4. **One honest weekly metric.** New qualified conversations per week. Activity counts are easy to game; conversations are not.
5. **Automate the scaffolding, not the voice.** List building, research briefs, draft preparation and CRM logging can all be systematized — that is the point of [our prospecting workflows](/services/sales-lead-generation/prospecting-workflows). The message itself stays human.

## Where automation genuinely helps

The reason most rhythms collapse is cost: prospecting done manually is slow, so it is the first thing sacrificed under delivery pressure. Removing the administrative layer — research, data entry, sequencing, reminders — cuts the cost of consistency until holding the floor is easy. That shift from manual to systematized prospecting is a large part of [our sales and lead generation work](/services/sales-lead-generation), alongside [appointment setting](/services/sales-lead-generation/appointment-setting) when calendars need filling.

## The rhythm on a real calendar

Concretely, for a two-person sales effort: Monday and Wednesday mornings, ninety minutes each, for research and first touches — batched, because context-switching is what makes prospecting feel heavier than it is. Every morning, thirty minutes of follow-ups before the inbox takes over. Friday afternoon, twenty minutes to review the week: conversations added, threads alive, one messaging experiment noted. That is the whole system. It fits around delivery work, it survives a bad week, and it produces a defensible answer to where next quarter's revenue is coming from.

## When you do need a burst

Launches, new territories, open capacity — sometimes you should surge. Surges work when they stack on top of the floor. They fail when they substitute for it, because the reservoir does not care how heroic last month was.

Consistency is not a personality trait. It is an operations problem: protected time, a volume floor, and systems cheap enough to keep running on your worst week. If yours keeps collapsing under delivery pressure, [book a free consultation](/book) — we will help you find the floor and automate everything beneath it.`,
  },
  {
    slug: "building-icp-team-uses",
    title: "Building an ICP your whole team actually uses",
    excerpt:
      "An ideal customer profile that lives in a slide helps nobody. Here is how to turn ICP work into a one-page operating document that shapes research, messaging and qualification every single week.",
    category: "Lead Generation",
    tags: "ICP, positioning, sales alignment",
    status: "DRAFT",
    readMinutes: 6,
    content: `## The ICP slide problem

Most companies have defined their ideal customer profile at least once, usually at a strategy offsite. The output is a handsome slide — and then nothing changes. Research is still done ad hoc, messaging is still guessed, and the pipeline still fills with prospects everyone privately agrees are a poor fit.

An ICP is only real when it changes daily decisions. That means treating it not as strategy documentation but as an operating document: short, specific, and present in the tools where work actually happens.

## Start from your best customers, honestly

Look backward before you write anything. Sort closed-won deals by the ones that renewed, expanded and referred — not just the ones that signed. Note what they share: industry, size, the trigger that made them start looking, the role that bought, the problem that hurt enough to spend money on.

Then do the uncomfortable half: study churned customers and lost deals. Who should never have entered the pipeline at all? Which deals were won on discount and left angry? An ICP built only from winners inherits survivorship bias.

## Write it as a one-pager with four blocks

1. **Fits.** The observable facts to check before any outreach: company type, size band, stack or systems, geography. If it takes longer than ten minutes to research, the list is too vague.
2. **Triggers.** The events that make this the right month to reach out — a hiring spree, a new location, a funding round, a season. Timing beats persuasion.
3. **Disqualifiers.** The honest list of who you politely decline or de-prioritize: too small, wrong regulatory context, needs you do not offer. Saying no early is a growth strategy, not a loss.
4. **Message hooks.** The angle per segment, written as sentences your team can actually say — not adjectives like "innovative" or "scalable."

## Make it operational

- **Research checklist.** New prospect review follows the ICP one-pager, capped at ten minutes.
- **Qualification fields.** The CRM requires ICP-fit answers before a deal can move past the first stage. No fit data, no forecast.
- **Fast no's are wins.** Track disqualifications as a healthy metric. Time reclaimed from bad-fit deals is where consistent pipelines come from.
- **Weekly review question.** Pipeline reviews ask "does this match the ICP?" before "what stage is it in?" — that order changes conversations.

This is the difference between research as an admin chore and research as [a qualification system](/services/sales-lead-generation/lead-research-qualification) that protects selling time.

## Keep it alive

An ICP decays like any other document. Put a quarterly review on the calendar with sales, marketing and delivery in the same room. Add language from real calls. Prune what no longer holds. Date and version it, so nobody is quoting last year's assumptions.

Teams that sell into clearly defined segments — [sales organizations](/industries/sales-organizations) being the obvious case — feel this compounding fastest: every research hour, every message and every qualification question gets sharper against the same target instead of being diluted across everyone.

## The failure modes to avoid

Three things quietly kill ICP work. First, breadth: a profile that describes almost everyone in your market describes no one — if a prospect can qualify without any trigger event, the triggers section is decorative. Second, vanity fits: company size bands copied from a competitor's deck rather than derived from your own wins. Third, orphaning: the document is written, celebrated, and never wired into the CRM, the research routine or the weekly review. The first two are fixed by looking honestly at your own data; the third is fixed by making the ICP a prerequisite of the workflow instead of a reference on a shelf.

## The test of a real ICP

Six weeks after rollout, ask three questions. Can a new team member research a prospect without asking anyone? Can you name three deals recently declined because of a disqualifier? Did the message hooks change at least once based on what calls revealed? Three yeses mean the ICP is alive.

If your profile still lives in a slide and your pipeline still carries passengers, that is a systems gap, not a discipline gap — it is exactly what we build in [our sales and lead generation service](/services/sales-lead-generation). [Book a free consultation](/book) and we will turn your ICP into a one-pager your team runs on.`,
  },

  // ------------------------------------------------------------------
  // BPO & CUSTOMER SUPPORT
  // ------------------------------------------------------------------
  {
    slug: "automate-or-outsource-support",
    title: "Automate or outsource? A decision framework for customer support",
    excerpt:
      "Between AI that answers routine questions and teams that handle everything else, most businesses need a mix. How to sort your support volume into what to automate, what to hand to a partner, and what stays in-house.",
    category: "Customer Support",
    tags: "customer support, automation, outsourcing",
    status: "PUBLISHED",
    seoTitle: "Automate or Outsource Customer Support?",
    seoDescription:
      "A decision framework for support volume: automate the repeatable, outsource the scalable, keep judgment in-house — with a worked example.",
    readMinutes: 7,
    publishedAt: "2025-12-09T09:00:00.000Z",
    content: `## The question behind the question

"Should we automate support or outsource it?" is usually the wrong either/or. Both are levers, and neither is a strategy by itself. The real question is which kinds of requests deserve which kind of handling — and that starts with looking at what actually fills your inbox.

## Map your support volume first

Pull one month of support requests — emails, calls, form submissions, chat logs — and sort them into buckets. Even a rough sort is enough:

- "Where is my order?" and status questions
- Returns, cancellations, rescheduling
- Billing and account access
- How-to and troubleshooting
- Complaints and escalations
- Pre-sales questions

Most owners discover their volume is not a smooth queue of unique problems; it is a handful of repeated patterns with a tail of genuine judgment calls. That shape is what makes the automate-or-outsource decision tractable.

## Sort every bucket on two axes

Score each bucket on volume — how often it happens — and judgment: how much product knowledge, empathy or discretion it needs. Four quadrants fall out:

1. **High volume, low judgment — automate.** Status questions, standard policy answers, document requests. These fit [AI-assisted inquiry processing](/services/ai-automation/customer-inquiry-processing), grounded in your actual policies so answers stay accurate.
2. **High volume, medium judgment — outsource.** Routine how-to coverage, evenings and overflow. A trained partner team working from your playbooks can carry these — that is the everyday work of [inbound customer support](/services/bpo-customer-support/inbound-customer-support) within [our BPO and customer support service](/services/bpo-customer-support).
3. **Low volume, high judgment — keep in-house.** Escalations, sensitive customers, anything reputation-sensitive. This is where your culture shows.
4. **Low volume, low judgment — eliminate.** Questions that only exist because a policy or page is confusing. Fix the cause; the ticket category will disappear.

## What automation is honestly good at today

Automation handles the documented and the repeatable: answering from your real policies, checking order or booking status, triaging requests to the right place, preparing draft replies for human approval. It fails — predictably — on ambiguity, emotion and novelty.

That is not a flaw to apologize for; it is a design constraint. Every automated support workflow needs an exception path: when the system is unsure, a human sees it with full context, and the customer never has to repeat themselves.

## What a support partner is good at

Outsourcing shines where the requirement is human attention at scale: evening and weekend coverage, languages, seasonal surges, back-office processing. It works when two things exist — decent documentation of your products and policies, and clear escalation routes.

Preparation is most of the effort. Before a partner takes their first ticket, they need a playbook per bucket: what the product does, the tone you expect, the top ten questions with approved answers, and exactly when to escalate and to whom. A one-month pilot on a single bucket — with response times, accuracy and customer feedback reviewed weekly — tells you more than any proposal document, and it makes expansion a decision based on evidence rather than hope.

Start with that pilot, measure honestly, and expand only what works.

## What stays with you

Some things should not leave the building, regardless of volume: systemic complaints (they are product feedback), VIP relationships, and the weekly reading of what support is telling you about the business. Someone senior must own that loop, or support becomes a cost center that repeats itself forever.

## A hybrid in practice

Consider an online store: automation answers order-status and returns-policy questions instantly; a partner team covers evenings and the holiday surge; the in-house lead handles escalations and feeds every recurring question back into the automation's knowledge base. Each month the automated layer absorbs a little more, because the humans upstream keep improving what it knows.

That continuous loop — automate the repeatable, humanize the rest, feed learnings back — is how modern support scales without diluting the experience.

## Decide in this order

1. Eliminate what should not exist.
2. Automate the documented and repeatable.
3. Outsource the scalable human layer.
4. Keep judgment, escalation and learning in-house.

Revisit the map quarterly; buckets migrate. If you want a second pair of eyes on your support volume, [book a free consultation](/book) — we run this exercise with owners regularly and will tell you honestly which quadrant to start with.`,
  },
  {
    slug: "support-slas-growing-companies",
    title: "What good support SLAs look like for growing companies",
    excerpt:
      "A support SLA is not a marketing promise — it is an operating agreement about priorities, coverage and honesty. How to design one your team can actually keep as you grow.",
    category: "Customer Support",
    tags: "SLA, support operations, customer experience",
    status: "DRAFT",
    readMinutes: 6,
    content: `## You already have an SLA — it just was not designed

Every company has a support SLA, even when nothing is written down. It is revealed by behavior: which tickets get answered in minutes and which wait three days, who escalates to whom, what happens on Fridays. An unwritten SLA is decided by whoever shouts loudest. Writing it down is how support stops being an accident.

## First response is not resolution

The most common self-deception in support metrics is celebrating fast first replies while problems age quietly for a week. A good SLA defines both:

- **First response** — a human has acknowledged the request with something genuinely useful, and the customer knows what happens next.
- **Resolution** — the issue is actually solved, or a clear plan with dates exists and the customer agrees.

Track both, separately, per priority. And be honest about business hours: a four-hour response published by a team that works nine-to-five means next morning for half your customers' tickets. Publish hours and channels alongside the numbers, or the numbers are marketing, not operations.

## Tier your priorities with real examples

Define three or four priority levels, each with a response cadence and an update rhythm — and, critically, with examples from your own context:

- **P1: business stopped.** The customer cannot operate — production down, lockout, a deadline blocked. Fastest acknowledgment, frequent updates, a named owner.
- **P2: significant but workable.** A major capability broken with a workaround available. Same-day response, daily updates.
- **P3: questions and minor issues.** Scheduled within business hours, with an honest target measured in days.

Without examples, every customer marks their ticket urgent. With examples, triage becomes teachable to a new hire in a week — including a partner team, which matters when coverage extends beyond your walls through [customer service operations](/services/bpo-customer-support/customer-service-operations) support.

## Be honest about coverage

State plainly: hours per channel, languages, holidays, and what happens outside them. If evenings are covered by a partner through [our BPO and customer support service](/services/bpo-customer-support), say what that team can resolve directly and what waits for your specialists until morning. Customers forgive limits they were told about; they churn on limits they discover.

## The mechanics that make SLAs keepable

An SLA is keepable when the queue makes it easy:

1. **One shared queue** with clear ownership rules — no private inboxes where tickets go to die.
2. **Instant acknowledgment** on every channel, with the next step spelled out.
3. **Escalation timers** — when a tier's clock runs out, the system moves the ticket, so the customer's patience never has to.
4. **A weekly SLA review** — misses are analyzed for causes (staffing, process, unclear triage) without blame, and the SLA is adjusted in writing when reality changes.

## Plan for the weeks that break patterns

Holidays, peak season, a key person on leave — SLA misses cluster around predictable disruptions. Build the exceptions into the agreement: adjusted hours published in advance, a temporary triage message for the affected channels, and pre-agreed priority rules for what may slip (usually P3) and what may not (never P1). A team that plans its slow weeks keeps its word all year; a team that pretends the year is fifty-two identical weeks breaks its promise on schedule.

## Publish it internally first

The first audience for an SLA is your own team. Sales should know what they may promise. Delivery should know the clocks they are working against. Leadership should see the weekly numbers. A support SLA that only lives on a customer-facing page is a wish; when it lives in the operating rhythm — reviewed weekly, edited quarterly — it becomes what it should be: a promise your operation can actually keep.

## Renegotiate with yourself every quarter

An SLA is a contract with your own capacity. As volume grows, last year's same-day response may quietly become impossible. Better to fix the target, staff for it, or automate the routine layer than to miss silently — and changes go to customers before they would notice, never after.

Good SLAs are boring, published, measured, and slightly conservative. That is what makes them worth trusting. If support promises and reality have drifted apart in your company, [book a free consultation](/book) — designing support operations that keep their word is routine work for us.`,
  },

  // ------------------------------------------------------------------
  // INTEGRATIONS
  // ------------------------------------------------------------------
  {
    slug: "crm-integration-patterns-double-entry",
    title: "Your CRM should update itself: integration patterns that end double data entry",
    excerpt:
      "Copying data between your CRM, inbox, invoicing and spreadsheets wastes hours and corrupts records. Five integration patterns that keep systems in sync — and the mistakes that make syncs fail.",
    category: "Integrations",
    tags: "CRM, integrations, data quality",
    status: "PUBLISHED",
    seoTitle: "End Double Data Entry: CRM Integration Patterns",
    seoDescription:
      "Five integration patterns that keep your CRM, inbox and billing in sync — and the common mistakes that make integrations fail.",
    readMinutes: 6,
    publishedAt: "2025-11-18T09:00:00.000Z",
    content: `## Where double data entry comes from

Nobody chooses it. A tool gets adopted for a specific job — invoicing here, email marketing there, scheduling somewhere else — and each one keeps its own little island of data. Then a person becomes the bridge: copying leads from the inbox into the CRM, copying deals from the CRM into the invoice tool, copying statuses from the tracking sheet into the weekly report.

The human-API pattern has three costs: the hours themselves, the errors that creep in with every copy-paste, and the stale records that make everyone quietly stop trusting the CRM. The fix is not more discipline. It is making the systems talk, so people stop typing the same thing twice.

## Pattern 1: one source of truth per data type

Before any integration, decide who owns what. Contact identity, deal stages and activity history belong to the CRM. Invoices and payments belong to the billing tool. Stock lives in inventory. Every other system references those records instead of keeping its own editable copy.

Most sync problems are actually ownership problems. When two systems can both edit the same fact, you do not have an integration — you have a dispute.

## Pattern 2: capture once, at the front door

The cheapest data entry is the kind nobody does twice. Route every inbound source — web forms, email inquiries, phone logs — directly into the CRM with validation at the point of entry: correct phone formats, normalized company names, required fields enforced once, at the boundary.

A lead that arrives clean never needs cleaning. That principle drives [CRM integration](/services/technical-services-integrations/crm-integrations) work: every new capture channel gets wired in at the door rather than retyped at a desk.

## Pattern 3: update on events, not on schedules

Wherever it matters, sync should be triggered by events, not by a nightly batch. A deal moves to won, and the invoice draft, onboarding tasks and welcome email are created immediately. An appointment is booked, and the CRM record updates in seconds.

Event-driven updates feel like magic to the team precisely because they delete a recurring mental step — "now I have to also go and update...". The integrations that justify themselves fastest are the ones that remove a task nobody enjoyed.

## Pattern 4: reconcile with a report, not a person

Even good syncs drift: an API times out, a record is archived mid-flight, a field changes shape. Instead of asking someone to spot-check everything, run a nightly reconciliation that compares counts and key fields between systems and reports only the mismatches. Exceptions go into a short review queue; the majority that match are never touched by human hands again.

## Pattern 5: give every sync a failure path

A silent failure is worse than no integration, because people keep trusting data that stopped being true. Every connection needs three things: retries with backoff, an alert that reaches a named person, and a dead-letter list of records that failed so they can be processed deliberately.

An integration is not finished when the happy path works. It is finished when failures are visible and recoverable — that is the bar we hold in [our technical services and integrations work](/services/technical-services-integrations).

## The mistakes that sink integration projects

- **Two-way sync without conflict rules.** If both systems can edit the same field, define which write wins — or make one side read-only. Last-write-wins with no logging is how records quietly corrupt.
- **Free text where structure belongs.** A company entered three different ways across three tools cannot be matched reliably. Normalize once, at entry.
- **Integrating before cleaning.** Connecting two systems that both hold messy copies just automates the mess at scale. Clean first, then connect — the sequencing matters as much in a [data sync and migration](/services/technical-services-integrations/data-sync-migration) project as the code.
- **No owner.** Integrations are living systems: APIs change, fields get renamed. Give each one a named owner and a quarterly health check.

## Start with a copy-paste audit

Ask your team to note, for two weeks, every time they copy information from one tool into another. The list is usually short, embarrassing, and enormously clarifying. Take the top offender and wire it properly. Then the next.

Within a month or two, the CRM updates itself on the flows that matter — and the team's relationship with the data changes from maintenance to trust. If you would like that audit reviewed and the top syncs scoped, [book a free consultation](/book).`,
  },

  // ------------------------------------------------------------------
  // WEB DEVELOPMENT
  // ------------------------------------------------------------------
  {
    slug: "what-a-business-website-must-do",
    title: "What a business website must do in 2025 (beyond looking good)",
    excerpt:
      "A redesign that only changes how your site looks changes almost nothing about how it performs. The six jobs a business website actually has to do — and a thirty-minute audit to check yours.",
    category: "Web Development",
    tags: "business website, conversion, web development",
    status: "PUBLISHED",
    seoTitle: "What a Business Website Must Do Beyond Looking Good",
    seoDescription:
      "The six jobs a business website must do: answer questions fast, drive one clear action, prove credibility, load quickly, rank and stay maintainable.",
    readMinutes: 6,
    publishedAt: "2025-11-04T09:00:00.000Z",
    content: `## Your website is an employee, not a brochure

The framing changes how you judge it. Your website talks to more prospects than any person on your team, works every hour, and never asks for feedback. Evaluate it like an employee: what is the job description, and is the work getting done? Redesigns that only change how a site looks almost always fail that test — the new site photographs beautifully and still answers nobody's questions.

Here are the six jobs a business website has to do, roughly in order.

## Job 1: answer the visitor's actual questions — fast

A first-time visitor needs three things within seconds: what you do, who it is for, and why it is credible. Then they need depth on demand. That means service pages that state plainly what is included, how the process works, and what happens after first contact — the standard we hold [business website projects](/services/website-development/business-websites) to.

If your homepage is a mood and your services are three vague paragraphs, the visitor goes back to the search results and chooses the competitor who explained themselves.

## Job 2: make the next step obvious and cheap

Every page needs one primary action — book a consultation, request a quote, start an order — repeated where the decision happens. Forms should ask for exactly what is needed to respond usefully, nothing more. And a contact page must never be a dead end: a phone number, a booking option, an email.

The measure is simple: from any page, can a motivated buyer act in under ten seconds?

## Job 3: prove you are real

Credibility is built with specificity, not superlatives. Describe your process with real steps. Name the standards you hold. Explain who you are and how you work. If you have genuine testimonials or results you can stand behind, show them honestly — and never invent them; sophisticated buyers can smell placeholder proof, and it costs more trust than it buys. An FAQ that answers real objections does more for credibility than any badge wall.

## Job 4: be fast and legible on a phone

Most first visits happen on a phone, often on a mediocre connection. The basics are non-negotiable: compressed images, minimal blocking scripts, readable type sizes, tap-friendly buttons, and the primary action within thumb reach. A beautiful site that takes eight seconds to become usable is leaking exactly the visitors it was redesigned to impress.

## Job 5: be found for the things you sell

Search visibility is structural, not cosmetic: one focused page per service, one per meaningful industry or location, descriptive titles, internal links between related pages, and content that answers the questions buyers actually type. A [well-planned landing page](/services/website-development/landing-pages) for a specific offer will outperform a gorgeous homepage for that query every time.

This architecture is a core deliverable of [our website development service](/services/website-development) — not an afterthought once the design is approved.

## Job 6: be maintainable

A site nobody can edit decays the day it ships. Someone on your team should be able to update text, add a service note, publish a role — without a developer ticket. Analytics should answer owner questions: which pages produce inquiries, where do people leave, what do they search for. And the unglamorous floor — SSL, backups, updates — needs a named owner too.

## A thirty-minute audit you can run today

- Show your homepage to someone outside your industry for five seconds. Can they say what you do and for whom?
- Open your site on a phone, on mobile data. How many taps to your primary action?
- Read your three most important service pages. Do they answer: what is included, how it works, what happens next?
- Search the way a customer would describe your main service. Do you appear? Does a page of yours answer that phrasing?
- Can you edit the site yourself, today, without help?

Every no is a work item — and none of them is about colors. Score your site on the six jobs, prioritize the failures, and design decisions become much easier: aesthetics serve the jobs, never the reverse.

If your audit turns up more gaps than an afternoon can fix, that is normal — and it is exactly the kind of prioritization we do with owners before any redesign. [Book a free consultation](/book) and bring your list.`,
  },
  {
    slug: "website-redesign-redirect-checklist",
    title: "Redesigning without losing your search visibility: the redirect checklist",
    excerpt:
      "Most redesigns lose search traffic not because the new site is worse, but because old addresses were abandoned. The redirect and migration checklist to run before, during and after launch.",
    category: "Web Development",
    tags: "website redesign, redirects, migration",
    status: "DRAFT",
    readMinutes: 6,
    content: `## Why rankings vanish after a redesign

The pattern is familiar: a company launches a handsome new website, and within weeks organic traffic sags. The new site is usually fine. What broke is continuity — pages that had earned positions were renamed, moved or deleted; old links now land on error pages; titles and content that search engines had learned to match with queries were rewritten wholesale.

Search visibility is memory. A redesign that discards URLs forces that memory to be rebuilt from zero. All of it is preventable with a checklist run before, during and after launch.

## Before you design anything: inventory every URL

You cannot preserve what you have not listed. Crawl the existing site and export every URL with its title, meta description and — where your analytics allow — its visits and inbound links. Flag three categories:

- **Pages that earn visits.** These must survive the redesign in a recognizable form.
- **Pages with valuable inbound links.** Even low-traffic pages can carry authority; their addresses matter.
- **Redundant or thin pages.** Candidates for consolidation, with redirects to the closest surviving equivalent.

## Map old to new, one-to-one

For every surviving URL, decide its new home and create a permanent redirect from the old address. The rules that matter:

1. **One-to-one wherever possible.** An old service page should land on the new service page, never on the homepage. Redirecting everything to the homepage is the most common and most costly redirect mistake — visitors bounce, and search engines treat the mapping as junk.
2. **Redirect to the closest equivalent,** not the prettiest page. If two old pages merge into one, both redirect to the merged page.
3. **Keep working URL structures** unless there is a strong reason to change them. Every unchanged URL is one that needs no redirect at all.

## Be conservative with content that ranks

A redesign is the wrong moment to experiment with pages that already perform. Preserve page titles, meta descriptions and the substance of ranking content unless you have a specific, measurable reason to change them. New designs can restyle; successful pages should keep saying whatever made them useful. When a rewrite is unavoidable, keep the core questions answered: what it is, who it is for, what it includes, what happens next.

## Staging is where the mistakes are cheap

Before launch, on the staging site:

- Test every planned redirect against the full list — not a sample.
- Crawl the staging domain for broken internal links.
- Compare titles and meta descriptions old versus new, page by page, and sign off on every change.
- Check canonical tags, robots rules and sitemap generation.

This is standard practice in [our website redesign process](/services/website-development/website-redesigns) — the checklist is boring precisely so the launch does not have to be.

## Launch week

- Deploy redirects before the new pages go live, and test the twenty most valuable URLs by hand.
- Submit the new sitemap in Search Console; watch coverage and 404 reports daily.
- Make sure internal links point directly at the new URLs, not through redirect chains.
- Fix 404s as they appear in server logs — real visitors are the best crawler.
- Monitor rankings and organic traffic daily for two weeks. Small dips are normal; step changes need a same-week fix.

## After the dust settles

Two habits keep the migration healthy. First, update the links you control outside the site — partner listings, social profiles, email signatures and templates — so they stop leaning on redirects. Second, watch the search queries that bring people in: if pages that used to answer a query now merely redirect to a broader one, that is a signal to rebuild the specific page rather than accept the loss.

Keep the redirect map forever. Redirects are not scaffolding to remove — bookmarks, documents and links accumulated over years will keep knocking on old addresses. And when the next redesign comes around, the map becomes the inventory that starts the process.

Handled this way, a redesign is an upgrade search engines can follow, not a fire they must rediscover you from. If search visibility is the asset you are worried about protecting, [book a free consultation](/book) — migration safety is built into how we approach [website development](/services/website-development).`,
  },
];
