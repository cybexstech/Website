// ---------------------------------------------------------------------------
// Demo registry — powers /work and links to the five interactive demo sites.
// All demo brands are FICTIONAL concept projects and must always be presented
// as such (never as clients).
// ---------------------------------------------------------------------------

export type DemoProject = {
  slug: "perfume" | "automotive" | "business-incubator" | "footwear" | "masala";
  brand: string;
  title: string;
  category: string;
  year: string;
  description: string;
  highlights: string[];
  image: string;
  accent: string; // preview accent color
  href: string;
};

export const DEMO_PROJECTS: DemoProject[] = [
  {
    slug: "perfume",
    brand: "Maison Élore",
    title: "Maison Élore — Luxury Fragrance",
    category: "Luxury E-commerce",
    year: "2024",
    description:
      "An editorial fragrance house concept with product storytelling, scent-note exploration and a refined product gallery.",
    highlights: ["Editorial art direction", "Scent-note explorer", "Product gallery & details"],
    image: "/demo-assets/perfume/hero.jpg",
    accent: "#B49B6C",
    href: "/demos/perfume",
  },
  {
    slug: "automotive",
    brand: "Aurion",
    title: "Aurion — Electric Hyper GT",
    category: "Automotive",
    year: "2024",
    description:
      "A cinematic automotive concept with model comparison, a live configurator feel and technical specification storytelling.",
    highlights: ["Model selector", "Spec highlight counters", "Dark cinematic UI"],
    image: "/demo-assets/automotive/hero.jpg",
    accent: "#C6FF3E",
    href: "/demos/automotive",
  },
  {
    slug: "business-incubator",
    brand: "Northbeam",
    title: "Northbeam — Startup Incubator",
    category: "Institutional",
    year: "2025",
    description:
      "A credible incubator presence with program discovery, cohort information and a multi-step application journey concept.",
    highlights: ["Program finder", "Multi-step application flow", "Cohort showcase"],
    image: "/demo-assets/incubator/hero.jpg",
    accent: "#1E5C3F",
    href: "/demos/business-incubator",
  },
  {
    slug: "footwear",
    brand: "SOLSTICE",
    title: "SOLSTICE — Footwear Store",
    category: "Fashion E-commerce",
    year: "2024",
    description:
      "An expressive footwear store concept with filtering, size selection and a demonstrative cart experience.",
    highlights: ["Filterable catalog", "Size selection", "Demo cart drawer"],
    image: "/demo-assets/footwear/hero.jpg",
    accent: "#FF4D2E",
    href: "/demos/footwear",
  },
  {
    slug: "masala",
    brand: "Garam Theory",
    title: "Garam Theory — Spice House",
    category: "Food & Beverage",
    year: "2025",
    description:
      "A rich spice brand concept with product storytelling, heat-level exploration and recipe-inspired discovery.",
    highlights: ["Heat-level guide", "Blend discovery", "Recipe pairings"],
    image: "/demo-assets/masala/hero.jpg",
    accent: "#C2410C",
    href: "/demos/masala",
  },
];

export function getDemo(slug: string): DemoProject | undefined {
  return DEMO_PROJECTS.find((d) => d.slug === slug);
}
