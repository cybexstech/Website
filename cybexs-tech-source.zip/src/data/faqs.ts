// General company FAQs for /faqs and reuse across pages.
// Answers stay honest: no guaranteed outcomes, no invented client proof.

export type GeneralFaq = { question: string; answer: string };

export const GENERAL_FAQS: GeneralFaq[] = [
  {
    question: "What does Cybexs Tech actually do?",
    answer:
      "We help businesses streamline operations, improve sales processes and create better digital experiences. In practice that means seven connected service areas: AI automation, AI voice agents, lead reactivation, sales & lead generation, BPO & customer support, technical services & integrations, and website development. You can start with one service or combine several.",
  },
  {
    question: "Are you a software company or a services company?",
    answer:
      "Both, deliberately. We implement technology — automation, integrations, websites — and we provide trained human teams for work that needs people, such as customer support and sales operations. Most clients benefit from that combination.",
  },
  {
    question: "How do engagements usually start?",
    answer:
      "With a free consultation. We discuss your current processes, tools and goals, and identify the two or three improvements with the best effort-to-impact ratio. From there you receive a concrete proposal — you decide what to proceed with.",
  },
  {
    question: "How much do your services cost?",
    answer:
      "It depends on scope: a focused automation, a support engagement and a full website have different footprints. We scope each project individually and explain the pricing clearly before any work starts. The initial consultation is free.",
  },
  {
    question: "How long does a typical project take?",
    answer:
      "Focused work — a single automation, an integration, a landing page — typically lands within weeks. Larger builds such as full websites or multi-workflow automation programs take longer. We agree a realistic timeline before starting and keep you updated.",
  },
  {
    question: "Do I need technical knowledge to work with you?",
    answer:
      "No. We explain everything in business terms, handle the technical implementation, and provide documentation and training. One point of contact on your side is enough.",
  },
  {
    question: "Which tools and regions do you work with?",
    answer:
      "We work with mainstream business tools (CRMs, e-commerce platforms, calendars, ERPs with APIs) and serve international clients in English. Specific tool and regional compliance questions are assessed during scoping.",
  },
  {
    question: "What happens after a project finishes?",
    answer:
      "Everything we build is documented and handed over — you own it. If you want, we offer ongoing support and improvement plans, but there is no lock-in requirement.",
  },
  {
    question: "Is the consultation really free?",
    answer:
      "Yes. The first consultation call is free and comes with no obligation. We use it to understand your situation and tell you honestly whether and how we can help.",
  },
  {
    question: "Are the projects in your portfolio real client work?",
    answer:
      "No. The portfolio shows concept and demonstration projects built by our team to illustrate our design and engineering approach. The brands shown are fictional and clearly labeled as demos.",
  },
];
