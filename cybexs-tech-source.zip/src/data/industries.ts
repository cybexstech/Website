// ---------------------------------------------------------------------------
// Industries — problem-oriented content for /industries and /industries/[slug].
// Each entry must answer: what hurts in this industry, how our combined
// services address it, and what a first engagement looks like.
// ---------------------------------------------------------------------------

export type Industry = {
  slug: string;
  name: string;
  group: string;
  icon: string; // lucide icon key
  headline: string;
  summary: string;
  challenges: { title: string; description: string }[];
  solutions: { service: string; serviceSlug: string; description: string }[];
  firstStep: string;
  faqs: { question: string; answer: string }[];
};

export const INDUSTRIES: Industry[] = [
  {
    slug: "small-medium-businesses",
    name: "Small & Medium Businesses",
    group: "Business types",
    icon: "Building2",
    headline: "Enterprise-grade operations for teams that do everything.",
    summary:
      "SMBs rarely have spare staff for admin, follow-up or IT projects. We bring automation, support and web capability that let a smaller team operate like a larger one.",
    challenges: [
      { title: "Everyone wears five hats", description: "Owners and staff juggle sales, service, admin and operations — repetitive work eats the day." },
      { title: "Follow-up falls through cracks", description: "Inquiries and quotes go unanswered when the team is busy, and revenue quietly leaks." },
      { title: "Tools exist, nothing connects", description: "Email, spreadsheet, invoicing and CRM all hold different versions of the truth." },
      { title: "Website underperforms", description: "An outdated site undermines credibility and converts poorly on mobile." },
    ],
    solutions: [
      { service: "AI Automation", serviceSlug: "ai-automation", description: "Automate quoting, invoicing prep, data entry and reporting so the team focuses on customers." },
      { service: "Lead Reactivation", serviceSlug: "lead-reactivation", description: "Re-engage the inquiries and quotes that went quiet — the fastest pipeline win available to most SMBs." },
      { service: "Technical Services", serviceSlug: "technical-services-integrations", description: "Connect the tools you already use so information moves without re-keying." },
      { service: "Website Development", serviceSlug: "website-development", description: "A modern, fast site that builds trust and captures inquiries properly." },
    ],
    firstStep:
      "A free consultation to identify the two or three highest-impact improvements for your size of team — most SMBs start with one automation and one follow-up workflow.",
    faqs: [
      { question: "Is this affordable for a small company?", answer: "Engagements are scoped to start small: a single well-chosen automation or workflow usually pays for itself in recovered hours. You can grow from there at your own pace." },
      { question: "Do we need technical staff to work with you?", answer: "No. We handle the technical side and hand over documentation and training. A single point of contact on your side is enough." },
    ],
  },
  {
    slug: "startups",
    name: "Startups",
    group: "Business types",
    icon: "Rocket",
    headline: "Move fast without building an ops team first.",
    summary:
      "Startups need to look credible, sell relentlessly and keep overhead minimal. We provide the operational and technical functions startups need — without full-time hires.",
    challenges: [
      { title: "No time for operations", description: "Founders are the sales, support and admin department — automation is always 'next month'." },
      { title: "Credibility gap", description: "A weak website or slow replies undermine an otherwise strong product story." },
      { title: "Pipeline depends on founder energy", description: "Outreach stops whenever shipping takes over." },
      { title: "Data scattered across tools", description: "Investor and board reporting takes days of manual assembly." },
    ],
    solutions: [
      { service: "Sales & Lead Generation", serviceSlug: "sales-lead-generation", description: "A consistent outreach engine that keeps the pipeline moving while the team builds." },
      { service: "Website Development", serviceSlug: "website-development", description: "A site that matches product ambition and converts visitors into conversations." },
      { service: "AI Automation", serviceSlug: "ai-automation", description: "Automate onboarding, reporting and internal busywork from day one." },
      { service: "BPO & Customer Support", serviceSlug: "bpo-customer-support", description: "Flexible support coverage that scales with signups, not headcount." },
    ],
    firstStep:
      "A free consultation focused on which single system — pipeline, support or website — will most accelerate your next stage.",
    faqs: [
      { question: "Can you work with our pace of change?", answer: "Yes — we scope in short cycles so deliverables land within weeks and adapt as your product and positioning evolve." },
      { question: "Do you require long contracts?", answer: "No. Work is scoped per project or per month, so you can adjust as your stage changes." },
    ],
  },
  {
    slug: "manufacturing",
    name: "Manufacturing",
    group: "Industry verticals",
    icon: "Factory",
    headline: "Fewer manual handoffs between quote, order and delivery.",
    summary:
      "Manufacturers run on documents: RFQs, purchase orders, delivery notes, invoices. We automate the paperwork layer and connect the systems around production.",
    challenges: [
      { title: "RFQ and quote backlog", description: "Quote preparation is manual and slow, and slow quotes lose orders." },
      { title: "Document-heavy order handling", description: "Order details arrive by email and PDF and are re-keyed into systems." },
      { title: "Distributor communication is ad hoc", description: "Updates, catalogs and availability questions consume sales time." },
      { title: "Disconnected systems", description: "ERP, accounting and spreadsheets each hold partial data." },
    ],
    solutions: [
      { service: "Document & Data Processing", serviceSlug: "ai-automation/document-data-processing", description: "Extract order and RFQ data from emails and PDFs directly into your systems." },
      { service: "Technical Services", serviceSlug: "technical-services-integrations", description: "Integrate ERP, accounting and e-commerce so stock and order data stay aligned." },
      { service: "Sales & Lead Generation", serviceSlug: "sales-lead-generation", description: "Structured distributor prospecting and reactivation in new regions." },
      { service: "BPO & Support", serviceSlug: "bpo-customer-support", description: "Back-office processing capacity for catalogs, orders and documentation." },
    ],
    firstStep:
      "A free consultation mapping one document flow end to end — most manufacturers see the biggest immediate win in RFQ or order intake.",
    faqs: [
      { question: "Do you understand ERP environments?", answer: "We work with your existing ERP through its APIs, exports or vendor-supported integration options, and assess feasibility honestly before committing." },
      { question: "Can you handle sensitive commercial documents?", answer: "Yes — access is limited to scope, handled under confidentiality agreements with secure credential management." },
    ],
  },
  {
    slug: "clinics",
    name: "Clinics & Healthcare Practices",
    group: "Industry verticals",
    icon: "Stethoscope",
    headline: "A calmer front desk and fewer missed appointments.",
    summary:
      "Clinics lose hours to phone interruptions and no-shows. We automate scheduling, reminders and routine questions while keeping patient communication personal where it matters.",
    challenges: [
      { title: "Interrupted staff", description: "The phone interrupts patient care all day with questions that have standard answers." },
      { title: "No-shows and gaps", description: "Missed appointments waste clinical capacity that cannot be recovered." },
      { title: "Dormant patient base", description: "Patients due for follow-up or recall are not systematically contacted." },
      { title: "Outdated web presence", description: "Patients check online first; poor presentation and booking friction cost appointments." },
    ],
    solutions: [
      { service: "AI Voice Agents", serviceSlug: "ai-voice-agents", description: "Answer routine calls, capture requests and book appointments around the clock." },
      { service: "Appointment Rebooking", serviceSlug: "lead-reactivation/appointment-rebooking", description: "Reduce no-shows with reminders and easy rebooking flows." },
      { service: "Lead Reactivation", serviceSlug: "lead-reactivation", description: "Recall and follow-up campaigns for patients who requested information but never booked." },
      { service: "Website Development", serviceSlug: "website-development", description: "A clear, trustworthy site with services, team and easy appointment requests." },
    ],
    firstStep:
      "A free consultation reviewing your call patterns and no-show rate to identify where automation helps most — without compromising patient care.",
    faqs: [
      { question: "How do you handle patient privacy?", answer: "We design workflows to minimize personal data movement, support region-specific privacy requirements, and define retention rules with you. Voice agents can be restricted to non-clinical topics entirely." },
      { question: "Will this replace our receptionist?", answer: "No — it removes repetitive interruptions so your front desk can focus on patients in the room. Escalation to a human is always one step away." },
    ],
  },
  {
    slug: "ecommerce",
    name: "E-commerce",
    group: "Industry verticals",
    icon: "ShoppingCart",
    headline: "Support, catalog and marketing operations that scale with orders.",
    summary:
      "E-commerce growth multiplies tickets, updates and campaigns. We automate the repetitive layer and provide support capacity so service quality survives your best sales days.",
    challenges: [
      { title: "Support volume spikes", description: "Order status, returns and sizing questions flood in during promotions." },
      { title: "Catalog maintenance", description: "Products, stock and prices need constant updates across channels." },
      { title: "One-time buyers disappear", description: "Past customers are rarely re-engaged systematically." },
      { title: "Slow store, weak product pages", description: "Traffic arrives on mobile and leaves before the page settles." },
    ],
    solutions: [
      { service: "Customer Inquiry Processing", serviceSlug: "ai-automation/customer-inquiry-processing", description: "Automate order-status, shipping and returns answers with AI grounded in your policies." },
      { service: "BPO & Customer Support", serviceSlug: "bpo-customer-support", description: "Human support coverage that flexes with seasonal volume." },
      { service: "Lead Reactivation", serviceSlug: "lead-reactivation", description: "Re-engage past customers with relevant replenishment and launch campaigns." },
      { service: "E-commerce Websites", serviceSlug: "website-development/ecommerce-websites", description: "Fast, conversion-focused stores connected to your operations." },
    ],
    firstStep:
      "A free consultation analyzing your support ticket mix and repeat-purchase rate — the two numbers that reveal where automation pays first.",
    faqs: [
      { question: "Can you work with our platform (Shopify, WooCommerce, custom)?", answer: "Yes — we integrate through platform APIs and connect orders, customers and support data into unified workflows." },
      { question: "Can support cover our peak season?", answer: "Yes — capacity is planned around your sales calendar with defined SLAs during peak periods." },
    ],
  },
  {
    slug: "recruiting-agencies",
    name: "Recruiting Agencies",
    group: "Industry verticals",
    icon: "Users",
    headline: "Faster placements through responsive candidate handling.",
    summary:
      "Recruiting is a responsiveness business. We automate candidate communication, screening steps and pipeline follow-up so strong candidates are never lost to slow replies.",
    challenges: [
      { title: "Slow candidate replies", description: "Applications sit unanswered; candidates move on to faster agencies." },
      { title: "Manual screening coordination", description: "Scheduling, reminders and status updates consume recruiter hours." },
      { title: "Dormant candidate database", description: "Past candidates fit new roles but are never re-contacted." },
      { title: "Client acquisition is inconsistent", description: "BD happens in bursts between mandates." },
    ],
    solutions: [
      { service: "AI Automation", serviceSlug: "ai-automation", description: "Automate application intake, screening questionnaires and interview scheduling." },
      { service: "Lead Reactivation", serviceSlug: "lead-reactivation", description: "Reactivate past candidates for new mandates systematically." },
      { service: "Sales & Lead Generation", serviceSlug: "sales-lead-generation", description: "A consistent client-acquisition engine between placement waves." },
      { service: "AI Voice Agents", serviceSlug: "ai-voice-agents", description: "Capture candidate inquiries and pre-screen basics after hours." },
    ],
    firstStep:
      "A free consultation tracing one candidate journey from application to placement to find the delay points automation can remove.",
    faqs: [
      { question: "Will automation make our agency feel impersonal?", answer: "The opposite — automation removes the delays that feel impersonal. Screening and relationship steps stay human; only status updates and scheduling are automated." },
      { question: "Can you integrate with our ATS?", answer: "If your ATS has an API or export options, we integrate with it and assess feasibility during scoping." },
    ],
  },
  {
    slug: "hvac",
    name: "HVAC & Home Services",
    group: "Industry verticals",
    icon: "Wrench",
    headline: "Never miss an emergency call again.",
    summary:
      "HVAC businesses live on urgent calls and seasonal demand. We make sure every call is answered, bookings flow automatically, and past customers return for maintenance.",
    challenges: [
      { title: "Missed calls while on jobs", description: "Technicians on site can't answer; after-hours calls go to voicemail." },
      { title: "Emergency vs routine triage", description: "Urgent calls and routine bookings arrive mixed, causing scheduling chaos." },
      { title: "Seasonal demand swings", description: "Capacity is idle in off-season while peak season overflows." },
      { title: "One-off customers", description: "Maintenance contracts and repeat service are under-sold." },
    ],
    solutions: [
      { service: "AI Voice Agents", serviceSlug: "ai-voice-agents", description: "24/7 call answering with emergency escalation rules and automatic booking for routine work." },
      { service: "Lead Reactivation", serviceSlug: "lead-reactivation", description: "Seasonal maintenance reminders bring past customers back on schedule." },
      { service: "Website Development", serviceSlug: "website-development", description: "A fast local site with clear services, service areas and easy booking." },
      { service: "Sales & Lead Generation", serviceSlug: "sales-lead-generation", description: "Local commercial prospecting for maintenance contracts." },
    ],
    firstStep:
      "A free consultation reviewing missed-call rates and seasonal patterns — most HVAC businesses start with call coverage and maintenance reminders.",
    faqs: [
      { question: "Can it really distinguish emergencies?", answer: "Yes — you define what counts as urgent (no heat, gas smell, flooding). Emergency calls escalate to on-call staff immediately; everything else is booked or messaged normally." },
      { question: "What about after-hours availability?", answer: "Voice agents answer around the clock. You decide which hours book automatically and which escalate." },
    ],
  },
  {
    slug: "sales-organizations",
    name: "Sales-Driven Organizations",
    group: "Business types",
    icon: "Target",
    headline: "Give sellers more hours of selling time every week.",
    summary:
      "Sales teams lose their week to research, CRM admin and follow-up. We build the operational layer — research, sequences, automation, support — so sellers sell.",
    challenges: [
      { title: "Admin-heavy selling", description: "CRM updates, quotes and follow-ups consume seller hours." },
      { title: "Inconsistent prospecting", description: "Outreach stops when deals heat up; the pipeline drains later." },
      { title: "Unqualified meetings", description: "Calendars fill with calls that should never have been booked." },
      { title: "Stalled deals go quiet", description: "No system exists to revive pipeline that ages out." },
    ],
    solutions: [
      { service: "Sales Process Automation", serviceSlug: "sales-lead-generation/sales-process-automation", description: "CRM capture, task generation and quote templating on autopilot." },
      { service: "Lead Research & Qualification", serviceSlug: "sales-lead-generation/lead-research-qualification", description: "Researched, scored lists so effort lands on real fit." },
      { service: "Lead Reactivation", serviceSlug: "lead-reactivation", description: "Systematic revival of stalled and dormant pipeline." },
      { service: "BPO Sales Support", serviceSlug: "bpo-customer-support/sales-support", description: "Human back-office support for quotes, orders and CRM hygiene." },
    ],
    firstStep:
      "A free consultation measuring where seller hours actually go — the data usually surprises leadership.",
    faqs: [
      { question: "Do you work with our CRM?", answer: "Yes — we build inside your existing CRM (HubSpot, Pipedrive, Salesforce, Zoho and others) rather than replacing it." },
      { question: "How quickly can this start producing activity?", answer: "Research and sequence infrastructure typically goes live within the first weeks; the first booked meetings follow once sequences are running." },
    ],
  },
];

export const INDUSTRY_MAP: Record<string, Industry> = Object.fromEntries(
  INDUSTRIES.map((i) => [i.slug, i])
);

export function getIndustry(slug: string): Industry | undefined {
  return INDUSTRY_MAP[slug];
}
