// ---------------------------------------------------------------------------
// Service taxonomy — single source of truth for /services, service detail
// pages, subservice pages, navigation and form selectors.
// Keep copy concrete, consultative and free of guaranteed outcomes.
// ---------------------------------------------------------------------------

export type Subservice = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  bullets: string[];
  useCases: string[];
};

export type ServiceFaq = { question: string; answer: string };

export type Service = {
  slug: string;
  name: string;
  shortName: string;
  icon: string; // lucide icon key, mapped in components
  tagline: string;
  intro: string;
  description: string[];
  outcomes: { title: string; description: string }[];
  subservices: Subservice[];
  process: { step: string; title: string; description: string }[];
  faqs: ServiceFaq[];
  relatedSlugs: string[];
};

export const SERVICES: Service[] = [
  {
    slug: "ai-automation",
    name: "AI Automation",
    shortName: "AI Automation",
    icon: "Bot",
    tagline: "Put repetitive operational work on autopilot.",
    intro:
      "We design and implement AI-powered automation that removes repetitive manual work from your day-to-day operations — so your team spends time on customers and decisions, not copy-paste.",
    description: [
      "Most growing businesses lose hours every week to work that follows the same pattern every time: moving data between tools, responding to routine inquiries, preparing documents, updating spreadsheets and CRMs. AI automation addresses exactly this category of work.",
      "We start by mapping how work actually flows through your business — not how the org chart says it should. Then we identify the steps that are repetitive, rule-based, or language-heavy, and automate them with a combination of AI agents, workflow platforms, and clean integrations. Everything we build is designed to be monitored, measured, and adjusted as your business changes.",
      "Automation is not about removing people. It is about giving your team leverage: fewer errors, faster turnaround, and capacity to handle growth without proportional hiring.",
    ],
    outcomes: [
      { title: "Reduce manual effort", description: "Turn multi-step manual processes into supervised automations that run consistently in the background." },
      { title: "Respond faster", description: "Inquiries, documents and follow-ups are handled in minutes instead of hours." },
      { title: "Scale without busywork", description: "Handle higher volumes with the same team by removing the repetitive layer of operations." },
    ],
    subservices: [
      {
        slug: "business-process-automation",
        name: "Business Process Automation",
        tagline: "End-to-end automation of recurring internal processes.",
        description:
          "We take a specific recurring process — quoting, onboarding, reporting, order handling — and rebuild it as an automated workflow with clear triggers, steps, exception handling and human checkpoints where judgment matters.",
        bullets: [
          "Process discovery and documentation before any automation is built",
          "Automations across your existing tools (CRM, email, sheets, storage, billing)",
          "Exception handling: anything unusual is routed to a human, not silently dropped",
          "Monitoring and reporting so you can see what the automation does",
        ],
        useCases: [
          "A distributor turns quote requests into prepared quotations automatically",
          "An agency onboards new clients with automated document collection and task creation",
          "An operations team receives a daily generated report instead of assembling spreadsheets by hand",
        ],
      },
      {
        slug: "customer-inquiry-processing",
        name: "Customer Inquiry Processing",
        tagline: "AI-assisted handling of routine inbound questions.",
        description:
          "Routine inquiries — order status, availability, document requests, standard policy questions — are answered or prepared automatically using AI that understands your business content. Complex or sensitive cases are escalated to your team with full context.",
        bullets: [
          "Answers grounded in your actual policies, catalogs and documents",
          "Email, web form and chat as input channels",
          "Confidence-based routing: low certainty goes to a human",
          "Every automated reply is logged for review",
        ],
        useCases: [
          "An e-commerce store answers shipping and returns questions automatically",
          "A clinic handles appointment-related questions without front-desk interruption",
          "A B2B supplier prepares draft answers for technical pre-sales questions",
        ],
      },
      {
        slug: "document-data-processing",
        name: "Document & Data Processing",
        tagline: "Extract, structure and move information automatically.",
        description:
          "Invoices, purchase orders, forms, contracts and attachments carry information your systems need. We build extraction and validation pipelines that read documents, structure the data, validate it and deliver it where it belongs.",
        bullets: [
          "Document parsing for PDFs, emails, forms and scans",
          "Validation rules to catch missing or inconsistent data",
          "Direct delivery into your CRM, ERP, accounting or database",
          "Human review queue for low-confidence extractions",
        ],
        useCases: [
          "An accounting team processes supplier invoices with automatic ledger coding",
          "A logistics company extracts delivery details from unstructured email orders",
          "An HR team digitizes applicant documents into a structured pipeline",
        ],
      },
      {
        slug: "ai-workflow-orchestration",
        name: "AI Workflow Orchestration",
        tagline: "Multi-step AI agents coordinated across your stack.",
        description:
          "Some work needs several AI capabilities in sequence — read, research, decide, draft, update systems. We orchestrate AI agents into reliable workflows with guardrails, audit trails and clear ownership of each step.",
        bullets: [
          "Agent workflows with explicit steps, permissions and limits",
          "Human-in-the-loop approval for consequential actions",
          "Full audit trail of what the automation did and why",
          "Iterative improvement as edge cases are discovered",
        ],
        useCases: [
          "A sales ops team automates research and draft preparation for inbound leads",
          "A publishing team assembles weekly performance digests from multiple sources",
          "A support team auto-triages and routes tickets by topic and urgency",
        ],
      },
    ],
    process: [
      { step: "01", title: "Map", description: "We document how the work actually happens today, where time is lost, and what 'good' looks like." },
      { step: "02", title: "Design", description: "We design the automated workflow with clear triggers, rules, human checkpoints and failure modes." },
      { step: "03", title: "Build", description: "We implement and test the automation against real cases before it touches live operations." },
      { step: "04", title: "Operate", description: "We monitor, measure and refine. Automations are living systems, not one-off installs." },
    ],
    faqs: [
      {
        question: "What does AI automation actually mean in practice?",
        answer:
          "It means software that performs recurring tasks which previously needed a person: reading documents, moving data between tools, drafting replies, updating systems. The AI handles language and judgment-heavy steps; deterministic rules handle the rest. You keep oversight through monitoring and approval checkpoints.",
      },
      {
        question: "Which processes are a good fit for automation?",
        answer:
          "Processes that are repetitive, follow a recognizable pattern, and involve moving or transforming information — quotes, inquiries, onboarding, reporting, data entry. Processes requiring deep human judgment or regulatory sign-off are usually better served with human-in-the-loop designs.",
      },
      {
        question: "Do we need to replace our current tools?",
        answer:
          "No. In most projects we connect the tools you already use — CRM, email, spreadsheets, storage, billing — through APIs and automation platforms. Replacement is only recommended when a tool genuinely cannot support the workflow.",
      },
      {
        question: "How do you handle mistakes made by automated systems?",
        answer:
          "Every workflow is designed with exception handling: low-confidence cases are routed to a human instead of being executed. Actions are logged, and we review accuracy with you during the first weeks and adjust.",
      },
    ],
    relatedSlugs: ["technical-services-integrations", "ai-voice-agents"],
  },
  {
    slug: "ai-voice-agents",
    name: "AI Voice Agents",
    shortName: "Voice Agents",
    icon: "PhoneCall",
    tagline: "A capable first line for your business phone.",
    intro:
      "AI voice agents answer routine calls, capture the details that matter, and route anything sensitive to your team — so fewer calls are missed and your staff is not interrupted for every routine question.",
    description: [
      "Missed calls are missed business. But most inbound calls are routine: questions about hours, services, availability, directions or status. An AI voice agent answers these instantly, politely and consistently — at any volume, at any hour you choose.",
      "We configure voice agents around your actual business content: services, pricing guidelines, policies, scheduling rules. The agent answers routine questions, captures caller details, books or updates appointments where you allow it, and transfers complex or high-value calls to your team with a clear summary.",
      "Voice agents work alongside your people, not instead of them. You define exactly what the agent may do, what it must escalate, and how callers are treated. Every call is transcribed and summarized so nothing is lost.",
    ],
    outcomes: [
      { title: "Fewer missed calls", description: "Routine calls are answered immediately, including after hours if you enable it." },
      { title: "Protected staff time", description: "Your team handles conversations that need a human, not repetitive questions." },
      { title: "Structured call data", description: "Every call produces a transcript, summary and captured details in your systems." },
    ],
    subservices: [
      {
        slug: "ai-receptionist",
        name: "AI Receptionist",
        tagline: "A consistent, courteous first answer for every call.",
        description:
          "An AI receptionist greets callers, understands what they need, answers standard questions from your approved content, and routes or escalates appropriately — with your preferred tone and scripts.",
        bullets: [
          "Answers from your approved service, pricing and policy content",
          "Natural conversation with clear escalation paths",
          "Custom greetings, tone and fallback behavior",
          "Messages and caller details delivered to your inbox or CRM",
        ],
        useCases: [
          "A clinic answers routine questions while the front desk is with patients",
          "A service business captures caller requests during busy hours",
          "A studio handles booking-related questions outside office hours",
        ],
      },
      {
        slug: "inbound-call-handling",
        name: "Inbound Call Handling",
        tagline: "Capture, qualify and route calls by intent.",
        description:
          "Calls are answered, the caller's need and details are captured in a structured way, and the call is routed by rules you define — urgent, sales, support, or message-taking.",
        bullets: [
          "Intent detection and structured information capture",
          "Rule-based routing to people, teams or voicemail",
          "Overflow handling when your lines are busy",
          "Summaries and transcripts for every call",
        ],
        useCases: [
          "An HVAC company separates emergency calls from routine bookings automatically",
          "A recruiting agency captures candidate inquiries outside office hours",
          "A sales team receives qualified call summaries instead of raw messages",
        ],
      },
      {
        slug: "appointment-scheduling-calls",
        name: "Appointment Scheduling Calls",
        tagline: "Let callers book, reschedule or confirm by phone.",
        description:
          "Connected to your calendar rules, the voice agent offers real availability, books or moves appointments, sends confirmations, and reduces no-shows with automated reminders.",
        bullets: [
          "Real-time availability based on your calendar rules",
          "Booking, rescheduling and cancellation handling",
          "Automatic confirmations and reminders",
          "Escalation for special requests the agent cannot fulfill",
        ],
        useCases: [
          "A clinic lets patients book routine appointments by phone at any hour",
          "A consultancy reduces scheduling back-and-forth with automated booking",
          "A service company fills cancellation slots from a waiting list",
        ],
      },
      {
        slug: "after-hours-call-assistance",
        name: "After-Hours Call Assistance",
        tagline: "Professional coverage when the office is closed.",
        description:
          "Evening, weekend and holiday calls are answered professionally: urgent matters are escalated according to your rules, everything else is captured for follow-up the next business day.",
        bullets: [
          "Configurable schedules and urgency rules",
          "Emergency escalation to on-call staff where defined",
          "Complete overnight log with summaries each morning",
          "Consistent experience regardless of call volume",
        ],
        useCases: [
          "A property manager handles tenant emergencies after hours",
          "An e-commerce brand answers order-status questions overnight",
          "A clinic provides an answering layer for urgent patient questions",
        ],
      },
    ],
    process: [
      { step: "01", title: "Scope", description: "We define exactly which call types the agent handles, what it may do, and what always goes to a human." },
      { step: "02", title: "Configure", description: "We load your approved content, booking rules, escalation paths and brand tone." },
      { step: "03", title: "Rehearse", description: "We test with realistic calls — including difficult ones — before going live." },
      { step: "04", title: "Monitor", description: "We review transcripts and outcomes with you and tune behavior continuously." },
    ],
    faqs: [
      {
        question: "Will callers know they are speaking with an AI?",
        answer:
          "We recommend transparent introductions where legally required and advise honesty in all cases. The agent can introduce itself and transfer to a human on request — callers always have a path to a person.",
      },
      {
        question: "What happens if the voice agent cannot help?",
        answer:
          "It follows your escalation rules: transfer to a person, take a detailed message, or offer a callback. It never invents answers to questions outside its approved content.",
      },
      {
        question: "Can it book appointments in our existing calendar?",
        answer:
          "Yes, where your calendar or scheduling tool exposes usable availability and booking interfaces. We assess your current setup during scoping and confirm what is possible before implementation.",
      },
      {
        question: "Is call recording and transcription included?",
        answer:
          "Yes — every call produces a transcript and summary. You define retention rules, and we advise on informing callers in line with applicable regulations in your region.",
      },
    ],
    relatedSlugs: ["bpo-customer-support", "ai-automation"],
  },
  {
    slug: "lead-reactivation",
    name: "Lead Reactivation",
    shortName: "Reactivation",
    icon: "History",
    tagline: "Turn dormant contacts into renewed conversations.",
    intro:
      "Your existing contact list already contains people who once showed interest. We build compliant, well-crafted reactivation workflows that reopen conversations — without spamming or damaging your reputation.",
    description: [
      "Every business accumulates contacts that went quiet: quotes that were never answered, enquiries from months ago, prospects that stalled in the pipeline. Reaching this audience is one of the most efficient growth activities available — when it is done with relevance and care.",
      "We design reactivation campaigns around the reason contact lapsed and what would genuinely be useful now: an update, a relevant offer, a simpler next step. Sequences combine email, SMS where consented, and call tasks for your team — all measured, all compliant.",
      "We are strict about consent and communication compliance. We only work with lists you are permitted to contact, honor opt-outs automatically, and follow applicable anti-spam and data-protection rules for your regions. Reactivation is about renewing permission-based relationships, not blasting strangers.",
    ],
    outcomes: [
      { title: "Renewed conversations", description: "Dormant leads re-engaged with relevant, respectful follow-up." },
      { title: "More value from existing data", description: "Utilize the list you already paid to build, before spending on new acquisition." },
      { title: "Clean, compliant outreach", description: "Consent-aware sequences with automatic opt-out handling and full activity logs." },
    ],
    subservices: [
      {
        slug: "dormant-lead-follow-up",
        name: "Dormant Lead Follow-Up",
        tagline: "Systematic re-engagement of lapsed inquiries.",
        description:
          "We segment your dormant leads by origin, age and previous behavior, then run tailored follow-up sequences that acknowledge the gap and offer a clear, low-friction reason to continue the conversation.",
        bullets: [
          "Segmentation by source, service and staleness",
          "Personalized sequences instead of one generic blast",
          "Clear opt-out handling in every message",
          "Responses routed to your sales owner instantly",
        ],
        useCases: [
          "A clinic re-contacts patients who requested information but never booked",
          "A B2B supplier revives quotes that expired without a decision",
          "An agency restarts conversations with past project inquiries",
        ],
      },
      {
        slug: "lead-nurturing-sequences",
        name: "Lead Nurturing Sequences",
        tagline: "Stay useful until prospects are ready.",
        description:
          "Not every lead is ready now. Nurturing sequences deliver genuinely helpful content and check-ins on a sensible cadence, so your business stays present without pressuring anyone.",
        bullets: [
          "Content and cadence planned per audience segment",
          "Behavior-based branching (opened, clicked, replied)",
          "Hand-off to sales when intent signals appear",
          "Weekly performance review and iteration",
        ],
        useCases: [
          "A software consultancy nurtures a long evaluation cycle",
          "A manufacturer stays present with distributors between buying seasons",
          "A service firm educates new subscribers toward a first engagement",
        ],
      },
      {
        slug: "appointment-rebooking",
        name: "Appointment Rebooking Campaigns",
        tagline: "Bring no-shows and expiries back to the calendar.",
        description:
          "Missed appointments and expired offers are recovered through respectful reminder sequences with one-tap rebooking paths, connected directly to your calendar.",
        bullets: [
          "Automated reminder and rebooking flows",
          "Calendar-connected booking links",
          "Reminder cadence tuned per industry norms",
          "Escalation to a personal call for high-value cases",
        ],
        useCases: [
          "A clinic recovers missed appointments with two-tap rebooking",
          "A consultancy rebooks postponed discovery calls",
          "A service company fills freed slots from its own waiting list",
        ],
      },
      {
        slug: "crm-reactivation-workflows",
        name: "CRM Reactivation Workflows",
        tagline: "Make your CRM a living pipeline again.",
        description:
          "We clean and segment your CRM, define reactivation triggers, and build the workflows that keep pipeline stages moving — so old contacts resurface automatically instead of gathering dust.",
        bullets: [
          "Data cleanup and duplicate merging before any campaign",
          "Trigger-based reactivation rules inside your CRM",
          "Task creation for personal follow-up where it matters",
          "Reporting on reactivated pipeline value",
        ],
        useCases: [
          "A sales team gets automatic prompts when dormant deals age past a threshold",
          "An e-commerce brand re-engages past purchasers with relevant replenishment offers",
          "A B2B firm tags and revives stalled opportunities by reason",
        ],
      },
    ],
    process: [
      { step: "01", title: "Audit", description: "We review your list quality, consent status and past outreach to set a compliant baseline." },
      { step: "02", title: "Segment", description: "We group contacts by relevance and design a message per segment — never one blast for all." },
      { step: "03", title: "Launch", description: "Sequences run with automatic opt-out handling, tracking and reply routing." },
      { step: "04", title: "Refine", description: "We review responses with you weekly and sharpen messages, cadence and offers." },
    ],
    faqs: [
      {
        question: "Is reactivating old leads legal?",
        answer:
          "It depends on your region, the channel and the consent you hold — rules like GDPR, CAN-SPAM and CASL differ. We audit your list first, only proceed where contact is permitted, include opt-outs everywhere, and document the basis for each campaign.",
      },
      {
        question: "How is this different from spamming our list?",
        answer:
          "Spam is irrelevant, high-pressure and untargeted. Reactivation done properly is segmented, relevant, respectful in cadence, and easy to opt out of. Quality of the match matters more than volume.",
      },
      {
        question: "What results can we expect?",
        answer:
          "We do not promise specific numbers. Outcomes depend on list quality, past relationship and offer. We set baseline metrics before launch and report honestly against them.",
      },
      {
        question: "Which channels do you use?",
        answer:
          "Email is the backbone; SMS and messaging apps are used only where you hold proper consent; call tasks are created for your team where a personal touch fits. Channel mix is agreed per campaign.",
      },
    ],
    relatedSlugs: ["sales-lead-generation", "ai-automation"],
  },
  {
    slug: "sales-lead-generation",
    name: "Sales & Lead Generation",
    shortName: "Lead Gen",
    icon: "TrendingUp",
    tagline: "A steadier, better-qualified flow of opportunities.",
    intro:
      "We build the research, outreach and follow-up system behind a healthier sales pipeline — combining human judgment with automation so your team talks to better prospects, more often.",
    description: [
      "A healthy pipeline needs three things working together: well-researched prospect lists, outreach worth replying to, and follow-up that never forgets. Most teams are strong in one area and weak in another. We build the whole system.",
      "We start by defining who your best customers actually are and where similar companies can be found. Then we build the prospecting engine: researched lists, personalized outreach sequences, qualification criteria, and appointment setting that hands your salespeople conversations worth having.",
      "Automation handles the research, tracking and follow-up cadence; people handle the parts of selling that require judgment and trust. The result is a pipeline that stays active without burning out your team.",
    ],
    outcomes: [
      { title: "Better-qualified conversations", description: "Prospects are researched and pre-qualified before they reach your calendar." },
      { title: "Consistent pipeline activity", description: "Outreach and follow-up run on schedule, regardless of how busy the week gets." },
      { title: "Visible sales operations", description: "Every touchpoint is tracked, so you can see what works and what stalls." },
    ],
    subservices: [
      {
        slug: "lead-research-qualification",
        name: "Lead Research & Qualification",
        tagline: "Lists built on fit, not on volume.",
        description:
          "We research and qualify prospects against your ideal customer profile — company fit, role relevance, signals of need — and deliver clean, enriched lists your team can trust.",
        bullets: [
          "Ideal Customer Profile (ICP) definition with your input",
          "Researched, verified and enriched prospect data",
          "Qualification scoring agreed with your sales team",
          "Delivered into your CRM, not a spreadsheet graveyard",
        ],
        useCases: [
          "A B2B service firm builds a targeted list of matching companies",
          "A manufacturer identifies distributors in a new region",
          "A SaaS company scores inbound signups before sales time is spent",
        ],
      },
      {
        slug: "prospecting-workflows",
        name: "Prospecting Workflows",
        tagline: "Outreach sequences people actually reply to.",
        description:
          "We design and run multi-step outreach across email and professional-network channels — researched, personalized, compliant — with follow-up that continues politely until it is time to stop.",
        bullets: [
          "Sequence design: message, cadence, stop conditions",
          "Personalization grounded in real research, not mail-merge gimmicks",
          "Reply handling and routing to the right owner",
          "Compliance with regional outreach rules",
        ],
        useCases: [
          "A consultancy books discovery calls with decision makers in a new vertical",
          "An agency fills its pipeline between referral waves",
          "A supplier opens conversations with retail chains",
        ],
      },
      {
        slug: "appointment-setting",
        name: "Appointment Setting",
        tagline: "Warm handoffs to your calendar, not cold leads.",
        description:
          "Interested prospects are guided to a booked meeting with the right person on your team — with context prepared so the first conversation starts at a useful level.",
        bullets: [
          "Qualification questions before time is booked",
          "Direct calendar booking with routing rules",
          "Briefing notes attached to every appointment",
          "No-show reduction with reminders and rebooking",
        ],
        useCases: [
          "A software company hands qualified demos to account executives",
          "A professional services firm fills partner calendars with qualified calls",
          "A clinic books consults for a new treatment line",
        ],
      },
      {
        slug: "sales-process-automation",
        name: "Sales Process Automation",
        tagline: "Remove the admin layer from selling.",
        description:
          "CRM updates, follow-up reminders, proposal preparation, pipeline hygiene — the operational side of sales is automated so sellers spend their hours selling.",
        bullets: [
          "Automatic CRM capture of emails, meetings and outcomes",
          "Task generation from pipeline triggers",
          "Proposal and quote document templating",
          "Pipeline dashboards your leadership actually reads",
        ],
        useCases: [
          "A sales team stops manual CRM data entry entirely",
          "A founder gets automated reminders on every aging opportunity",
          "A sales ops team generates quotes from CRM records in one click",
        ],
      },
    ],
    process: [
      { step: "01", title: "Define", description: "We define your ICP, offer positioning and qualification criteria with your sales leadership." },
      { step: "02", title: "Build", description: "We build the research, outreach and follow-up engine — tools, sequences and tracking." },
      { step: "03", title: "Run", description: "Campaigns run with ongoing personalization and reply handling; your team receives booked conversations." },
      { step: "04", title: "Improve", description: "We review reply rates, meeting quality and pipeline movement — and adjust continuously." },
    ],
    faqs: [
      {
        question: "Do you replace our sales team?",
        answer:
          "No. We build and operate the system that feeds your team: research, outreach, qualification and booked meetings. Your people close — with better preparation and less admin.",
      },
      {
        question: "Is cold outreach acceptable for our industry?",
        answer:
          "It depends on your region, channel and audience. We review applicable rules (GDPR, CAN-SPAM, CASL and local equivalents) before any campaign and design compliant sequences. Where cold outreach is inappropriate, we focus on inbound and referral systems.",
      },
      {
        question: "What do you need from us to start?",
        answer:
          "A clear picture of who your best customers are, access to your CRM, and one point person for weekly reviews. We handle the rest.",
      },
      {
        question: "How do you measure success?",
        answer:
          "With pipeline metrics agreed upfront: qualified conversations, booked meetings, pipeline value created — reported transparently, without inflated promises.",
      },
    ],
    relatedSlugs: ["lead-reactivation", "ai-automation"],
  },
  {
    slug: "bpo-customer-support",
    name: "BPO & Customer Support",
    shortName: "BPO & Support",
    icon: "Headset",
    tagline: "Dependable human support, strengthened by technology.",
    intro:
      "Trained people handle your customer conversations — supported by automation and clear processes, so quality stays high while your costs stay predictable.",
    description: [
      "Customer support is where your brand is experienced directly. We provide trained support teams that represent your business professionally across email, chat and phone — with processes, quality standards and reporting that keep quality measurable.",
      "We are pragmatic about technology: automation absorbs the repetitive layer (order status, FAQs, routing), while humans handle conversations that need empathy, judgment and negotiation. This combination typically improves both speed and customer satisfaction compared with either extreme.",
      "Engagements start small — a defined scope, clear SLAs, weekly quality reviews — and scale as trust grows. You keep full visibility through reporting and recorded interactions.",
    ],
    outcomes: [
      { title: "Consistent coverage", description: "Customer inquiries answered on time, every business day, without staffing stress." },
      { title: "Predictable costs", description: "Support capacity that flexes with volume instead of fixed overhead." },
      { title: "Measured quality", description: "SLAs, QA reviews and satisfaction tracking — reported to you transparently." },
    ],
    subservices: [
      {
        slug: "inbound-customer-support",
        name: "Inbound Customer Support",
        tagline: "Professional answers across email, chat and phone.",
        description:
          "Your customers reach trained support agents who know your products, policies and tone — resolving issues on first contact wherever possible and escalating cleanly when not.",
        bullets: [
          "Onboarding on your products, policies and brand voice",
          "Email, chat and voice channels with clear SLAs",
          "First-contact resolution focus with clean escalation paths",
          "Weekly quality assurance reviews",
        ],
        useCases: [
          "An e-commerce brand outsources order and returns support",
          "A software company adds coverage for peak-season tickets",
          "A clinic extends patient communication beyond front-desk hours",
        ],
      },
      {
        slug: "customer-service-operations",
        name: "Customer Service Operations",
        tagline: "The process layer behind great support.",
        description:
          "We design and operate the support function itself: ticket workflows, response templates, knowledge bases, QA scorecards and reporting — so quality does not depend on individual heroics.",
        bullets: [
          "Support playbook and knowledge base creation",
          "Ticket routing, prioritization and SLA design",
          "QA scorecards and coaching loops",
          "Monthly reporting on volume, quality and trends",
        ],
        useCases: [
          "A growing retailer formalizes support for the first time",
          "A B2B firm introduces SLAs for key accounts",
          "A startup builds its support foundation before scaling",
        ],
      },
      {
        slug: "sales-support",
        name: "Sales Support",
        tagline: "Keep opportunities moving between meetings.",
        description:
          "Quotes, order processing, account updates, follow-ups and documentation — handled by our team inside your systems, so your sellers stay in front of customers.",
        bullets: [
          "Quote and order preparation in your CRM",
          "Follow-up tracking and reminders",
          "Account record maintenance and cleanup",
          "Confidential handling under clear agreements",
        ],
        useCases: [
          "A distributor's sales team hands off order admin entirely",
          "A services firm gets proposal documents prepared same-day",
          "A manufacturer keeps CRM records current without seller effort",
        ],
      },
      {
        slug: "outsourced-back-office",
        name: "Outsourced Business Processes",
        tagline: "Reliable execution of defined back-office work.",
        description:
          "Data entry, catalog updates, document preparation, reporting packs — defined, repeatable processes executed by our trained team with quality checks and clear turnaround times.",
        bullets: [
          "Process documentation with QA checkpoints",
          "Turnaround-time commitments per task type",
          "Secure access handling and confidentiality agreements",
          "Volume-based reporting",
        ],
        useCases: [
          "An e-commerce operation maintains catalog and inventory data",
          "A finance team outsources invoice preparation steps",
          "An agency delegates reporting pack assembly",
        ],
      },
    ],
    process: [
      { step: "01", title: "Scope", description: "We define channels, hours, SLAs, quality standards and reporting with you." },
      { step: "02", title: "Onboard", description: "Our team is trained on your products, systems, tone and escalation rules." },
      { step: "03", title: "Operate", description: "Support runs with defined coverage; automation absorbs the repetitive layer." },
      { step: "04", title: "Review", description: "Weekly QA and monthly reporting keep quality visible and improving." },
    ],
    faqs: [
      {
        question: "Will customers know support is outsourced?",
        answer:
          "Our agents work under your brand, with your tone and processes. Transparency requirements differ by market — we follow your preference and applicable rules. What matters to customers is fast, competent help.",
      },
      {
        question: "How do you protect our customer data?",
        answer:
          "Access is limited to what the scope requires, under confidentiality agreements, with secure credential handling. We support additional requirements such as NDAs and region-specific data-handling rules.",
      },
      {
        question: "Can you work in our tools and time zone?",
        answer:
          "Yes — we operate inside your existing systems and align coverage hours to your customer base. Specific hours and channels are agreed during scoping.",
      },
      {
        question: "What happens if quality drops?",
        answer:
          "QA scorecards catch issues early. Weekly reviews with your point of contact address them directly, and persistent issues have documented remediation paths in the SLA.",
      },
    ],
    relatedSlugs: ["ai-voice-agents", "ai-automation"],
  },
  {
    slug: "technical-services-integrations",
    name: "Technical Services & Integrations",
    shortName: "Integrations",
    icon: "PlugZap",
    tagline: "Make your business systems talk to each other.",
    intro:
      "When your tools don't connect, work falls through the gaps. We build the integrations, data flows and internal tools that make your systems operate as one business.",
    description: [
      "Most operational friction lives between systems: the CRM that doesn't know what the website captured, the store that doesn't update accounting, the spreadsheet that replaces a missing integration. We close those gaps properly.",
      "We assess your current stack, design the data flows that should exist, and implement them with well-built APIs, middleware and clear error handling. Where no tool fits, we build custom internal tools — scoped pragmatically, documented thoroughly.",
      "Everything we deliver is built to be maintainable: clear documentation, monitored flows, and handover training. Integrations should outlive the project that created them.",
    ],
    outcomes: [
      { title: "One connected operation", description: "Data flows between systems automatically, accurately and in near real time." },
      { title: "No more re-keying", description: "Information entered once is available everywhere it is needed." },
      { title: "Tools that fit your process", description: "Custom internal tools where off-the-shelf software falls short." },
    ],
    subservices: [
      {
        slug: "api-integrations",
        name: "API Integrations",
        tagline: "Reliable connections between your platforms.",
        description:
          "We design and implement API integrations between your business systems — with authentication, error handling, retries and monitoring handled properly from day one.",
        bullets: [
          "Integration design before code: data flow, failure modes, ownership",
          "Robust error handling, retries and alerting",
          "Rate limits, webhooks and queuing handled correctly",
          "Documentation your team can maintain",
        ],
        useCases: [
          "A store's orders flow into accounting and fulfillment automatically",
          "A marketing platform syncs leads into the CRM in real time",
          "A booking system notifies operations through multiple channels",
        ],
      },
      {
        slug: "crm-integrations",
        name: "CRM Integrations",
        tagline: "A CRM that reflects reality automatically.",
        description:
          "We connect your CRM to your website, email, telephony and billing — so records are complete and current without anyone maintaining them by hand.",
        bullets: [
          "Website and form capture mapped to CRM records",
          "Email, call and meeting activity logged automatically",
          "Deduplication and data-quality rules",
          "Segmentation and reporting built on clean data",
        ],
        useCases: [
          "A sales team trusts its pipeline because the CRM updates itself",
          "Marketing and sales finally share one lead definition",
          "Leadership reports are generated from live CRM data",
        ],
      },
      {
        slug: "data-sync-migration",
        name: "Data Transfer & Synchronization",
        tagline: "Move and sync data safely between systems.",
        description:
          "Migrations, one-time transfers and ongoing synchronization — executed with validation, reconciliation and rollback plans, so nothing is lost or doubled along the way.",
        bullets: [
          "Field mapping and validation before any migration",
          "Trial runs with reconciliation reports",
          "Ongoing sync with conflict resolution rules",
          "Backup and rollback planning",
        ],
        useCases: [
          "A company migrates from spreadsheets to a real ERP",
          "Two merged businesses consolidate their customer data",
          "An ongoing sync keeps e-commerce and inventory aligned",
        ],
      },
      {
        slug: "custom-internal-tools",
        name: "Custom Internal Tools",
        tagline: "Practical software for the gaps off-the-shelf can't fill.",
        description:
          "When your process doesn't match any SaaS product, we build focused internal tools — dashboards, approval apps, calculators, admin panels — sized to the actual need.",
        bullets: [
          "Scoped to the real workflow, not enterprise bloat",
          "Built on maintainable, mainstream technology",
          "Authentication and permissions from the start",
          "Handover documentation and training included",
        ],
        useCases: [
          "An operations team gets a custom approval dashboard",
          "A sales team uses a quoting calculator with pricing rules",
          "A clinic manages internal referrals in a simple secure app",
        ],
      },
    ],
    process: [
      { step: "01", title: "Assess", description: "We map your systems, data flows and the gaps causing manual work." },
      { step: "02", title: "Design", description: "Integration architecture is documented: data flow, failure handling, security and ownership." },
      { step: "03", title: "Implement", description: "We build, test against real data and deploy with monitoring in place." },
      { step: "04", title: "Handover", description: "Documentation, monitoring dashboards and training so your team can operate confidently." },
    ],
    faqs: [
      {
        question: "Our tools are unusual. Can you still integrate them?",
        answer:
          "Usually yes. Anything with an API can be connected; anything without one can often be reached through file exports, email parsing or vendor-provided options. We assess feasibility honestly before committing.",
      },
      {
        question: "Who owns the integrations after the project?",
        answer:
          "You do. Everything is documented, the code and configurations are yours, and we offer ongoing support only if you want it.",
      },
      {
        question: "Can you migrate our data without downtime?",
        answer:
          "Most migrations are staged: parallel runs, reconciliation reports and a cut-over window agreed with you. The plan depends on the systems involved and is documented before we start.",
      },
      {
        question: "How is security handled?",
        answer:
          "Least-privilege credentials, encrypted secrets, no credentials in code, and access logging where supported. We follow your security requirements and flag gaps we find in existing setups.",
      },
    ],
    relatedSlugs: ["ai-automation", "website-development"],
  },
  {
    slug: "website-development",
    name: "Website Development",
    shortName: "Web Development",
    icon: "MonitorSmartphone",
    tagline: "Websites that look exceptional and work hard.",
    intro:
      "We design and build modern business websites — fast, clear and connected to your operations. Premium presentation on the surface, working systems underneath.",
    description: [
      "Your website is often the first real conversation with a customer. It should communicate clearly what you do, prove credibility, and make the next step obvious — whether that step is a purchase, a booking or a conversation.",
      "We build on modern frameworks with performance and accessibility as defaults: fast load times, responsive layouts on every device, semantic structure that search engines understand, and analytics you can actually use. Every build is designed around your business goals, not a template.",
      "We also connect your website to your operations: forms into your CRM, booking into your calendar, content you can edit yourself. A website should be an asset you operate, not a brochure you tolerate.",
    ],
    outcomes: [
      { title: "Credible first impression", description: "A distinctive, polished presence that matches the quality of your business." },
      { title: "Measured performance", description: "Fast, responsive and search-ready — with Core Web Vitals treated as requirements." },
      { title: "Connected to operations", description: "Forms, bookings and content management wired into your real workflows." },
    ],
    subservices: [
      {
        slug: "business-websites",
        name: "Business Websites",
        tagline: "A complete digital home for your company.",
        description:
          "Multi-page business websites with clear information architecture, persuasive service content and conversion paths — built to support sales, recruiting and credibility at once.",
        bullets: [
          "Structure and messaging planned around buyer questions",
          "Responsive, accessible, fast by default",
          "Editable content: you can update text, articles and images yourself",
          "SEO foundations: metadata, sitemaps, structured data",
        ],
        useCases: [
          "A consultancy replaces an outdated brochure site",
          "A manufacturer presents capabilities to international buyers",
          "A service firm adds careers, insights and case content",
        ],
      },
      {
        slug: "ecommerce-websites",
        name: "E-commerce Websites",
        tagline: "Stores designed to sell and built to operate.",
        description:
          "Online stores with clean product presentation, friction-free checkout and operational connections — inventory, orders and shipping flowing into the systems that run your business.",
        bullets: [
          "Product catalog structure and merchandising logic",
          "Conversion-focused product pages and checkout",
          "Payment, shipping and tax configuration",
          "Order data connected to your operations",
        ],
        useCases: [
          "A retail brand launches direct-to-consumer sales",
          "A wholesaler opens a B2B ordering portal",
          "A brand migrates from a slow legacy platform",
        ],
      },
      {
        slug: "landing-pages",
        name: "Landing Pages",
        tagline: "Single pages engineered around one action.",
        description:
          "Campaign and offer landing pages with focused messaging, fast delivery and measurable results — built to support a specific promotion, product or audience.",
        bullets: [
          "One page, one goal: message and design aligned",
          "Fast load for paid-traffic budgets",
          "A/B-ready structure and clean analytics events",
          "Forms wired to your CRM with spam protection",
        ],
        useCases: [
          "A product launch gets a dedicated conversion page",
          "A service promotion supports an ad campaign",
          "An event page handles registration end-to-end",
        ],
      },
      {
        slug: "website-redesigns",
        name: "Website Redesigns",
        tagline: "Keep what works, fix what doesn't.",
        description:
          "We rebuild underperforming websites while protecting what already earns: existing rankings are mapped, redirects planned, and content preserved — so a redesign is an upgrade, not a reset.",
        bullets: [
          "Audit of current content, rankings and conversion paths",
          "Redesign with preserved URL structure and redirects",
          "Content migration with improved structure",
          "Before/after measurement of speed and conversion",
        ],
        useCases: [
          "A company modernizes without losing search visibility",
          "A rebrand carries the website along properly",
          "A slow site is rebuilt for speed and mobile",
        ],
      },
    ],
    process: [
      { step: "01", title: "Discover", description: "Goals, audiences and required functionality are agreed before design starts." },
      { step: "02", title: "Design", description: "Structure, content and visual design are approved page by page — no surprises at launch." },
      { step: "03", title: "Build", description: "Development with performance, accessibility and SEO handled as requirements, not extras." },
      { step: "04", title: "Launch & operate", description: "Deployment, analytics, training and a plan for keeping the site healthy." },
    ],
    faqs: [
      {
        question: "How long does a business website take?",
        answer:
          "A focused business site typically takes a few weeks from kickoff to launch depending on scope; larger builds take longer. We agree a realistic timeline after scoping — and communicate clearly when anything changes it.",
      },
      {
        question: "Can we edit the website ourselves afterwards?",
        answer:
          "Yes. We build content management into every site — articles, service content and pages you need to update are editable by your team, with training included.",
      },
      {
        question: "Will our website be fast and rank well?",
        answer:
          "We build to strong technical standards: fast load times, responsive design, clean structure, metadata and sitemaps. No honest developer can guarantee rankings — but poor technical foundations guarantee problems, and we remove them.",
      },
      {
        question: "What happens after launch?",
        answer:
          "You own everything. We offer maintenance and improvement plans if you want ongoing support — updates, monitoring, content help and iteration based on real usage data.",
      },
    ],
    relatedSlugs: ["technical-services-integrations", "ai-automation"],
  },
];

export const SERVICE_MAP: Record<string, Service> = Object.fromEntries(
  SERVICES.map((s) => [s.slug, s])
);

export function getService(slug: string): Service | undefined {
  return SERVICE_MAP[slug];
}

export function getSubservice(serviceSlug: string, subSlug: string) {
  const service = getService(serviceSlug);
  if (!service) return undefined;
  const sub = service.subservices.find((s) => s.slug === subSlug);
  if (!sub) return undefined;
  return { service, sub };
}

export function countSubservices(): number {
  return SERVICES.reduce((acc, s) => acc + s.subservices.length, 0);
}
