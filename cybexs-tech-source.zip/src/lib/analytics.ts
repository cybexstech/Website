// Analytics abstraction. No provider is configured at launch by design —
// events are described once here and can be wired to a provider later without
// touching call sites. Do NOT send form field values or personal data as properties.

export type AnalyticsEvent =
  | "consultation_cta_clicked"
  | "consultation_form_submitted"
  | "scheduling_opened"
  | "booking_confirmed"
  | "contact_form_submitted"
  | "demo_opened"
  | "service_page_viewed"
  | "article_viewed";

type EventProps = Record<string, string | number | boolean | undefined>;

declare global {
  interface Window {
    __cybexsAnalytics?: (event: AnalyticsEvent, props?: EventProps) => void;
  }
}

/**
 * Track a product analytics event. While no provider is connected this is a
 * safe no-op (dev console only). Wire a provider by assigning
 * `window.__cybexsAnalytics` in a small client component — no call sites change.
 */
export function trackEvent(event: AnalyticsEvent, props?: EventProps): void {
  if (typeof window === "undefined") return;
  try {
    if (process.env.NODE_ENV !== "production") {
      // Dev visibility only.
      console.debug(`[analytics] ${event}`, props ?? {});
    }
    window.__cybexsAnalytics?.(event, props);
  } catch {
    // Analytics must never break the UI.
  }
}
