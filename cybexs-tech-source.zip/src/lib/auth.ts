import "server-only";

import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

const SESSION_COOKIE = "cybexs_admin_session";
const SESSION_TTL_SECONDS = 60 * 60 * 8; // 8 hours

export type AdminSession = {
  id: string;
  email: string;
  name: string;
  role: "ADMIN" | "TEAM";
};

function getSecretKey(): Uint8Array {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error("SESSION_SECRET env var must be set (min 16 chars).");
  }
  return new TextEncoder().encode(secret);
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createSession(user: AdminSession): Promise<void> {
  const token = await new SignJWT({ ...user })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_TTL_SECONDS}s`)
    .sign(getSecretKey());

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_TTL_SECONDS,
    path: "/",
  });
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export async function getSession(): Promise<AdminSession | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE)?.value;
    if (!token) return null;

    const { payload } = await jwtVerify(token, getSecretKey());
    if (!payload || typeof payload.id !== "string" || typeof payload.email !== "string") {
      return null;
    }

    // Verify the user still exists (revocation-safe).
    const user = await db.adminUser.findUnique({ where: { id: payload.id } });
    if (!user) return null;

    return {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role === "ADMIN" ? "ADMIN" : "TEAM",
    };
  } catch {
    return null;
  }
}

export async function authenticate(
  email: string,
  password: string
): Promise<AdminSession | null> {
  const user = await db.adminUser.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (!user) return null;
  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return null;
  return { id: user.id, email: user.email, name: user.name, role: user.role === "ADMIN" ? "ADMIN" : "TEAM" };
}

/**
 * Server-side guard for admin API routes. Throws Response-like errors handled by callers.
 * ADMIN role required when `adminOnly` is true (e.g. exports, team management).
 */
export async function requireSession(adminOnly = false): Promise<AdminSession> {
  const session = await getSession();
  if (!session) {
    throw new UnauthorizedError("Authentication required.");
  }
  if (adminOnly && session.role !== "ADMIN") {
    throw new ForbiddenError("Administrator privileges required.");
  }
  return session;
}

export class UnauthorizedError extends Error {}
export class ForbiddenError extends Error {}

export function isAdminError(err: unknown): err is UnauthorizedError | ForbiddenError {
  return err instanceof UnauthorizedError || err instanceof ForbiddenError;
}
