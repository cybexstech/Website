import { PrismaClient } from '@prisma/client'

// ---------------------------------------------------------------------------
// Import-safe Prisma client.
//
// `new PrismaClient()` at module scope throws when DATABASE_URL is missing
// (e.g. a fresh CI/Vercel build of a clone without .env), which would crash
// the entire build. Pages deliberately wrap every query in try/catch so the
// site degrades gracefully ("database unavailable" empty states), so the
// failure must happen at QUERY time, never at IMPORT time.
//
// The Proxy below defers client construction until the first property access
// (i.e. the first actual query), keeping `import { db }` always safe.
// ---------------------------------------------------------------------------

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

function createClient(): PrismaClient {
  if (!process.env.DATABASE_URL) {
    // Thrown on first USE — caught by the callers' try/catch, which render
    // graceful empty states. Never thrown at import time.
    throw new Error('DATABASE_URL is not configured')
  }
  return new PrismaClient({
    log: process.env.NODE_ENV === 'production' ? ['error'] : ['query'],
  })
}

function getDb(): PrismaClient {
  if (!globalForPrisma.prisma) {
    globalForPrisma.prisma = createClient()
  }
  return globalForPrisma.prisma
}

export const db: PrismaClient = new Proxy({} as PrismaClient, {
  get(_target, prop, receiver) {
    const client = getDb()
    const value = Reflect.get(client as object, prop, receiver)
    return typeof value === 'function' ? value.bind(client) : value
  },
})
