import "server-only";

import { siteConfig } from "@/lib/site";

export type EmailSendResult = {
  status: "SENT" | "FAILED" | "SKIPPED_NO_PROVIDER";
  error?: string;
  providerRef?: string;
};

type LeadNotification = {
  leadId: string;
  fullName: string;
  email: string;
  companyName: string;
  companyWebsite?: string | null;
  serviceInterest: string;
  source: string;
  message?: string | null;
};

function isConfigured(): boolean {
  return Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM);
}

function notifyAddress(): string {
  return process.env.NOTIFY_EMAIL || siteConfig.contactEmail;
}

async function sendViaResend(subject: string, html: string, to: string, replyTo?: string): Promise<EmailSendResult> {
  const apiKey = process.env.RESEND_API_KEY as string;
  const from = process.env.EMAIL_FROM as string;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject,
        html,
        ...(replyTo ? { reply_to: replyTo } : {}),
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      // Never leak credentials or full provider internals to logs stored on leads.
      return { status: "FAILED", error: `Provider responded ${res.status}` };
    }
    const data = (await res.json().catch(() => ({}))) as { id?: string };
    return { status: "SENT", providerRef: data.id };
  } catch (err) {
    return { status: "FAILED", error: err instanceof Error ? err.message.slice(0, 200) : "Unknown transport error" };
  }
}

function wrapEmail(title: string, bodyHtml: string): string {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#fafaf8;font-family:Helvetica,Arial,sans-serif;">
  <div style="max-width:560px;margin:0 auto;padding:32px 24px;">
    <div style="font-size:18px;font-weight:700;color:#0a0a0a;">Cybexs Tech<span style="color:#FF3B30;">.</span></div>
    <h1 style="font-size:20px;margin:24px 0 12px;color:#0a0a0a;">${title}</h1>
    <div style="background:#ffffff;border:1px solid #e5e5e5;border-radius:12px;padding:24px;font-size:14px;line-height:1.7;color:#333;">${bodyHtml}</div>
    <p style="font-size:12px;color:#999;margin-top:24px;">Sent by the Cybexs Tech website. Business inquiries: ${siteConfig.contactEmail}</p>
  </div></body></html>`;
}

function leadRows(lead: LeadNotification): string {
  const row = (label: string, value: string) =>
    `<tr><td style="padding:6px 12px 6px 0;color:#888;white-space:nowrap;vertical-align:top;">${label}</td><td style="padding:6px 0;color:#0a0a0a;font-weight:600;">${value}</td></tr>`;
  return `<table style="border-collapse:collapse;width:100%;">${row("Name", escape(lead.fullName))}${row(
    "Email",
    escape(lead.email)
  )}${row("Company", escape(lead.companyName))}${
    lead.companyWebsite ? row("Website", escape(lead.companyWebsite)) : ""
  }${row("Service interest", escape(lead.serviceInterest))}${row("Source", escape(lead.source))}${
    lead.message ? row("Message", escape(lead.message).replace(/\n/g, "<br/>")) : ""
  }</table>`;
}

function escape(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * Notify the business inbox about a new lead. Lead persistence happens BEFORE
 * this call and a failure here never discards the lead — the result is recorded on the Lead row.
 */
export async function sendLeadNotification(lead: LeadNotification): Promise<EmailSendResult> {
  if (!isConfigured()) {
    console.info(`[email] Provider not configured — skipping notification for lead ${lead.leadId}. Set RESEND_API_KEY + EMAIL_FROM to enable.`);
    return { status: "SKIPPED_NO_PROVIDER" };
  }
  const kind = lead.source === "consultation" ? "New consultation request" : "New contact inquiry";
  const html = wrapEmail(kind, `<p>${lead.fullName} from <strong>${escape(lead.companyName)}</strong> submitted the website form.</p>${leadRows(lead)}<p style="margin-top:16px;">Lead reference: <code>${lead.leadId}</code></p>`);
  return sendViaResend(`${kind} — ${lead.companyName}`, html, notifyAddress(), lead.email);
}

/**
 * Polite acknowledgement to the prospect. Only for form submissions, never used
 * as a booking confirmation (bookings are only confirmed by Cal.com itself).
 */
export async function sendProspectAcknowledgement(lead: LeadNotification): Promise<EmailSendResult> {
  if (!isConfigured()) {
    return { status: "SKIPPED_NO_PROVIDER" };
  }
  const html = wrapEmail(
    "Thanks for reaching out",
    `<p>Hi ${escape(lead.fullName.split(" ")[0])},</p>
     <p>Thank you for contacting Cybexs Tech. We have received your inquiry about <strong>${escape(lead.serviceInterest)}</strong> and a member of our team will review it and get back to you at this address.</p>
     <p>If you are scheduling a free consultation, please use the scheduling step you were directed to after submitting the form — your appointment is only confirmed once the scheduling provider confirms it.</p>
     <p>— The Cybexs Tech team</p>`
  );
  return sendViaResend("We received your inquiry — Cybexs Tech", html, lead.email, notifyAddress());
}

export function emailProviderConfigured(): boolean {
  return isConfigured();
}
