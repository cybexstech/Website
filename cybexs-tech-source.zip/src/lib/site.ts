// Central site configuration. Production domain is env-driven so temporary
// deployment domains are never used as canonical URLs.

export const siteConfig = {
  name: "Cybexs Tech",
  legalName: "Cybexs Tech",
  domain: "cybexs.tech",
  url: process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") || "https://cybexs.tech",
  contactEmail: "business@cybexs.tech",
  description:
    "Cybexs Tech helps businesses streamline operations, improve sales processes, and create better digital experiences through practical AI automation, technical solutions, and human-powered business services.",
  tagline: "Automate the busywork. Support the growth. Build better digital experiences.",
  linkedinUrl: process.env.NEXT_PUBLIC_LINKEDIN_URL || null,
  bookingUrl: process.env.NEXT_PUBLIC_CALCOM_BOOKING_URL || null,
  keywords: [
    "AI automation agency",
    "AI voice agents",
    "lead reactivation",
    "sales lead generation",
    "BPO customer support",
    "business system integrations",
    "website development services",
  ],
} as const;

export type SiteConfig = typeof siteConfig;

export function absoluteUrl(path: string): string {
  return `${siteConfig.url}${path.startsWith("/") ? path : `/${path}`}`;
}
