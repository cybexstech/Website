import { z } from "zod";
import { SERVICES } from "@/data/services";

export const SERVICE_INTEREST_VALUES = [
  ...SERVICES.map((s) => s.name),
  "Not sure yet",
] as const;

// Shared constraints. Deliberately permissive to avoid rejecting legitimate
// business contacts (e.g. long company names, international phone-format emails are out of scope).
const nameSchema = z.string().trim().min(2, "Please enter your full name.").max(120);
const emailSchema = z.string().trim().toLowerCase().email("Please enter a valid work email.").max(200);
const companySchema = z.string().trim().min(2, "Please enter your company name.").max(160);
const websiteSchema = z
  .string()
  .trim()
  .max(200)
  .optional()
  .or(z.literal(""))
  .transform((v) => (v && v.length > 0 ? v : undefined))
  .refine(
    (v) => !v || /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/\S*)?$/i.test(v),
    "Please enter a valid website (e.g. company.com)."
  );

export const consultationLeadSchema = z.object({
  fullName: nameSchema,
  email: emailSchema,
  companyName: companySchema,
  companyWebsite: websiteSchema,
  serviceInterest: z.enum(SERVICE_INTEREST_VALUES),
});

export const contactLeadSchema = z.object({
  fullName: nameSchema,
  email: emailSchema,
  companyName: companySchema,
  companyWebsite: websiteSchema,
  serviceInterest: z.enum(SERVICE_INTEREST_VALUES),
  message: z.string().trim().min(10, "Please tell us briefly what you need help with (10+ characters).").max(4000),
});

export type ConsultationLeadInput = z.infer<typeof consultationLeadSchema>;
export type ContactLeadInput = z.infer<typeof contactLeadSchema>;

export const LEAD_STATUSES = ["NEW", "CONTACTED", "QUALIFIED", "MEETING_BOOKED", "WON", "LOST"] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const leadUpdateSchema = z.object({
  status: z.enum(LEAD_STATUSES).optional(),
  ownerName: z.string().trim().max(120).nullable().optional(),
  followUpDate: z.string().datetime({ offset: true }).nullable().optional(),
});

export const noteCreateSchema = z.object({
  body: z.string().trim().min(1, "Note cannot be empty.").max(4000),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Password is required.").max(200),
});

export const articleUpsertSchema = z.object({
  title: z.string().trim().min(4).max(200),
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug may contain lowercase letters, numbers and hyphens.")
    .min(3)
    .max(120),
  excerpt: z.string().trim().min(20).max(400),
  content: z.string().trim().min(50),
  category: z.string().trim().min(2).max(80),
  tags: z.string().trim().max(240).default(""),
  status: z.enum(["DRAFT", "PUBLISHED"]).default("DRAFT"),
  seoTitle: z.string().trim().max(200).optional().or(z.literal("")),
  seoDescription: z.string().trim().max(320).optional().or(z.literal("")),
  featuredImage: z.string().trim().max(400).optional().or(z.literal("")),
  author: z.string().trim().min(2).max(120).default("Cybexs Tech Team"),
  readMinutes: z.coerce.number().int().min(1).max(60).default(6),
  publishedAt: z.string().datetime({ offset: true }).nullable().optional(),
});

export type ArticleUpsertInput = z.infer<typeof articleUpsertSchema>;
